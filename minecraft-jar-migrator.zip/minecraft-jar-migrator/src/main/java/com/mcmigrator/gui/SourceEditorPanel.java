package com.mcmigrator.gui;

import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class SourceEditorPanel extends JPanel {

    private final RSyntaxTextArea textArea;
    private Path currentFile;

    public SourceEditorPanel() {
        super(new BorderLayout());
        textArea = new RSyntaxTextArea(20, 80);
        textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        textArea.setCodeFoldingEnabled(true);
        textArea.setAntiAliasingEnabled(true);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        textArea.setEditable(true);

        RTextScrollPane scrollPane = new RTextScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton saveBtn = new JButton("Save");
        JButton revertBtn = new JButton("Revert");
        JLabel fileLabel = new JLabel("No file loaded");

        saveBtn.addActionListener(e -> saveFile());
        revertBtn.addActionListener(e -> {
            if (currentFile != null) loadFile(currentFile);
        });

        toolbar.add(saveBtn);
        toolbar.add(revertBtn);
        toolbar.add(Box.createHorizontalStrut(20));
        toolbar.add(fileLabel);
        add(toolbar, BorderLayout.NORTH);
    }

    public void loadFile(Path file) {
        try {
            this.currentFile = file;
            String content = Files.readString(file, StandardCharsets.UTF_8);
            textArea.setText(content);
            textArea.setCaretPosition(0);
            textArea.discardAllEdits();
        } catch (IOException e) {
            textArea.setText("// Error loading file: " + e.getMessage());
        }
    }

    public void loadContent(String content, String fileName) {
        textArea.setText(content);
        textArea.setCaretPosition(0);
        textArea.discardAllEdits();
        if (fileName.endsWith(".java")) {
            textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        } else if (fileName.endsWith(".json")) {
            textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JSON);
        } else if (fileName.endsWith(".xml")) {
            textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_XML);
        } else if (fileName.endsWith(".yml") || fileName.endsWith(".yaml")) {
            textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_YAML);
        }
    }

    private void saveFile() {
        if (currentFile == null) return;
        try {
            Files.writeString(currentFile, textArea.getText(), StandardCharsets.UTF_8);
            JOptionPane.showMessageDialog(this, "Saved: " + currentFile.getFileName());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public String getContent() {
        return textArea.getText();
    }

    public boolean isModified() {
        return textArea.getText().length() > 0 && currentFile != null;
    }
}
