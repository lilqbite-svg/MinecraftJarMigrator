package com.mcmigrator.gui;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.mcmigrator.Constants;
import com.mcmigrator.ModType;
import com.mcmigrator.pipeline.MigrationConfig;
import com.mcmigrator.pipeline.MigrationPipeline;
import com.mcmigrator.analysis.CompatibilityAdvisor;
import com.mcmigrator.analysis.LibraryCatalog;
import com.mcmigrator.analysis.PreflightChecker;
import com.mcmigrator.util.MigrationHistory;
import com.mcmigrator.util.SettingsProfiles;
import com.mcmigrator.util.TestServerScriptGenerator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Графический интерфейс мигратора: анализ jar (выбор или drag&drop),
 * информация о моде, параметры миграции, каскад и пакетный режим,
 * Mixin-проверка, вкладки отчёта и diff, история, профили настроек,
 * живой журнал с копированием, статус-индикатор, темы и масштаб.
 */
public final class MigratorGui {

    private static final Color OK_COLOR = new Color(0x2E9E5B);
    private static final Color WARN_COLOR = new Color(0xC98A1B);
    private static final Color ERR_COLOR = new Color(0xD64545);

    private final JFrame frame = new JFrame(Constants.TOOL_NAME + " v" + Constants.TOOL_VERSION);

    private final JTextField inputField = new JTextField();
    private final JTextField outputField = new JTextField();
    private final JTextField fromField = new JTextField();
    private final JTextField toField = new JTextField();
    private final JComboBox<String> loaderCombo = new JComboBox<>(new String[]{
            "Fabric", "Forge", "NeoForge", "Quilt", "Paper/Spigot", "Mixed"});
    private final JTextField classpathField = new JTextField();
    private final JCheckBox keepSourcesCheck = new JCheckBox("Сохранить исходники");
    private final JCheckBox dryRunCheck = new JCheckBox("Пробный запуск (--dry-run)");
    private final JComboBox<com.mcmigrator.decompiler.DecompilerType> decompilerCombo =
            new JComboBox<>(com.mcmigrator.decompiler.DecompilerType.values());
    private final JCheckBox decompileCacheCheck = new JCheckBox("Кэш декомпиляции", true);
    private final JButton preflightButton = new JButton("🔎 Проверить jar");
    private final JButton smokeTestButton = new JButton("🧪 Smoke-test");
    private final JCheckBox autoClasspathCheck =
            new JCheckBox("Автоматический classpath", true);
    private final JCheckBox interactiveCheck =
            new JCheckBox("Интерактивный выбор breaking-правил");
    private final JCheckBox cascadeCheck =
            new JCheckBox("Каскад через промежуточные версии");
    private final JToggleButton themeToggle = new JToggleButton("\uD83C\uDF19 Тёмная тема");
    private final JButton migrateButton = new JButton("Мигрировать \u2192");
    private final JButton mixinButton = new JButton("\uD83D\uDD0D Проверить Mixin'ы");
    private final JButton batchButton = new JButton("\uD83D\uDCC1 Пакетно");
    private final JButton historyButton = new JButton("\uD83D\uDD52 История");
    private final JButton copyLogButton = new JButton("\uD83D\uDCCB Копировать журнал");
    private final JButton protectionAnalyzeButton = new JButton("\uD83D\uDEE1\uFE0F Анализ защиты");
    private final JButton protectionRemoveButton = new JButton("\uD83D\uDD13 Снять защиту");
    private final JTextArea protectionArea = new JTextArea(12, 60);
    private final JLabel protectionStatus = new JLabel(" ");
    private final JProgressBar protectionProgress = new JProgressBar();
    private final JTextArea compatibilityArea = new JTextArea(12, 60);
    private final JTextArea graphArea = new JTextArea(12, 60);
    private final JTextArea preflightArea = new JTextArea(12, 60);
    private final JTextArea smokeTestArea = new JTextArea(10, 60);

    private final JLabel statusIcon = new JLabel("\u25CF");
    private final JProgressBar progressBar = new JProgressBar();
    private final JTextArea logArea = new JTextArea();

    private final JLabel infoName = new JLabel("—");
    private final JLabel infoId = new JLabel("—");
    private final JLabel infoVersion = new JLabel("—");
    private final JLabel infoMc = new JLabel("—");
    private final JLabel infoLoader = new JLabel("—");
    private final JLabel infoAuthors = new JLabel("—");
    private final JLabel infoLicense = new JLabel("—");
    private final JTextArea infoLibraries = new JTextArea(2, 10);
    private final JTextArea infoDescription = new JTextArea(2, 10);

    private final JTabbedPane tabs = new JTabbedPane();
    private final JTextArea reportArea = new JTextArea();
    private final JComboBox<String> reportFilter = new JComboBox<>(new String[]{
            "Весь отчёт", "Трансформации", "Ручные правки", "Предупреждения"});
    private final JTextArea diffArea = new JTextArea();
    private final JComboBox<String> diffCombo = new JComboBox<>();
    private String lastReportText = "";
    private Path lastDiffDir;

    private final JComboBox<String> profileCombo = new JComboBox<>();
    private CompatibilityAdvisor.Report lastAdvice = CompatibilityAdvisor.Report.empty();
    private PreflightChecker.Result lastPreflight = PreflightChecker.Result.empty();
    private ModAnalyzer.ModInfo lastInfo;
    private Path lastAnalyzedJar;
    private final MigrationHistory history = new MigrationHistory(
            Path.of(System.getProperty("user.home"), ".mcmigrator"));
    private final SettingsProfiles profiles = new SettingsProfiles(
            Path.of(System.getProperty("user.home"), ".mcmigrator"));

    private float fontScale = 1.0f;

    /**
     * Запускает GUI в потоке диспетчеризации событий Swing.
     *
     * @param preload jar для немедленного анализа («Открыть с помощью»); может быть {@code null}
     */
    public static void launch(Path preload) {
        FlatLightLaf.setup();
        SwingUtilities.invokeLater(() -> {
            MigratorGui gui = new MigratorGui();
            gui.show();
            if (preload != null) {
                gui.setInput(preload.toFile());
            }
        });
    }

    private MigratorGui() {
        Locale.setDefault(Locale.forLanguageTag("ru"));
    }

    private void show() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(0, 8));
        frame.add(buildHeader(), BorderLayout.NORTH);
        frame.add(buildCenter(), BorderLayout.CENTER);
        frame.setMinimumSize(new Dimension(820, 820));
        frame.setLocationRelativeTo(null);

        loaderCombo.setSelectedItem("Paper/Spigot");
        fromField.setToolTipText("Определится автоматически после выбора jar");
        toField.setToolTipText("Целевая версия Minecraft, например 1.21.1");
        progressBar.setStringPainted(true);
        setStatus("Перетащите .jar в окно или нажмите «Обзор…»", null);

        logArea.setEditable(false);
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        SwingLogAppender.attach(line ->
                SwingUtilities.invokeLater(() -> {
                    logArea.append(line + System.lineSeparator());
                    logArea.setCaretPosition(logArea.getDocument().getLength());
                }));

        themeToggle.addActionListener(e -> applyTheme(themeToggle.isSelected()));
        migrateButton.addActionListener(e -> startMigration());
        mixinButton.addActionListener(e -> checkMixins());
        batchButton.addActionListener(e -> startBatch());
        historyButton.addActionListener(e -> showHistory());
        copyLogButton.addActionListener(e -> copyLog());
        preflightButton.addActionListener(e -> runPreflight());
        smokeTestButton.addActionListener(e -> generateSmokeTest());
        protectionAnalyzeButton.addActionListener(e -> analyzeProtection());
        protectionRemoveButton.addActionListener(e -> removeProtection());
        loaderCombo.addActionListener(e -> applyEcosystemPreset());
        diffCombo.addActionListener(e -> renderDiff());
        reportFilter.addActionListener(e -> renderReport());

        reloadProfiles();
        refreshInsights();
        installDragAndDrop();
        frame.setVisible(true);
    }

    /* ------------------------------ Каркас UI ------------------------------ */

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(BorderFactory.createEmptyBorder(12, 16, 0, 16));
        JLabel title = new JLabel("Миграция Minecraft-модов между версиями");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        header.add(title, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.add(scaleButton("A\u2212", -1));
        right.add(scaleButton("A+", +1));
        right.add(themeToggle);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JButton scaleButton(String text, int direction) {
        JButton button = new JButton(text);
        button.setToolTipText("Масштаб интерфейса");
        button.setMargin(new Insets(2, 8, 2, 8));
        button.addActionListener(e -> rescale(direction));
        return button;
    }

    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout(0, 10));
        center.setBorder(BorderFactory.createEmptyBorder(8, 16, 16, 16));

        JPanel top = new JPanel(new BorderLayout(0, 10));
        top.add(buildForm(), BorderLayout.NORTH);
        top.add(buildInfoPanel(), BorderLayout.CENTER);
        top.add(buildProfilesRow(), BorderLayout.SOUTH);
        center.add(top, BorderLayout.NORTH);

        JPanel bottom = new JPanel(new BorderLayout(0, 8));
        JPanel runRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        migrateButton.setFont(migrateButton.getFont().deriveFont(Font.BOLD, 14f));
        migrateButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        runRow.add(migrateButton);
        runRow.add(mixinButton);
        runRow.add(preflightButton);
        runRow.add(protectionAnalyzeButton);
        runRow.add(smokeTestButton);
        runRow.add(batchButton);
        runRow.add(historyButton);

        JPanel runWrap = new JPanel(new BorderLayout(8, 0));
        runWrap.add(runRow, BorderLayout.WEST);
        statusIcon.setFont(statusIcon.getFont().deriveFont(16f));
        statusIcon.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 4));
        JPanel statusRow = new JPanel(new BorderLayout(4, 0));
        statusRow.add(statusIcon, BorderLayout.WEST);
        statusRow.add(progressBar, BorderLayout.CENTER);
        runWrap.add(statusRow, BorderLayout.CENTER);
        bottom.add(runWrap, BorderLayout.NORTH);

        bottom.add(buildTabs(), BorderLayout.CENTER);
        center.add(bottom, BorderLayout.CENTER);
        return center;
    }

    private JTabbedPane buildTabs() {
        JPanel logPanel = new JPanel(new BorderLayout(0, 4));
        JPanel logHeader = new JPanel(new BorderLayout());
        logHeader.add(copyLogButton, BorderLayout.EAST);
        logPanel.add(logHeader, BorderLayout.NORTH);
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setPreferredSize(new Dimension(0, 240));
        logPanel.add(logScroll, BorderLayout.CENTER);
        tabs.addTab("Журнал", logPanel);

        reportArea.setEditable(false);
        reportArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        reportArea.setText("Отчёт появится после миграции.");
        JPanel reportPanel = new JPanel(new BorderLayout(0, 4));
        JPanel reportHeader = new JPanel(new BorderLayout());
        reportHeader.add(new JLabel("Фильтр: "), BorderLayout.WEST);
        reportHeader.add(reportFilter, BorderLayout.CENTER);
        reportPanel.add(reportHeader, BorderLayout.NORTH);
        reportPanel.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        tabs.addTab("Отчёт", reportPanel);

        JPanel diffPanel = new JPanel(new BorderLayout(0, 4));
        JPanel diffHeader = new JPanel(new BorderLayout());
        diffHeader.add(new JLabel("Файл: "), BorderLayout.WEST);
        diffHeader.add(diffCombo, BorderLayout.CENTER);
        diffPanel.add(diffHeader, BorderLayout.NORTH);
        diffArea.setEditable(false);
        diffArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        diffArea.setText("Diff доступен при включённом «Сохранить исходники».");
        diffPanel.add(new JScrollPane(diffArea), BorderLayout.CENTER);
        tabs.addTab("Изменения (diff)", diffPanel);

        tabs.addTab("Совместимость", buildCompatibilityPanel());
        tabs.addTab("Граф зависимостей", buildGraphPanel());
        tabs.addTab("Проверка jar", buildPreflightPanel());
        tabs.addTab("Smoke-test", buildSmokePanel());
        tabs.addTab("\uD83D\uDEE1\uFE0F Защита JAR", buildProtectionPanel());
        return tabs;
    }


    private JPanel buildCompatibilityPanel() {
        compatibilityArea.setEditable(false);
        compatibilityArea.setLineWrap(true);
        compatibilityArea.setWrapStyleWord(true);
        compatibilityArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        compatibilityArea.setText("Совместимость появится после анализа jar.");
        JButton refresh = new JButton("Обновить");
        refresh.addActionListener(e -> refreshInsights());
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        JPanel header = new JPanel(new BorderLayout());
        header.add(new JLabel("Панель совместимости и рекомендаций"), BorderLayout.WEST);
        header.add(refresh, BorderLayout.EAST);
        panel.add(header, BorderLayout.NORTH);
        panel.add(new JScrollPane(compatibilityArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildGraphPanel() {
        graphArea.setEditable(false);
        graphArea.setLineWrap(false);
        graphArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        graphArea.setText("Граф зависимостей появится после анализа jar.");
        JButton refresh = new JButton("Обновить");
        refresh.addActionListener(e -> refreshInsights());
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        JPanel header = new JPanel(new BorderLayout());
        header.add(new JLabel("Текстовый граф зависимостей"), BorderLayout.WEST);
        header.add(refresh, BorderLayout.EAST);
        panel.add(header, BorderLayout.NORTH);
        panel.add(new JScrollPane(graphArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildPreflightPanel() {
        preflightArea.setEditable(false);
        preflightArea.setLineWrap(true);
        preflightArea.setWrapStyleWord(true);
        preflightArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        preflightArea.setText("Предварительная проверка ещё не запускалась.");
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        header.add(preflightButton);
        header.add(new JLabel("Каталог библиотек обновляется автоматически из ~/.mcmigrator/library-catalog.json"));
        panel.add(header, BorderLayout.NORTH);
        panel.add(new JScrollPane(preflightArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildSmokePanel() {
        smokeTestArea.setEditable(false);
        smokeTestArea.setLineWrap(true);
        smokeTestArea.setWrapStyleWord(true);
        smokeTestArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        smokeTestArea.setText("Генератор smoke-test скрипта готов.");
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        header.add(smokeTestButton);
        panel.add(header, BorderLayout.NORTH);
        panel.add(new JScrollPane(smokeTestArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildProtectionPanel() {
        protectionArea.setEditable(false);
        protectionArea.setLineWrap(true);
        protectionArea.setWrapStyleWord(true);
        protectionArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        protectionArea.setText("Нажмите \"\uD83D\uDEE1\uFE0F Анализ защиты\" для сканирования входного JAR.");

        JPanel panel = new JPanel(new BorderLayout(0, 4));
        JPanel header = new JPanel(new BorderLayout());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.add(protectionAnalyzeButton);
        buttons.add(protectionRemoveButton);
        protectionRemoveButton.setEnabled(false);
        header.add(buttons, BorderLayout.WEST);
        header.add(protectionStatus, BorderLayout.CENTER);

        JPanel headerFull = new JPanel(new BorderLayout(0, 2));
        headerFull.add(header, BorderLayout.NORTH);
        protectionProgress.setVisible(false);
        headerFull.add(protectionProgress, BorderLayout.SOUTH);

        panel.add(headerFull, BorderLayout.NORTH);
        panel.add(new JScrollPane(protectionArea), BorderLayout.CENTER);
        return panel;
    }

    private com.mcmigrator.protection.ProtectionAnalyzer.AnalysisResult lastProtectionResult;

    private void analyzeProtection() {
        String inputText = inputField.getText().trim();
        if (inputText.isEmpty()) {
            toast("Выберите входной JAR");
            return;
        }
        Path inputPath = Path.of(inputText);
        if (!java.nio.file.Files.isRegularFile(inputPath)) {
            toast("Файл не найден: " + inputText);
            return;
        }

        protectionAnalyzeButton.setEnabled(false);
        protectionRemoveButton.setEnabled(false);
        protectionProgress.setVisible(true);
        protectionProgress.setIndeterminate(true);
        protectionStatus.setText("Анализ...");
        protectionArea.setText("Сканирование JAR...\n");

        new javax.swing.SwingWorker<com.mcmigrator.protection.ProtectionAnalyzer.AnalysisResult, Void>() {
            @Override
            protected com.mcmigrator.protection.ProtectionAnalyzer.AnalysisResult doInBackground() throws Exception {
                try (java.util.jar.JarFile jar = new java.util.jar.JarFile(inputPath.toFile())) {
                    return com.mcmigrator.protection.ProtectionAnalyzer.analyze(jar);
                }
            }

            @Override
            protected void done() {
                protectionProgress.setVisible(false);
                protectionAnalyzeButton.setEnabled(true);
                try {
                    lastProtectionResult = get();
                    renderProtectionReport(lastProtectionResult);
                    protectionStatus.setText(lastProtectionResult.obfuscatorGuess());
                    if (lastProtectionResult.hasProtections()) {
                        protectionRemoveButton.setEnabled(true);
                        setStatus("Обнаружено " + lastProtectionResult.protections().size()
                                + " механизм(ов) защиты", WARN_COLOR);
                    } else {
                        setStatus("Защита не обнаружена", OK_COLOR);
                    }
                } catch (Exception e) {
                    protectionArea.setText("Ошибка анализа: " + e.getMessage());
                    protectionStatus.setText("Ошибка");
                    setStatus("Ошибка анализа защиты", ERR_COLOR);
                }
            }
        }.execute();
    }

    private void renderProtectionReport(com.mcmigrator.protection.ProtectionAnalyzer.AnalysisResult result) {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════════════\n");
        sb.append("  ОТЧЁТ АНАЛИЗА ЗАЩИТЫ JAR\n");
        sb.append("═══════════════════════════════════════════\n\n");

        sb.append("Классов: ").append(result.totalClasses());
        sb.append(" | Защищённых: ").append(result.protectedClasses());
        sb.append(" | Сложность: ").append(String.format("%.1f", result.protectionScore())).append("/10\n");
        sb.append("Обфускатор: ").append(result.obfuscatorGuess()).append("\n");
        sb.append("Декомпилируемый: ").append(result.decompilable() ? "Да" : "Проблематично").append("\n\n");

        if (!result.hasProtections()) {
            sb.append("✅ Защитные механизмы не обнаружены.\n");
            sb.append("JAR чистый и готов к миграции.\n");
        } else {
            sb.append("⚠ Обнаружено механизмов защиты: ").append(result.protections().size()).append("\n\n");
            for (var p : result.protections()) {
                String icon = switch (p.severity()) {
                    case CRITICAL, HIGH -> "🔴";
                    case MEDIUM -> "🟡";
                    case LOW -> "🟢";
                    case INFO -> "ℹ️";
                };
                sb.append(icon).append(" [").append(p.severity()).append("] ")
                        .append(p.type().getDisplayName()).append("\n");
                sb.append("   ").append(p.type().getDescription()).append("\n");
                sb.append("   ").append(p.details()).append("\n");
                sb.append("   Удаляемый: ").append(p.removable() ? "Да" : "Нет").append("\n");
                if (!p.affectedClasses().isEmpty()) {
                    sb.append("   Классы: ");
                    int show = Math.min(5, p.affectedClasses().size());
                    for (int i = 0; i < show; i++) {
                        if (i > 0) sb.append(", ");
                        String cls = p.affectedClasses().get(i);
                        sb.append(cls.contains(".") ? cls.substring(cls.lastIndexOf('.') + 1) : cls);
                    }
                    if (p.affectedClasses().size() > 5) {
                        sb.append(" ... и ещё ").append(p.affectedClasses().size() - 5);
                    }
                    sb.append("\n");
                }
                sb.append("\n");
            }

            boolean hasRemovable = result.protections().stream().anyMatch(p -> p.removable());
            if (hasRemovable) {
                sb.append("───────────────────────────────────────────\n");
                sb.append("Нажмите \"🔓 Снять защиту\" для удаления\n");
                sb.append("автоматически удаляемых механизмов.\n");
            }
        }

        protectionArea.setText(sb.toString());
        protectionArea.setCaretPosition(0);
    }

    private void removeProtection() {
        if (lastProtectionResult == null) {
            toast("Сначала выполните анализ защиты");
            return;
        }
        String inputText = inputField.getText().trim();
        Path inputPath = Path.of(inputText);

        protectionRemoveButton.setEnabled(false);
        protectionProgress.setVisible(true);
        protectionProgress.setIndeterminate(true);
        protectionStatus.setText("Снятие защиты...");

        new javax.swing.SwingWorker<com.mcmigrator.protection.ProtectionRemover.RemovalResult, Void>() {
            @Override
            protected com.mcmigrator.protection.ProtectionRemover.RemovalResult doInBackground() throws Exception {
                return com.mcmigrator.protection.ProtectionRemover.removeProtections(
                        inputPath, lastProtectionResult);
            }

            @Override
            protected void done() {
                protectionProgress.setVisible(false);
                try {
                    var result = get();
                    String outputPath = inputText.replace(".jar", "-unprotected.jar");
                    java.nio.file.Files.write(Path.of(outputPath), result.outputJar());

                    StringBuilder sb = new StringBuilder(protectionArea.getText());
                    sb.append("═══════════════════════════════════════════\n");
                    sb.append("  РЕЗУЛЬТАТ СНЯТИЯ ЗАЩИТЫ\n");
                    sb.append("═══════════════════════════════════════════\n\n");
                    sb.append(result.summary()).append("\n\n");

                    sb.append("Статистика:\n");
                    sb.append("  Классов обработано: ").append(result.classesProcessed()).append("\n");
                    if (result.stringsDecrypted() > 0)
                        sb.append("  Строк расшифровано: ").append(result.stringsDecrypted()).append("\n");
                    if (result.flowSimplified() > 0)
                        sb.append("  Flow-блоков упрощено: ").append(result.flowSimplified()).append("\n");
                    if (result.reflectionInlined() > 0)
                        sb.append("  Reflection инлайнено: ").append(result.reflectionInlined()).append("\n");
                    if (result.nativeStubbed() > 0)
                        sb.append("  Native застаблено: ").append(result.nativeStubbed()).append("\n");
                    if (result.watermarksRemoved() > 0)
                        sb.append("  Watermark удалено: ").append(result.watermarksRemoved()).append("\n");
                    if (result.antiTamperRemoved() > 0)
                        sb.append("  Подписей удалено: ").append(result.antiTamperRemoved()).append("\n");
                    if (result.framesRestored() > 0)
                        sb.append("  StackMapTable восстановлено: ").append(result.framesRestored()).append("\n");

                    sb.append("\nВыходной файл: ").append(outputPath).append("\n\n");

                    if (!result.warnings().isEmpty()) {
                        sb.append("Предупреждения:\n");
                        for (String w : result.warnings()) {
                            sb.append("  ⚠ ").append(w).append("\n");
                        }
                    }

                    protectionArea.setText(sb.toString());
                    protectionArea.setCaretPosition(0);
                    protectionStatus.setText("Защита снята");
                    setStatus("Защита снята → " + outputPath, OK_COLOR);
                    toast("Файл сохранён: " + outputPath);
                } catch (Exception e) {
                    protectionArea.append("\nОшибка: " + e.getMessage());
                    protectionStatus.setText("Ошибка");
                    setStatus("Ошибка снятия защиты", ERR_COLOR);
                }
            }
        }.execute();
    }

    private void refreshInsights() {
        compatibilityArea.setText(lastAdvice == null ? "Совместимость не рассчитана." :
                buildCompatibilityText(lastAdvice));
        graphArea.setText(lastAdvice == null ? "Граф не рассчитан." : lastAdvice.graph());
        preflightArea.setText(lastPreflight == null ? "Проверка не выполнялась." :
                buildPreflightText(lastPreflight));
        smokeTestArea.setText(buildSmokeText());
    }

    private String buildCompatibilityText(CompatibilityAdvisor.Report report) {
        StringBuilder sb = new StringBuilder();
        sb.append("Сводка:\n").append(report.summary()).append("\n\n");
        sb.append("Матрица:\n").append(report.matrix()).append("\n\n");
        if (!report.notes().isEmpty()) {
            sb.append("Заметки:\n");
            for (String note : report.notes()) {
                sb.append(" - ").append(note).append('\n');
            }
            sb.append('\n');
        }
        if (!report.recommendations().isEmpty()) {
            sb.append("Рекомендации:\n");
            for (String rec : report.recommendations()) {
                sb.append(" - ").append(rec).append('\n');
            }
        }
        return sb.toString().trim();
    }

    private String buildPreflightText(PreflightChecker.Result result) {
        StringBuilder sb = new StringBuilder();
        sb.append("Descriptor: ").append(result.descriptorType()).append('\n');
        sb.append("Classes: ").append(result.hasClasses()).append('\n');
        sb.append("Sources: ").append(result.hasSources()).append('\n');
        sb.append("Nested jars: ").append(result.nestedJars().size()).append('\n');
        if (!result.warnings().isEmpty()) {
            sb.append("\nWarnings:\n");
            for (String w : result.warnings()) {
                sb.append(" - ").append(w).append('\n');
            }
        }
        if (!result.suggestions().isEmpty()) {
            sb.append("\nSuggestions:\n");
            for (String s : result.suggestions()) {
                sb.append(" - ").append(s).append('\n');
            }
        }
        if (!result.missingMixinClasses().isEmpty()) {
            sb.append("\nMissing mixin classes:\n");
            for (String m : result.missingMixinClasses()) {
                sb.append(" - ").append(m).append('\n');
            }
        }
        sb.append("\n").append(result.graph());
        return sb.toString().trim();
    }

    private String buildSmokeText() {
        String out = outputField.getText().trim();
        String to = toField.getText().trim();
        if (out.isEmpty() || to.isEmpty()) {
            return "Сначала укажите целевую версию и выходной jar.";
        }
        return "Будет создан скрипт test-server-" + to + ".bat рядом с:\n" + out
                + "\n\nОн скачает Fabric-сервер целевой версии, положит jar в mods/ и запустит smoke-test.";
    }

    private void runPreflight() {
        String inputText = inputField.getText().trim();
        if (inputText.isEmpty()) {
            toast("Укажите входной jar");
            return;
        }
        Path input = Path.of(inputText);
        setStatus("Предварительная проверка jar…", WARN_COLOR);
        new SwingWorker<PreflightChecker.Result, Void>() {
            @Override
            protected PreflightChecker.Result doInBackground() {
                try {
                    ModAnalyzer.ModInfo info = null;
                    try {
                        info = ModAnalyzer.analyze(input);
                    } catch (Exception ignored) {
                        // preflight можно выполнить и без metadata
                    }
                    return PreflightChecker.inspect(input, info);
                } catch (Exception e) {
                    return PreflightChecker.Result.empty();
                }
            }

            @Override
            protected void done() {
                try {
                    lastPreflight = get();
                    if (lastInfo != null) {
                        lastAdvice = CompatibilityAdvisor.analyze(lastInfo, lastPreflight);
                    }
                    refreshInsights();
                    preflightArea.setCaretPosition(0);
                    setStatus("Проверка jar завершена", OK_COLOR);
                    toast("Preflight готов");
                } catch (Exception e) {
                    setStatus("Не удалось выполнить preflight", ERR_COLOR);
                }
            }
        }.execute();
    }

    private void generateSmokeTest() {
        String outputText = outputField.getText().trim();
        String to = toField.getText().trim();
        if (outputText.isEmpty() || to.isEmpty()) {
            toast("Укажите выходной jar и целевую версию");
            return;
        }
        try {
            Path script = TestServerScriptGenerator.generate(Path.of(outputText), to);
            smokeTestArea.setText("Скрипт создан:\n" + script + "\n\nЗапустите его в Windows для проверки загрузки мода на Fabric-сервере.");
            smokeTestArea.setCaretPosition(0);
            setStatus("Smoke-test скрипт готов", OK_COLOR);
            JOptionPane.showMessageDialog(frame,
                    "Smoke-test скрипт создан:\n" + script,
                    "Готово", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            smokeTestArea.setText("Не удалось создать smoke-test: " + e.getMessage());
            setStatus("Smoke-test не создан", ERR_COLOR);
        }
    }

    /** Применяет пресет выбранного загрузчика: настраивает рекомендуемые флажки. */
    private void applyEcosystemPreset() {
        String preset = (String) loaderCombo.getSelectedItem();
        if (preset == null) {
            return;
        }
        switch (preset) {
            case "Fabric", "Forge", "NeoForge", "Quilt" -> {
                autoClasspathCheck.setSelected(true);
                cascadeCheck.setSelected(false);
            }
            case "Paper/Spigot" -> {
                // Плагинам Paper/Spigot ремап-classpath не нужен.
                autoClasspathCheck.setSelected(false);
                cascadeCheck.setSelected(false);
            }
            case "Mixed" -> {
                autoClasspathCheck.setSelected(false);
                cascadeCheck.setSelected(true);
            }
            default -> {
            }
        }
    }

    /**
     * Тип мода, соответствующий выбранному загрузчику. «Mixed» не несёт
     * собственного {@link ModType}, поэтому трактуется как Fabric
     * (наиболее частый случай для модов; для плагинов пользователь выберет
     * Paper/Spigot явно).
     *
     * @return выбранный тип мода
     */
    private ModType selectedModType() {
        String loader = (String) loaderCombo.getSelectedItem();
        if (loader == null) {
            return ModType.FABRIC;
        }
        return switch (loader) {
            case "Forge" -> ModType.FORGE;
            case "NeoForge" -> ModType.NEOFORGE;
            case "Quilt" -> ModType.QUILT;
            case "Paper/Spigot" -> ModType.PAPER;
            default -> ModType.FABRIC; // Fabric и Mixed
        };
    }

    /** Выбирает в списке загрузчика пункт, соответствующий типу мода. */
    private void selectLoaderFor(ModType type) {
        String label = switch (type) {
            case FORGE -> "Forge";
            case NEOFORGE -> "NeoForge";
            case QUILT -> "Quilt";
            case PAPER, SPIGOT -> "Paper/Spigot";
            default -> "Fabric";
        };
        loaderCombo.setSelectedItem(label);
    }

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        addPathRow(form, gc, row++, "Входной .jar:", inputField, this::browseInput);
        addPathRow(form, gc, row++, "Выходной .jar:", outputField, this::browseOutput);

        addLabel(form, gc, row, 0, "Из версии:");
        addField(form, gc, row, 1, fromField, 0.5);
        addLabel(form, gc, row, 2, "В версию:");
        addField(form, gc, row, 3, toField, 0.5);
        row++;

        addLabel(form, gc, row, 0, "Загрузчик / пресет:");
        addField(form, gc, row, 1, loaderCombo, 0.5);
        loaderCombo.setToolTipText("Тип загрузчика мода. Определяется автоматически при анализе "
                + "jar; задаёт рекомендуемые флажки. «Mixed» — для сборок разного типа.");
        row++;

        addLabel(form, gc, row, 0, "Декомпилятор:");
        addField(form, gc, row, 1, decompilerCombo, 0.5);
        row++;

        addPathRow(form, gc, row, "Classpath (через ;):", classpathField, this::browseClasspath);
        row++;

        gc.gridx = 0;
        gc.gridy = row;
        gc.gridwidth = 4;
        JPanel checks = new JPanel(new GridBagLayout());
        GridBagConstraints cgc = new GridBagConstraints();
        cgc.anchor = GridBagConstraints.WEST;
        cgc.gridx = 0;
        cgc.gridy = 0;
        checks.add(keepSourcesCheck, cgc);
        cgc.gridy = 1;
        checks.add(dryRunCheck, cgc);
        cgc.gridy = 2;
        checks.add(autoClasspathCheck, cgc);
        cgc.gridy = 3;
        checks.add(cascadeCheck, cgc);
        cgc.gridy = 4;
        checks.add(interactiveCheck, cgc);
        cgc.gridy = 5;
        checks.add(decompileCacheCheck, cgc);
        form.add(checks, gc);
        gc.gridwidth = 1;
        row++;

        classpathField.setToolTipText(
                "Server jar / API целевой версии; при авто-classpath заполняется само");
        return form;
    }

    private JPanel buildInfoPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Информация о моде"),
                BorderFactory.createEmptyBorder(2, 8, 6, 8)));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(2, 4, 2, 12);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        addInfoRow(panel, gc, 0, 0, "Название:", infoName);
        addInfoRow(panel, gc, 0, 2, "ID:", infoId);
        addInfoRow(panel, gc, 1, 0, "Версия мода:", infoVersion);
        addInfoRow(panel, gc, 1, 2, "Версия Minecraft:", infoMc);
        addInfoRow(panel, gc, 2, 0, "Загрузчик:", infoLoader);
        addInfoRow(panel, gc, 2, 2, "Автор(ы):", infoAuthors);
        addInfoRow(panel, gc, 3, 0, "Библиотеки/API:", infoLibraries);
        addInfoRow(panel, gc, 3, 2, "Лицензия:", infoLicense);

        infoLibraries.setEditable(false);
        infoLibraries.setLineWrap(true);
        infoLibraries.setWrapStyleWord(true);
        infoLibraries.setOpaque(false);
        infoLibraries.setBorder(null);
        infoLibraries.setText("—");

        gc.gridy = 4;
        gc.gridx = 0;
        gc.weightx = 0;
        panel.add(boldLabel("Описание:"), gc);
        gc.gridx = 1;
        gc.gridwidth = 3;
        gc.weightx = 1;
        infoDescription.setEditable(false);
        infoDescription.setLineWrap(true);
        infoDescription.setWrapStyleWord(true);
        infoDescription.setOpaque(false);
        infoDescription.setBorder(null);
        infoDescription.setText("—");
        panel.add(infoDescription, gc);
        return panel;
    }

    private JPanel buildProfilesRow() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        row.add(new JLabel("Профиль:"));
        profileCombo.setEditable(true);
        profileCombo.setPreferredSize(new Dimension(200, 28));
        row.add(profileCombo);
        JButton apply = new JButton("Применить");
        apply.addActionListener(e -> applyProfile());
        JButton save = new JButton("Сохранить");
        save.addActionListener(e -> saveProfile());
        JButton del = new JButton("Удалить");
        del.addActionListener(e -> deleteProfile());
        row.add(apply);
        row.add(save);
        row.add(del);
        return row;
    }

    private static JLabel boldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        return label;
    }

    private static String formatLibraries(List<LibraryCatalog.LibraryMatch> libraries) {
        if (libraries == null || libraries.isEmpty()) {
            return "—";
        }
        List<String> parts = new ArrayList<>();
        for (LibraryCatalog.Category category : LibraryCatalog.Category.values()) {
            List<String> names = libraries.stream()
                    .filter(m -> m.category() == category)
                    .map(LibraryCatalog.LibraryMatch::displayName)
                    .toList();
            if (!names.isEmpty()) {
                parts.add(category.label() + ": " + String.join(", ", names));
            }
        }
        return String.join("; ", parts);
    }

    private void addInfoRow(JPanel panel, GridBagConstraints gc, int row, int col,
                            String title, java.awt.Component value) {
        gc.gridy = row;
        gc.gridwidth = 1;
        gc.gridx = col;
        gc.weightx = 0;
        panel.add(boldLabel(title), gc);
        gc.gridx = col + 1;
        gc.weightx = 0.5;
        panel.add(value, gc);
    }

    private void addPathRow(JPanel form, GridBagConstraints gc, int row,
                            String label, JTextField field, Runnable browse) {
        addLabel(form, gc, row, 0, label);
        gc.gridx = 1;
        gc.gridy = row;
        gc.gridwidth = 2;
        gc.weightx = 1;
        form.add(field, gc);
        gc.gridwidth = 1;
        gc.gridx = 3;
        gc.weightx = 0;
        JButton browseButton = new JButton("Обзор…");
        browseButton.addActionListener(e -> browse.run());
        form.add(browseButton, gc);
    }

    private void addLabel(JPanel form, GridBagConstraints gc, int row, int col, String text) {
        gc.gridx = col;
        gc.gridy = row;
        gc.weightx = 0;
        form.add(new JLabel(text), gc);
    }

    private void addField(JPanel form, GridBagConstraints gc, int row, int col,
                          java.awt.Component field, double weight) {
        gc.gridx = col;
        gc.gridy = row;
        gc.weightx = weight;
        form.add(field, gc);
    }

    /* --------------------------- Drag & Drop --------------------------- */

    private void installDragAndDrop() {
        new DropTarget(frame, DnDConstants.ACTION_COPY, new java.awt.dnd.DropTargetAdapter() {
            @Override
            public void drop(DropTargetDropEvent event) {
                try {
                    event.acceptDrop(DnDConstants.ACTION_COPY);
                    @SuppressWarnings("unchecked")
                    List<File> files = (List<File>) event.getTransferable()
                            .getTransferData(DataFlavor.javaFileListFlavor);
                    event.dropComplete(true);
                    files.stream()
                            .filter(f -> f.getName().toLowerCase().endsWith(".jar"))
                            .findFirst()
                            .ifPresentOrElse(
                                    f -> SwingUtilities.invokeLater(() -> setInput(f)),
                                    () -> toast("Перетащите файл .jar"));
                } catch (Exception ex) {
                    event.dropComplete(false);
                }
            }
        }, true);
    }

    /* --------------------------- Выбор файлов --------------------------- */

    private void browseInput() {
        File file = chooseFile("Выберите входной jar", false);
        if (file != null) {
            setInput(file);
        }
    }

    private void setInput(File file) {
        inputField.setText(file.getAbsolutePath());
        analyzeAsync(file.toPath());
    }

    private void browseOutput() {
        File file = chooseFile("Куда сохранить выходной jar", true);
        if (file != null) {
            String path = file.getAbsolutePath();
            outputField.setText(path.endsWith(".jar") ? path : path + ".jar");
        }
    }

    private void browseClasspath() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Выберите jar-файлы для classpath");
        chooser.setMultiSelectionEnabled(true);
        chooser.setFileFilter(new FileNameExtensionFilter("JAR файлы", "jar"));
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            StringBuilder sb = new StringBuilder(classpathField.getText().trim());
            for (File f : chooser.getSelectedFiles()) {
                if (sb.length() > 0) {
                    sb.append(';');
                }
                sb.append(f.getAbsolutePath());
            }
            classpathField.setText(sb.toString());
        }
    }

    private File chooseFile(String title, boolean save) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle(title);
        chooser.setFileFilter(new FileNameExtensionFilter("JAR файлы", "jar"));
        int result = save ? chooser.showSaveDialog(frame) : chooser.showOpenDialog(frame);
        return result == JFileChooser.APPROVE_OPTION ? chooser.getSelectedFile() : null;
    }

    /* ------------------------------ Анализ ------------------------------ */

    private void analyzeAsync(Path jar) {
        setStatus("Анализ " + jar.getFileName() + "…", WARN_COLOR);
        progressBar.setIndeterminate(true);
        new SwingWorker<ModAnalyzer.ModInfo, Void>() {
            private Exception failure;

            @Override
            protected ModAnalyzer.ModInfo doInBackground() {
                try {
                    return ModAnalyzer.analyze(jar);
                } catch (Exception e) {
                    failure = e;
                    return null;
                }
            }

            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                try {
                    ModAnalyzer.ModInfo info = get();
                    if (failure != null || info == null) {
                        setStatus("Не удалось проанализировать jar", ERR_COLOR);
                        toast("Файл не похож на мод/плагин Minecraft");
                        return;
                    }
                    applyAnalysis(jar, info);
                } catch (Exception e) {
                    setStatus("Не удалось проанализировать jar", ERR_COLOR);
                }
            }
        }.execute();
    }

    private void applyAnalysis(Path jar, ModAnalyzer.ModInfo info) {
        infoName.setText(orDash(info.name()));
        infoId.setText(orDash(info.id()));
        infoVersion.setText(orDash(info.version()));
        infoMc.setText(orDash(info.mcVersion()));
        String loader = orDash(info.loaderName());
        if (info.intermediary()) {
            loader += " (production, intermediary)";
        }
        infoLoader.setText(loader);
        infoAuthors.setText(orDash(info.authors()));
        infoLibraries.setText(formatLibraries(info.libraries()));
        infoLicense.setText(orDash(info.license()));
        infoDescription.setText(info.description() != null ? info.description() : "—");
        lastInfo = info;
        lastAnalyzedJar = jar;

        if (info.mcVersion() != null) {
            fromField.setText(info.mcVersion());
        }
        if (info.loader() != null) {
            selectLoaderFor(info.loader());
            applyEcosystemPreset();
        }
        suggestOutput(jar);

        lastPreflight = PreflightChecker.inspect(jar, info);
        lastAdvice = CompatibilityAdvisor.analyze(info, lastPreflight);
        refreshInsights();

        String summary = String.format("Анализ: %s %s — %s, MC %s%s",
                orDash(info.name()), orDash(info.version()),
                orDash(info.loaderName()), orDash(info.mcVersion()),
                info.libraries() != null && !info.libraries().isEmpty()
                        ? " • " + info.libraries().size() + " библиотек"
                        : "");
        setStatus(summary, OK_COLOR);
        toast("Анализ завершён");
    }

    private void suggestOutput(Path jar) {
        if (!outputField.getText().isBlank()) {
            return;
        }
        String name = jar.getFileName().toString();
        String base = name.endsWith(".jar") ? name.substring(0, name.length() - 4) : name;
        String to = toField.getText().trim();
        String suffix = to.isEmpty() ? "-migrated" : "-" + to;
        outputField.setText(jar.resolveSibling(base + suffix + ".jar").toString());
    }

    private static String orDash(String value) {
        return value == null || value.isBlank() ? "—" : value;
    }

    /* ------------------------------ Журнал ------------------------------ */

    private void copyLog() {
        String text = logArea.getText();
        Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new StringSelection(text), null);
        toast("Журнал скопирован");
    }

    private void toast(String message) {
        JWindow window = new JWindow(frame);
        JLabel label = new JLabel(message);
        label.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        label.setOpaque(true);
        label.setBackground(UIManager.getColor("ToolTip.background"));
        label.setForeground(UIManager.getColor("ToolTip.foreground"));
        window.add(label);
        window.pack();
        int x = frame.getX() + (frame.getWidth() - window.getWidth()) / 2;
        int y = frame.getY() + frame.getHeight() - window.getHeight() - 48;
        window.setLocation(x, y);
        window.setVisible(true);
        Timer timer = new Timer(1800, e -> window.dispose());
        timer.setRepeats(false);
        timer.start();
    }

    /* ------------------------- Тема и масштаб ------------------------- */

    private void applyTheme(boolean dark) {
        if (dark) {
            FlatDarkLaf.setup();
            themeToggle.setText("\u2600 Светлая тема");
        } else {
            FlatLightLaf.setup();
            themeToggle.setText("\uD83C\uDF19 Тёмная тема");
        }
        SwingUtilities.updateComponentTreeUI(frame);
    }

    private void rescale(int direction) {
        fontScale = Math.max(0.8f, Math.min(1.6f, fontScale + direction * 0.1f));
        Font base = UIManager.getFont("defaultFont");
        if (base != null) {
            UIManager.put("defaultFont", base.deriveFont(13f * fontScale));
        }
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, Math.round(12 * fontScale)));
        SwingUtilities.updateComponentTreeUI(frame);
    }

    private void setStatus(String text, Color color) {
        progressBar.setString(text);
        statusIcon.setForeground(color != null ? color
                : UIManager.getColor("Label.disabledForeground"));
    }

    /* ------------------------------ Миграция ------------------------------ */

    private void startMigration() {
        String inputText = inputField.getText().trim();
        String outputText = outputField.getText().trim();
        String from = fromField.getText().trim();
        String to = toField.getText().trim();
        if (inputText.isEmpty() || outputText.isEmpty() || from.isEmpty() || to.isEmpty()) {
            JOptionPane.showMessageDialog(frame,
                    "Заполните входной/выходной jar и обе версии.",
                    "Не все поля заполнены", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<Path> classpath = new ArrayList<>();
        for (String part : classpathField.getText().split("[;,]")) {
            if (!part.isBlank()) {
                classpath.add(Path.of(part.trim()));
            }
        }

        List<String> disabledRules = interactiveCheck.isSelected()
                ? askDisabledRules(from, to) : List.of();
        if (disabledRules == null) {
            return; // пользователь отменил
        }

        if (lastPreflight != null && lastPreflight.hasSources() && !lastPreflight.hasClasses()) {
            int answer = JOptionPane.showConfirmDialog(frame,
                    "Похоже, это source archive, а не собранный jar.\nПродолжить миграцию?",
                    "Предупреждение", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (answer != JOptionPane.YES_OPTION) {
                return;
            }
        }

        boolean cascade = cascadeCheck.isSelected();
        MigrationConfig config = new MigrationConfig(
                Path.of(inputText), Path.of(outputText), from, to,
                selectedModType(),
                keepSourcesCheck.isSelected(), dryRunCheck.isSelected(),
                Path.of(System.getProperty("user.home")).resolve(Constants.DEFAULT_MAPPINGS_DIR),
                classpath, autoClasspathCheck.isSelected(), disabledRules,
                (com.mcmigrator.decompiler.DecompilerType) decompilerCombo.getSelectedItem(),
                decompileCacheCheck.isSelected());

        logArea.setText("");
        migrateButton.setEnabled(false);
        progressBar.setIndeterminate(true);
        setStatus("Миграция: " + from + " \u2192 " + to + (cascade ? " (каскад)…" : "…"),
                WARN_COLOR);

        new SwingWorker<Void, Void>() {
            private Exception failure;

            @Override
            protected Void doInBackground() {
                try {
                    if (cascade) {
                        com.mcmigrator.pipeline.CascadeMigration.run(config, (step, total, label) ->
                                SwingUtilities.invokeLater(() -> setStatus(
                                        "Каскад " + step + "/" + total + ": " + label,
                                        WARN_COLOR)));
                    } else {
                        new MigrationPipeline().run(config, (stageName, percent, detail) ->
                                SwingUtilities.invokeLater(() -> {
                                    progressBar.setIndeterminate(false);
                                    progressBar.setValue(percent);
                                    setStatus(stageName + " (" + percent + "%): " + detail,
                                            WARN_COLOR);
                                }));
                    }
                } catch (Exception e) {
                    failure = e;
                }
                return null;
            }

            @Override
            protected void done() {
                migrateButton.setEnabled(true);
                progressBar.setIndeterminate(false);
                Path output = Path.of(outputText);
                history.add(MigrationHistory.now(Path.of(inputText), output, from, to,
                        selectedModType(), cascade, failure == null));
                if (failure == null) {
                    setStatus("Готово \u2713", OK_COLOR);
                    loadReportAndDiffs(output);
                    JOptionPane.showMessageDialog(frame,
                            "Миграция завершена!\nОтчёт: "
                                    + MigrationPipeline.reportPath(output),
                            "Успех", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    setStatus("Ошибка миграции", ERR_COLOR);
                    java.io.StringWriter sw = new java.io.StringWriter();
                    failure.printStackTrace(new java.io.PrintWriter(sw));
                    logArea.append("[ERROR] Полная причина:" + System.lineSeparator()
                            + sw + System.lineSeparator());
                    logArea.setCaretPosition(logArea.getDocument().getLength());
                    String message = failure.getMessage() != null
                            ? failure.getMessage() : failure.toString();
                    JOptionPane.showMessageDialog(frame,
                            message + "\n\nПодробности — в журнале внизу окна.",
                            "Миграция не удалась", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }


    /* --------------------- Отчёт и Diff после миграции --------------------- */

    private void loadReportAndDiffs(Path outputJar) {
        try {
            Path reportPath = MigrationPipeline.reportPath(outputJar);
            lastReportText = java.nio.file.Files.isRegularFile(reportPath)
                    ? java.nio.file.Files.readString(reportPath) : "";
        } catch (java.io.IOException e) {
            lastReportText = "Отчёт не прочитан: " + e.getMessage();
        }
        renderReport();

        String base = outputJar.getFileName().toString();
        if (base.endsWith(".jar")) {
            base = base.substring(0, base.length() - 4);
        }
        lastDiffDir = outputJar.resolveSibling(base + "-diffs");
        diffCombo.removeAllItems();
        if (java.nio.file.Files.isDirectory(lastDiffDir)) {
            try (var walk = java.nio.file.Files.list(lastDiffDir)) {
                walk.filter(f -> f.toString().endsWith(".diff")).sorted()
                        .forEach(f -> diffCombo.addItem(f.getFileName().toString()));
            } catch (java.io.IOException ignored) {
                // список останется пустым
            }
        }
        diffArea.setText(diffCombo.getItemCount() == 0
                ? "Правила не меняли файлы — diff отсутствует." : "");
        renderDiff();
    }

    private void renderReport() {
        if (lastReportText.isEmpty()) {
            reportArea.setText("Отчёт появится после миграции.");
            return;
        }
        String filter = (String) reportFilter.getSelectedItem();
        if (filter == null || filter.startsWith("Весь")) {
            reportArea.setText(lastReportText);
        } else {
            String marker = switch (filter) {
                case "Трансформации" -> "## Автоматические трансформации";
                case "Ручные правки" -> "## Требует ручной правки";
                default -> "## Предупреждения";
            };
            StringBuilder sb = new StringBuilder();
            boolean in = false;
            for (String line : lastReportText.split("\n")) {
                if (line.startsWith("## ")) {
                    in = line.startsWith(marker);
                }
                if (in) {
                    sb.append(line).append('\n');
                }
            }
            reportArea.setText(sb.toString());
        }
        reportArea.setCaretPosition(0);
    }

    private void renderDiff() {
        String item = (String) diffCombo.getSelectedItem();
        if (item == null || lastDiffDir == null) {
            return;
        }
        try {
            diffArea.setText(java.nio.file.Files.readString(lastDiffDir.resolve(item)));
            diffArea.setCaretPosition(0);
        } catch (java.io.IOException e) {
            diffArea.setText("Diff не прочитан: " + e.getMessage());
        }
    }

    /* ----------------------- Интерактивные правила ----------------------- */

    /** @return выключенные описания; {@code null} — отмена пользователем */
    private java.util.List<String> askDisabledRules(String from, String to) {
        java.util.List<javax.swing.JCheckBox> boxes = new java.util.ArrayList<>();
        try {
            var ruleSet = com.mcmigrator.rules.VersionRuleSet.load(from, to);
            for (var change : ruleSet.apiBreakingChanges()) {
                javax.swing.JCheckBox box = new javax.swing.JCheckBox(
                        change.description(), true);
                box.setToolTipText("Фикс: " + change.suggestedFix());
                boxes.add(box);
            }
        } catch (Exception e) {
            return java.util.List.of();
        }
        if (boxes.isEmpty()) {
            return java.util.List.of();
        }
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.anchor = GridBagConstraints.WEST;
        gc.gridx = 0;
        for (int i = 0; i < boxes.size(); i++) {
            gc.gridy = i;
            panel.add(boxes.get(i), gc);
        }
        JScrollPane scroll = new JScrollPane(panel);
        scroll.setPreferredSize(new Dimension(640, Math.min(380, 30 * boxes.size() + 20)));
        int answer = JOptionPane.showConfirmDialog(frame, scroll,
                "Какие breaking-проверки выполнять (" + from + " \u2192 " + to + ")",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (answer != JOptionPane.OK_OPTION) {
            return null;
        }
        java.util.List<String> disabled = new java.util.ArrayList<>();
        for (javax.swing.JCheckBox box : boxes) {
            if (!box.isSelected()) {
                disabled.add("ApiBreakingChangeRule: " + box.getText());
            }
        }
        return disabled;
    }

    /* ----------------------------- Mixin-проверка ----------------------------- */

    private void checkMixins() {
        String inputText = inputField.getText().trim();
        String to = toField.getText().trim();
        if (inputText.isEmpty() || to.isEmpty()) {
            toast("Укажите входной jar и целевую версию");
            return;
        }
        setStatus("Проверка Mixin'ов против " + to + "\u2026", WARN_COLOR);
        progressBar.setIndeterminate(true);
        Path input = Path.of(inputText);
        ModType type = selectedModType();
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() {
                try {
                    var mappings = new com.mcmigrator.mappings.MappingsProvider(
                            Path.of(System.getProperty("user.home"))
                                    .resolve(Constants.DEFAULT_MAPPINGS_DIR));
                    Path cpCache = Path.of(System.getProperty("user.home"),
                            ".mcmigrator", "classpath");
                    var report = new com.mcmigrator.report.MigrationReport("mixin-check");
                    var classpath = new com.mcmigrator.classpath.ClasspathProvider(
                            mappings, cpCache).autoClasspath(to, type, report, input);
                    Path mcJar = classpath.stream()
                            .filter(pth -> pth.getFileName().toString()
                                    .matches("(client|server)-" + java.util.regex.Pattern
                                            .quote(to) + "-(mojmap|intermediary).*\\.jar"))
                            .findFirst().orElse(null);
                    if (mcJar == null) {
                        return "Jar Minecraft " + to + " не подготовлен — проверка невозможна";
                    }
                    var summary = com.mcmigrator.analysis.MixinAnalyzer.analyze(input, mcJar);
                    StringBuilder sb = new StringBuilder(summary.verdict()).append('\n');
                    for (var r : summary.results()) {
                        if (r.ok()) {
                            continue;
                        }
                        sb.append('\n').append("\u2717 ").append(r.mixinClass())
                          .append(" \u2192 ").append(r.targetClass());
                        if (!r.targetExists()) {
                            sb.append(" — класс отсутствует");
                        } else {
                            sb.append(" — нет: ")
                              .append(String.join("; ", r.missingMembers()));
                        }
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return "Проверка не удалась: "
                            + com.mcmigrator.util.Throwables.describe(e);
                }
            }

            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                String result;
                try {
                    result = get();
                } catch (Exception e) {
                    result = "Проверка не удалась";
                }
                boolean ok = result.startsWith("Все ") || result.startsWith("Mixin'ов не");
                setStatus(ok ? "Mixin-проверка: всё применится \u2713"
                        : "Mixin-проверка: есть проблемы", ok ? OK_COLOR : ERR_COLOR);
                javax.swing.JTextArea area = new javax.swing.JTextArea(result, 18, 70);
                area.setEditable(false);
                area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
                JOptionPane.showMessageDialog(frame, new JScrollPane(area),
                        "Результат Mixin-проверки", ok
                                ? JOptionPane.INFORMATION_MESSAGE
                                : JOptionPane.WARNING_MESSAGE);
            }
        }.execute();
    }

    /* ------------------------------ Пакетный режим ------------------------------ */

    private void startBatch() {
        String from = fromField.getText().trim();
        String to = toField.getText().trim();
        if (from.isEmpty() || to.isEmpty()) {
            toast("Сначала укажите версии «из» и «в»");
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Папка с jar для пакетной миграции");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        Path inputDir = chooser.getSelectedFile().toPath();
        Path outputDir = inputDir.resolve("migrated-" + to);

        MigrationConfig template = new MigrationConfig(
                inputDir, outputDir, from, to,
                selectedModType(),
                keepSourcesCheck.isSelected(), dryRunCheck.isSelected(),
                Path.of(System.getProperty("user.home")).resolve(Constants.DEFAULT_MAPPINGS_DIR),
                java.util.List.of(), autoClasspathCheck.isSelected(),
                java.util.List.of(),
                (com.mcmigrator.decompiler.DecompilerType) decompilerCombo.getSelectedItem(),
                decompileCacheCheck.isSelected());
        boolean cascade = cascadeCheck.isSelected();

        logArea.setText("");
        migrateButton.setEnabled(false);
        progressBar.setIndeterminate(true);
        new SwingWorker<java.util.List<com.mcmigrator.pipeline.BatchMigration.Item>, Void>() {
            private Exception failure;

            @Override
            protected java.util.List<com.mcmigrator.pipeline.BatchMigration.Item> doInBackground() {
                try {
                    return com.mcmigrator.pipeline.BatchMigration.run(
                            inputDir, outputDir, template, cascade,
                            (step, total, desc) -> SwingUtilities.invokeLater(() ->
                                    setStatus("Пакет " + step + "/" + total
                                            + ": " + desc, WARN_COLOR)));
                } catch (Exception e) {
                    failure = e;
                    return java.util.List.of();
                }
            }

            @Override
            protected void done() {
                migrateButton.setEnabled(true);
                progressBar.setIndeterminate(false);
                if (failure != null) {
                    setStatus("Пакет не выполнен", ERR_COLOR);
                    JOptionPane.showMessageDialog(frame, failure.getMessage(),
                            "Пакетная миграция", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    var results = get();
                    long ok = results.stream().filter(r -> r.status()
                            == com.mcmigrator.pipeline.BatchMigration.Item.Status.OK).count();
                    setStatus("Пакет: " + ok + "/" + results.size() + " успешно",
                            ok == results.size() ? OK_COLOR : WARN_COLOR);
                    StringBuilder sb = new StringBuilder("Готово: " + ok + " из "
                            + results.size() + "\n\n");
                    for (var item : results) {
                        sb.append(item.status() == com.mcmigrator.pipeline
                                        .BatchMigration.Item.Status.OK ? "\u2713 " : "\u2717 ")
                          .append(item.fileName()).append('\n');
                    }
                    sb.append("\nРезультаты и сводка: ").append(outputDir);
                    JOptionPane.showMessageDialog(frame, sb.toString(),
                            "Пакетная миграция", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ignored) {
                    // диалог не критичен
                }
            }
        }.execute();
    }

    /* ------------------------------ История ------------------------------ */

    private void showHistory() {
        var entries = history.load();
        if (entries.isEmpty()) {
            toast("История пока пуста");
            return;
        }
        javax.swing.DefaultListModel<String> model = new javax.swing.DefaultListModel<>();
        entries.forEach(e -> model.addElement(e.display()));
        javax.swing.JList<String> list = new javax.swing.JList<>(model);
        list.setSelectedIndex(0);
        JScrollPane scroll = new JScrollPane(list);
        scroll.setPreferredSize(new Dimension(640, 300));
        int answer = JOptionPane.showOptionDialog(frame, scroll, "История миграций",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                new Object[]{"Повторить", "Закрыть"}, "Повторить");
        if (answer == 0 && list.getSelectedIndex() >= 0) {
            var entry = entries.get(list.getSelectedIndex());
            setInput(new File(entry.inputJar()));
            outputField.setText(entry.outputJar());
            fromField.setText(entry.fromVersion());
            toField.setText(entry.toVersion());
            selectLoaderFor(entry.type());
            cascadeCheck.setSelected(entry.cascade());
            toast("Параметры восстановлены из истории");
        }
    }

    /* ------------------------------ Профили ------------------------------ */

    private void reloadProfiles() {
        profileCombo.removeAllItems();
        profileCombo.addItem("");
        profiles.load().keySet().forEach(profileCombo::addItem);
    }

    private void applyProfile() {
        String name = (String) profileCombo.getSelectedItem();
        if (name == null || name.isBlank()) {
            return;
        }
        var profile = profiles.load().get(name);
        if (profile == null) {
            return;
        }
        fromField.setText(profile.fromVersion());
        toField.setText(profile.toVersion());
        // Загрузчик — единый источник истины. Старые профили хранят его в
        // ecosystem; если его нет, восстанавливаем из устаревшего modType.
        if (profile.ecosystem() != null && !profile.ecosystem().isBlank()) {
            loaderCombo.setSelectedItem(profile.ecosystem());
        } else {
            try {
                selectLoaderFor(ModType.valueOf(profile.modType()));
            } catch (IllegalArgumentException ignored) {
                // тип из очень старого профиля — пропускаем
            }
        }
        classpathField.setText(profile.classpath());
        keepSourcesCheck.setSelected(profile.keepSources());
        dryRunCheck.setSelected(profile.dryRun());
        autoClasspathCheck.setSelected(profile.autoClasspath());
        cascadeCheck.setSelected(profile.cascade());
        toast("Профиль применён: " + name);
    }

    private void saveProfile() {
        Object value = profileCombo.getEditor().getItem();
        String name = value != null ? value.toString().trim() : "";
        if (name.isEmpty()) {
            toast("Введите имя профиля в поле слева");
            return;
        }
        profiles.save(name, new com.mcmigrator.util.SettingsProfiles.Profile(
                fromField.getText().trim(), toField.getText().trim(),
                (selectedModType()).name(),
                (String) loaderCombo.getSelectedItem(),
                classpathField.getText().trim(),
                keepSourcesCheck.isSelected(), dryRunCheck.isSelected(),
                autoClasspathCheck.isSelected(), cascadeCheck.isSelected(),
                ((com.mcmigrator.decompiler.DecompilerType) decompilerCombo.getSelectedItem()).name(),
                decompileCacheCheck.isSelected()));
        reloadProfiles();
        profileCombo.setSelectedItem(name);
        toast("Профиль сохранён: " + name);
    }

    private void deleteProfile() {
        String name = (String) profileCombo.getSelectedItem();
        if (name == null || name.isBlank()) {
            return;
        }
        profiles.delete(name);
        reloadProfiles();
        toast("Профиль удалён: " + name);
    }
}
