package com.mcmigrator.protection;

import org.objectweb.asm.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public final class ProtectionAnalyzer {

    private static final Logger log = LoggerFactory.getLogger(ProtectionAnalyzer.class);

    public enum ProtectionType {
        STRING_ENCRYPTION("String Encryption", "Strings decrypted at runtime via custom algorithm", Severity.HIGH),
        CONTROL_FLOW_OBFUSCATION("Control Flow Obfuscation", "Dead code, opaque predicates, goto spaghetti", Severity.MEDIUM),
        CLASS_RENAMING("Class/Method Renaming", "Names replaced with unreadable characters (a, b, aa, 0x00ff)", Severity.LOW),
        REFLECTION_HEAVY("Heavy Reflection", "Extensive use of reflection to hide method calls", Severity.MEDIUM),
        RESOURCE_ENCRYPTION("Resource Encryption", "Class files or resources encrypted/packed", Severity.HIGH),
        ANTI_TAMPER("Anti-Tamper", "Integrity checks that prevent modification", Severity.HIGH),
        NATIVE_CODE("Native Code", "JNI calls or native library loading", Severity.HIGH),
        CUSTOM_CLASSLOADER("Custom ClassLoader", "Non-standard class loading mechanism", Severity.MEDIUM),
        ZLIB_PACKING("ZLIB/Custom Packing", "Classes packed with custom compression", Severity.HIGH),
        STACK_MAP_TABLE_REMOVAL("StackMapTable Removal", "Debug info stripped, harder to decompile", Severity.LOW),
        INVOKE_DYNAMIC("InvokeDynamic Obfuscation", "String concatenation, lambda wrapping to hide calls", Severity.MEDIUM),
        NUMBER_OBFUSCATION("Number Obfuscation", "Numeric constants split/encoded", Severity.LOW),
        WATERMARK("Watermark/Fingerprint", "Hidden identifiers embedded in bytecode", Severity.INFO),
        DEBUG_INFO_STRIPPED("Debug Info Stripped", "Line numbers, local variable names removed", Severity.LOW);

        private final String displayName;
        private final String description;
        private final Severity severity;

        ProtectionType(String displayName, String description, Severity severity) {
            this.displayName = displayName;
            this.description = description;
            this.severity = severity;
        }

        public String getDisplayName() { return displayName; }
        public String getDescription() { return description; }
        public Severity getSeverity() { return severity; }
    }

    public enum Severity { INFO, LOW, MEDIUM, HIGH, CRITICAL }

    public record Protection(
            ProtectionType type,
            String details,
            Severity severity,
            List<String> affectedClasses,
            boolean removable) {}

    public record AnalysisResult(
            List<Protection> protections,
            String obfuscatorGuess,
            int totalClasses,
            int protectedClasses,
            double protectionScore,
            boolean decompilable,
            String summary) {

        public boolean hasProtections() {
            return !protections.isEmpty();
        }

        public int highSeverityCount() {
            return (int) protections.stream()
                    .filter(p -> p.severity() == Severity.HIGH || p.severity() == Severity.CRITICAL)
                    .count();
        }
    }

    private ProtectionAnalyzer() {
    }

    public static AnalysisResult analyze(JarFile jar) {
        List<Protection> protections = new ArrayList<>();
        int totalClasses = 0;
        int protectedClasses = 0;
        Set<String> obfuscatorHints = new HashSet<>();

        // Stats for heuristics
        int encryptedStrings = 0;
        int renamedClasses = 0;
        int invokeDynamicCount = 0;
        int reflectionCalls = 0;
        int nativeCalls = 0;
        int customClassLoaders = 0;
        int deadCodeBlocks = 0;
        int missingLineNumbers = 0;
        int totalMethods = 0;
        int methodsWithDebug = 0;
        Set<String> suspiciousClasses = new HashSet<>();
        Set<String> allClassNames = new HashSet<>();

        Enumeration<JarEntry> entries = jar.entries();
        while (entries.hasMoreElements()) {
            JarEntry entry = entries.nextElement();
            if (!entry.getName().endsWith(".class")) continue;
            totalClasses++;
            allClassNames.add(entry.getName().substring(0, entry.getName().length() - ".class".length()));

            try (InputStream is = jar.getInputStream(entry)) {
                byte[] bytes = is.readAllBytes();
                String className = entry.getName().replace('/', '.').replaceAll("\\.class$", "");

                ClassInfo info = analyzeClass(bytes, className);

                if (info.hasEncryptedStrings) {
                    encryptedStrings++;
                    suspiciousClasses.add(className);
                }
                if (info.isRenamed) renamedClasses++;
                invokeDynamicCount += info.invokeDynamicCount;
                reflectionCalls += info.reflectionCalls;
                nativeCalls += info.nativeCalls;
                if (info.isCustomClassLoader) customClassLoaders++;
                deadCodeBlocks += info.deadCodeBlocks;
                totalMethods += info.totalMethods;
                methodsWithDebug += info.methodsWithLineNumbers;

                if (info.hasEncryptedStrings || info.invokeDynamicCount > 5
                        || info.reflectionCalls > 3 || info.nativeCalls > 0) {
                    protectedClasses++;
                }

                if (info.obfuscatorHint != null) {
                    obfuscatorHints.add(info.obfuscatorHint);
                }
            } catch (IOException e) {
                log.debug("Cannot read {}: {}", entry.getName(), e.getMessage());
            }
        }

        // Detect protections based on analysis
        if (encryptedStrings > 0) {
            protections.add(new Protection(
                    ProtectionType.STRING_ENCRYPTION,
                    encryptedStrings + " classes with string encryption detected",
                    Severity.HIGH, new ArrayList<>(suspiciousClasses), true));
        }

        if (renamedClasses > totalClasses * 0.5 && totalClasses > 10) {
            protections.add(new Protection(
                    ProtectionType.CLASS_RENAMING,
                    renamedClasses + "/" + totalClasses + " classes have obfuscated names",
                    Severity.LOW, List.of(), true));
        }

        if (invokeDynamicCount > totalClasses) {
            protections.add(new Protection(
                    ProtectionType.INVOKE_DYNAMIC,
                    invokeDynamicCount + " InvokeDynamic instructions (avg " +
                            (invokeDynamicCount / Math.max(totalClasses, 1)) + " per class)",
                    Severity.MEDIUM, List.of(), true));
        }

        if (reflectionCalls > 10) {
            protections.add(new Protection(
                    ProtectionType.REFLECTION_HEAVY,
                    reflectionCalls + " reflective calls detected",
                    Severity.MEDIUM, List.of(), false));
        }

        if (nativeCalls > 0) {
            protections.add(new Protection(
                    ProtectionType.NATIVE_CODE,
                    nativeCalls + " native method references",
                    Severity.HIGH, List.of(), false));
        }

        if (customClassLoaders > 0) {
            protections.add(new Protection(
                    ProtectionType.CUSTOM_CLASSLOADER,
                    customClassLoaders + " custom ClassLoader implementations",
                    Severity.MEDIUM, List.of(), true));
        }

        // Debug info
        if (totalMethods > 0) {
            double debugRatio = (double) methodsWithDebug / totalMethods;
            if (debugRatio < 0.1) {
                protections.add(new Protection(
                        ProtectionType.DEBUG_INFO_STRIPPED,
                        String.format("%.0f%% methods missing line numbers", (1 - debugRatio) * 100),
                        Severity.LOW, List.of(), false));
            }
        }

        // Check for packing (unusual class file sizes)
        if (hasPackedClasses(jar)) {
            protections.add(new Protection(
                    ProtectionType.ZLIB_PACKING,
                    "Some class files have unusual size patterns — possible packing",
                    Severity.HIGH, List.of(), true));
        }

        // Точные сигнатуры обфускаторов из структуры jar (приоритетнее эвристики).
        obfuscatorHints.addAll(detectObfuscatorSignatures(jar, allClassNames));

        // Guess obfuscator
        String obfuscatorGuess = guessObfuscator(obfuscatorHints, protections);

        // Calculate score
        double score = 0;
        for (Protection p : protections) {
            score += switch (p.severity()) {
                case INFO -> 0.5;
                case LOW -> 1;
                case MEDIUM -> 3;
                case HIGH -> 5;
                case CRITICAL -> 10;
            };
        }
        score = Math.min(10, score);

        boolean decompilable = score < 5;

        String summary = buildSummary(protections, obfuscatorGuess, score, decompilable);

        return new AnalysisResult(protections, obfuscatorGuess, totalClasses,
                protectedClasses, score, decompilable, summary);
    }

    private static class ClassInfo {
        boolean hasEncryptedStrings;
        boolean isRenamed;
        int invokeDynamicCount;
        int reflectionCalls;
        int nativeCalls;
        boolean isCustomClassLoader;
        int deadCodeBlocks;
        int totalMethods;
        int methodsWithLineNumbers;
        String obfuscatorHint;
    }

    private static ClassInfo analyzeClass(byte[] bytes, String className) {
        ClassInfo info = new ClassInfo();

        // Check if class name is obfuscated
        String simpleName = className.contains(".") ?
                className.substring(className.lastIndexOf('.') + 1) : className;
        info.isRenamed = simpleName.matches("^[a-z]$") || simpleName.matches("^[0-9a-f]{4,}$")
                || simpleName.matches("^.{1,2}$") && simpleName.matches(".*[^a-zA-Z].*");

        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            private String currentClass;

            @Override
            public void visit(int version, int access, String name, String sig,
                              String superName, String[] interfaces) {
                currentClass = name;
                if ("java/lang/ClassLoader".equals(superName)
                        || "java/net/URLClassLoader".equals(superName)) {
                    info.isCustomClassLoader = true;
                }
                if (interfaces != null) {
                    for (String iface : interfaces) {
                        if (iface.contains("Serializable") && name.length() <= 3) {
                            info.obfuscatorHint = "ProGuard";
                        }
                    }
                }
            }

            @Override
            public MethodVisitor visitMethod(int access, String name, String desc,
                                              String signature, String[] exceptions) {
                info.totalMethods++;
                return new MethodVisitor(Opcodes.ASM9) {
                    @Override
                    public void visitLineNumber(int line, Label start) {
                        info.methodsWithLineNumbers++;
                    }

                    @Override
                    public void visitLdcInsn(Object value) {
                        if (value instanceof String s && s.length() > 20) {
                            // Check for base64 or hex patterns (encrypted strings)
                            if (s.matches("^[A-Za-z0-9+/=]{20,}$")
                                    || s.matches("^[0-9a-fA-F]{20,}$")) {
                                info.hasEncryptedStrings = true;
                            }
                        }
                    }

                    @Override
                    public void visitMethodInsn(int opcode, String owner, String mname,
                                                 String descriptor, boolean isInterface) {
                        if ("java/lang/Class".equals(owner) && "forName".equals(mname)) {
                            info.reflectionCalls++;
                        }
                        if ("java/lang/reflect".equals(owner)) {
                            info.reflectionCalls++;
                        }
                        if ("java/lang/Runtime".equals(owner) && "exec".equals(mname)) {
                            info.nativeCalls++;
                        }
                        if ("java/lang/System".equals(owner) && "loadLibrary".equals(mname)) {
                            info.nativeCalls++;
                        }
                    }

                    @Override
                    public void visitInvokeDynamicInsn(String name, String descriptor,
                                                        Handle bootstrapMethodHandle,
                                                        Object... bootstrapMethodArguments) {
                        info.invokeDynamicCount++;
                    }

                    @Override
                    public void visitJumpInsn(int opcode, Label label) {
                        // Detect opaque predicates (always-true/false jumps)
                        if (opcode == Opcodes.GOTO) {
                            info.deadCodeBlocks++;
                        }
                    }
                };
            }
        }, ClassReader.SKIP_FRAMES);

        return info;
    }

    private static boolean hasPackedClasses(JarFile jar) {
        int tinyCount = 0;
        int hugeCount = 0;
        int total = 0;
        Enumeration<JarEntry> entries = jar.entries();
        while (entries.hasMoreElements()) {
            JarEntry entry = entries.nextElement();
            if (!entry.getName().endsWith(".class")) continue;
            total++;
            long size = entry.getSize();
            if (size > 0 && size < 100) tinyCount++;
            if (size > 500000) hugeCount++;
        }
        return total > 10 && (tinyCount > total * 0.3 || hugeCount > 0);
    }

    private static String guessObfuscator(Set<String> hints, List<Protection> protections) {
        // Точные сигнатуры (из jar-структуры) имеют приоритет над эвристикой.
        for (String known : List.of("Allatori", "Zelix KlassMaster", "ProGuard", "R8",
                "Stringer", "Radon", "Skidfuscator", "Branchlock", "yGuard")) {
            if (hints.contains(known)) {
                return known;
            }
        }
        // Падение на поведенческую эвристику, если явных меток нет.
        boolean hasStringEnc = protections.stream()
                .anyMatch(p -> p.type() == ProtectionType.STRING_ENCRYPTION);
        boolean hasInvokeDynamic = protections.stream()
                .anyMatch(p -> p.type() == ProtectionType.INVOKE_DYNAMIC);
        boolean hasClassRename = protections.stream()
                .anyMatch(p -> p.type() == ProtectionType.CLASS_RENAMING);

        if (hasStringEnc && hasInvokeDynamic) {
            return "Allatori / Zelix KlassMaster (по поведению)";
        }
        if (hasStringEnc) {
            return "Stringer / SimpleObfuscator (по поведению)";
        }
        if (hasInvokeDynamic && hasClassRename) {
            return "Radon / Smoke (по поведению)";
        }
        if (hasClassRename) {
            return "ProGuard / R8 (по поведению)";
        }
        return "Unknown / None";
    }

    /**
     * Детектирует конкретные обфускаторы по их «отпечаткам» на уровне jar:
     * атрибутах манифеста, классах-маркерах, характерных именах и структуре.
     * Это точнее поведенческой эвристики — обфускаторы оставляют узнаваемые следы.
     *
     * <p>Только распознавание (для честного предупреждения пользователя),
     * без какого-либо обхода или снятия защиты.</p>
     *
     * @param jar          анализируемый архив
     * @param classNames   множество имён классов (internal, со слэшами, без .class)
     * @return метки найденных обфускаторов (могут совпадать с именами в {@code guessObfuscator})
     */
    private static Set<String> detectObfuscatorSignatures(JarFile jar, Set<String> classNames) {
        Set<String> found = new HashSet<>();

        // 1) Манифест: некоторые обфускаторы прописывают свои атрибуты.
        try {
            Manifest mf = jar.getManifest();
            if (mf != null) {
                var attrs = mf.getMainAttributes();
                for (Object keyObj : attrs.keySet()) {
                    String key = keyObj.toString().toLowerCase(Locale.ROOT);
                    if (key.contains("allatori")) {
                        found.add("Allatori");
                    }
                    if (key.contains("zelix") || key.contains("zkm")) {
                        found.add("Zelix KlassMaster");
                    }
                    if (key.contains("stringer")) {
                        found.add("Stringer");
                    }
                    if (key.contains("yguard")) {
                        found.add("yGuard");
                    }
                }
                // ProGuard/R8 убирают почти все атрибуты, но R8 часто оставляет
                // "Dex" / специфичные значения в "Created-By".
                String createdBy = String.valueOf(attrs.getValue("Created-By"))
                        .toLowerCase(Locale.ROOT);
                if (createdBy.contains("r8")) {
                    found.add("R8");
                } else if (createdBy.contains("proguard")) {
                    found.add("ProGuard");
                }
            }
        } catch (IOException e) {
            log.debug("Манифест не прочитан: {}", e.getMessage());
        }

        // 2) Классы-/файлы-маркеры, которые кладут конкретные обфускаторы.
        for (String name : classNames) {
            String lower = name.toLowerCase(Locale.ROOT);
            // Allatori: рантайм-хелпер расшифровки строк.
            if (lower.contains("allatori")) {
                found.add("Allatori");
            }
            // Zelix: классы-декрипторы вида "ZKM_*" или одиночные методы exception-driven flow.
            if (name.startsWith("ZKM") || lower.contains("zelix")) {
                found.add("Zelix KlassMaster");
            }
            // Stringer: рантайм-класс обычно в пакете com/stringer или sun/security-подделке.
            if (lower.contains("stringer")) {
                found.add("Stringer");
            }
            // Skidfuscator/Radon: характерные классы-диспетчеры.
            if (lower.contains("skidfuscator")) {
                found.add("Skidfuscator");
            }
            if (lower.contains("radon")) {
                found.add("Radon");
            }
            // Branchlock: онлайн-обфускатор оставляет метку в имени пакета.
            if (lower.contains("branchlock")) {
                found.add("Branchlock");
            }
        }

        // 3) Файлы-маркеры в архиве (не классы).
        Enumeration<JarEntry> entries = jar.entries();
        while (entries.hasMoreElements()) {
            String entryName = entries.nextElement().getName().toLowerCase(Locale.ROOT);
            if (entryName.contains("allatori")) {
                found.add("Allatori");
            }
            if (entryName.equals("meta-inf/zkm.txt") || entryName.contains("zelix")) {
                found.add("Zelix KlassMaster");
            }
            if (entryName.contains("proguard") && entryName.endsWith(".txt")) {
                found.add("ProGuard");
            }
        }

        return found;
    }

    private static String buildSummary(List<Protection> protections, String obfuscator,
                                        double score, boolean decompilable) {
        if (protections.isEmpty()) {
            return "No protection mechanisms detected. JAR is clean and ready for migration.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Protection score: ").append(String.format("%.1f", score)).append("/10");
        sb.append(" | Obfuscator: ").append(obfuscator);
        sb.append(" | Decompilable: ").append(decompilable ? "Yes" : "Likely problematic");
        sb.append("\n");
        sb.append(protections.size()).append(" protection mechanism(s) found:\n");
        for (Protection p : protections) {
            sb.append("  [").append(p.severity()).append("] ")
                    .append(p.type().getDisplayName()).append(": ")
                    .append(p.details()).append("\n");
        }
        return sb.toString();
    }
}
