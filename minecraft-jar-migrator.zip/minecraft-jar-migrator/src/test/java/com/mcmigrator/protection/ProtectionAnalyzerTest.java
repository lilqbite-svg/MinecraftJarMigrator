package com.mcmigrator.protection;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Проверяет распознавание конкретных обфускаторов по их следам в jar.
 * Тесты только на ДЕТЕКЦИЮ (никакого обхода защиты).
 */
class ProtectionAnalyzerTest {

    @Test
    void detectsAllatoriFromManifest(@TempDir Path dir) throws IOException {
        Manifest mf = new Manifest();
        mf.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        mf.getMainAttributes().putValue("Allatori-Obfuscation", "true");
        Path jar = dir.resolve("allatori.jar");
        writeJarWithManifest(jar, mf, "com/example/Main.class");

        try (JarFile jf = new JarFile(jar.toFile())) {
            var result = ProtectionAnalyzer.analyze(jf);
            assertEquals("Allatori", result.obfuscatorGuess());
        }
    }

    @Test
    void detectsZelixFromMarkerFile(@TempDir Path dir) throws IOException {
        Path jar = dir.resolve("zelix.jar");
        try (JarOutputStream out = new JarOutputStream(Files.newOutputStream(jar))) {
            out.putNextEntry(new JarEntry("META-INF/ZKM.txt"));
            out.write("Zelix KlassMaster".getBytes(StandardCharsets.UTF_8));
            out.closeEntry();
            out.putNextEntry(new JarEntry("a/b/C.class"));
            out.write(new byte[]{(byte) 0xCA, (byte) 0xFE, (byte) 0xBA, (byte) 0xBE});
            out.closeEntry();
        }
        try (JarFile jf = new JarFile(jar.toFile())) {
            var result = ProtectionAnalyzer.analyze(jf);
            assertEquals("Zelix KlassMaster", result.obfuscatorGuess());
        }
    }

    @Test
    void detectsR8FromCreatedBy(@TempDir Path dir) throws IOException {
        Manifest mf = new Manifest();
        mf.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        mf.getMainAttributes().putValue("Created-By", "R8");
        Path jar = dir.resolve("r8.jar");
        writeJarWithManifest(jar, mf, "x/Y.class");

        try (JarFile jf = new JarFile(jar.toFile())) {
            var result = ProtectionAnalyzer.analyze(jf);
            assertEquals("R8", result.obfuscatorGuess());
        }
    }

    @Test
    void cleanJarReportsNoObfuscator(@TempDir Path dir) throws IOException {
        Manifest mf = new Manifest();
        mf.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        Path jar = dir.resolve("clean.jar");
        writeJarWithManifest(jar, mf, "com/example/CleanMod.class");

        try (JarFile jf = new JarFile(jar.toFile())) {
            var result = ProtectionAnalyzer.analyze(jf);
            assertNotNull(result.obfuscatorGuess());
            assertTrue(result.obfuscatorGuess().contains("Unknown")
                            || result.obfuscatorGuess().contains("None"),
                    "чистый jar не должен опознаваться как обфусцированный, получили: "
                            + result.obfuscatorGuess());
        }
    }

    private static void writeJarWithManifest(Path jar, Manifest mf, String classEntry)
            throws IOException {
        try (JarOutputStream out = new JarOutputStream(Files.newOutputStream(jar), mf)) {
            out.putNextEntry(new JarEntry(classEntry));
            // Минимальный валидный заголовок class-файла (магия + версия).
            out.write(new byte[]{(byte) 0xCA, (byte) 0xFE, (byte) 0xBA, (byte) 0xBE,
                    0x00, 0x00, 0x00, 0x34});
            out.closeEntry();
        }
    }
}
