@echo off
rem ============================================================
rem  Сборка автономного Windows-приложения MinecraftJarMigrator
rem  со ВСТРОЕННОЙ Java — пользователю ничего ставить не нужно.
rem
rem  Требования только для СБОРКИ (не для пользователя!):
rem    - JDK 17+ (в нём уже есть jpackage и jlink)
rem    - интернет (зависимости; Gradle скачается сам, если его нет)
rem
rem  Результат: build\dist\MinecraftJarMigrator\MinecraftJarMigrator.exe
rem  Эту папку можно заархивировать и раздавать — запускается
rem  двойным кликом на любом Windows без установленной Java.
rem ============================================================

setlocal
chcp 65001 >nul
cd /d "%~dp0"
set GRADLE_VERSION=9.5.1
set GRADLE_CMD=

echo [1/3] Ищу Gradle...
rem 1) wrapper в проекте  2) gradle из PATH  3) скачиваю сам
if exist gradlew.bat (
  set GRADLE_CMD=call gradlew.bat
  goto :gradle_found
)
where gradle >nul 2>nul && (
  set GRADLE_CMD=call gradle
  goto :gradle_found
)
rem Заранее скачанный архив рядом со скриптом тоже подходит (на случай проблем с сетью)
if exist "gradle-%GRADLE_VERSION%-bin.zip" if not exist "build\gradle.zip" (
  if not exist build mkdir build
  copy /y "gradle-%GRADLE_VERSION%-bin.zip" build\gradle.zip >nul
)
if not exist build\gradle-dist\gradle-%GRADLE_VERSION%\bin\gradle.bat (
  set NEED_DL=
  if not exist build\gradle.zip set NEED_DL=1
  if exist build\gradle.zip for %%A in (build\gradle.zip) do if %%~zA LSS 130000000 set NEED_DL=1
  if defined NEED_DL (
    echo Скачиваю Gradle %GRADLE_VERSION% (~134 МБ, до 5 попыток, докачка с места обрыва^)...
    if not exist build mkdir build
    where curl.exe >nul 2>nul
    if not errorlevel 1 (
      curl.exe -L --fail -C - --retry 5 --retry-all-errors --retry-delay 3 -o build\gradle.zip "https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
    ) else (
      powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; $ok=$false; for($i=1;$i -le 3 -and -not $ok;$i++){ try { Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile 'build\gradle.zip'; $ok=$true } catch { Write-Host ('Попытка ' + $i + ' не удалась, повтор...'); Start-Sleep 3 } }; if(-not $ok){ exit 1 }"
    )
  )
  if not exist build\gradle.zip goto :gradle_dl_fail
  for %%A in (build\gradle.zip) do if %%~zA LSS 130000000 (
    echo Архив скачан не полностью (%%~zA байт из ~134 МБ^) — обрыв соединения.
    echo Файл сохранён: повторный запуск ДОКАЧАЕТ его с места обрыва.
    goto :gradle_dl_fail
  )
  echo Распаковываю Gradle...
  powershell -NoProfile -Command ^
    "$ErrorActionPreference='Stop'; Expand-Archive -Force 'build\gradle.zip' 'build\gradle-dist'" || (del build\gradle.zip & goto :gradle_dl_fail)
  del build\gradle.zip
)
if not exist build\gradle-dist\gradle-%GRADLE_VERSION%\bin\gradle.bat goto :gradle_dl_fail
set GRADLE_CMD=call build\gradle-dist\gradle-%GRADLE_VERSION%\bin\gradle.bat
:gradle_found
echo Использую: %GRADLE_CMD:call =%

echo [2/3] Собираю fat-jar...
%GRADLE_CMD% shadowJar || goto :error

echo [3/3] Упаковываю в .exe со встроенной Java (jlink + jpackage)...

rem --- Ищу JDK с jpackage: JAVA_HOME -> рядом с java.exe -> Program Files -> PATH ---
rem (важно брать jlink и jpackage из ОДНОГО JDK, иначе рантайм может не запуститься)
set JDK_BIN=
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\jpackage.exe" set "JDK_BIN=%JAVA_HOME%\bin\"
if not defined JDK_BIN (
  for /f "delims=" %%j in ('where java 2^>nul') do (
    if not defined JDK_BIN if exist "%%~dpjjpackage.exe" set "JDK_BIN=%%~dpj"
  )
)
if not defined JDK_BIN (
  rem Берём самый новый JDK: перебор без остановки — последний (старшая версия) побеждает
  for /d %%d in ("%ProgramFiles%\Java\jdk*" "%ProgramFiles%\Eclipse Adoptium\jdk*" "%ProgramFiles%\Microsoft\jdk*" "%ProgramFiles%\Amazon Corretto\jdk*" "%ProgramFiles%\Zulu\zulu*" "%ProgramFiles%\BellSoft\Liberica*") do (
    if exist "%%d\bin\jpackage.exe" set "JDK_BIN=%%d\bin\"
  )
)
if not defined JDK_BIN (
  for /f "delims=" %%j in ('where jpackage 2^>nul') do (
    if not defined JDK_BIN set "JDK_BIN=%%~dpj"
  )
)
if not defined JDK_BIN (
  echo ОШИБКА: jpackage не найден. Он входит в JDK 17+.
  echo Укажите путь к JDK через переменную JAVA_HOME, например:
  echo   set "JAVA_HOME=C:\Program Files\Java\jdk-26"
  echo и запустите скрипт снова.
  goto :error
)
echo Использую JDK: %JDK_BIN%

rem --- Явно собираю встроенный рантайм со всеми нужными модулями ---
if exist build\runtime-image rmdir /s /q build\runtime-image
"%JDK_BIN%jlink.exe" ^
  --add-modules java.base,java.desktop,java.logging,java.management,java.naming,java.net.http,java.sql,java.xml,jdk.compiler,jdk.zipfs,jdk.crypto.ec,jdk.unsupported ^
  --strip-debug --no-header-files --no-man-pages ^
  --output build\runtime-image || goto :error

if exist build\dist rmdir /s /q build\dist
if exist build\jpackage-input rmdir /s /q build\jpackage-input
mkdir build\jpackage-input
copy /y build\libs\migrator.jar build\jpackage-input\ >nul || goto :error

"%JDK_BIN%jpackage.exe" ^
  --type app-image ^
  --name MinecraftJarMigrator ^
  --app-version 1.0.0 ^
  --vendor mcmigrator ^
  --runtime-image build\runtime-image ^
  --input build\jpackage-input ^
  --main-jar migrator.jar ^
  --main-class com.mcmigrator.Main ^
  --java-options "-Xmx2g" ^
  --java-options "-Dfile.encoding=UTF-8" ^
  --dest build\dist || goto :error

echo.
echo Готово! Запускайте: build\dist\MinecraftJarMigrator\MinecraftJarMigrator.exe
echo Всю папку MinecraftJarMigrator можно копировать/раздавать как есть.
echo.
echo (Опционально: чтобы собрать установщик .exe одним файлом, установите
echo  WiX Toolset 3.x и замените "--type app-image" на "--type exe".)
goto :eof

:gradle_dl_fail
echo.
echo Не удалось скачать Gradle (сеть/антивирус/VPN^).
echo Решения:
echo   1^) Запустите скрипт ещё раз — докачка продолжится с места обрыва.
echo   2^) Скачайте архив браузером:
echo      https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
echo      и положите файл РЯДОМ с build-exe.bat (не распаковывая^), затем перезапустите.
echo   3^) Если есть старая папка проекта со скачанным Gradle — скопируйте из неё build\gradle-dist.
goto :error

:error
echo.
echo СБОРКА НЕ УДАЛАСЬ — см. сообщения выше.
exit /b 1
