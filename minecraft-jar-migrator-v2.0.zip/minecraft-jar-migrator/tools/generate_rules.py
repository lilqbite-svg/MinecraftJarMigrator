#!/usr/bin/env python3
"""Генератор JSON-правил миграции для всех пар версий Minecraft 1.14.4..26.1.2.

Правило пары (A -> C) = объединение правил всех последовательных переходов
между A и C, плюс токен-зависимые правила (CraftBukkit/NMS), параметризованные
токеном версии A. Запуск:  python3 tools/generate_rules.py
"""
import itertools
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "src/main/resources/rules"

# 42 релиза от 1.14.4 до 26.1.2 (июнь 2026), в порядке выхода.
VERSIONS = [
    "1.14.4",
    "1.15", "1.15.1", "1.15.2",
    "1.16", "1.16.1", "1.16.2", "1.16.3", "1.16.4", "1.16.5",
    "1.17", "1.17.1",
    "1.18", "1.18.1", "1.18.2",
    "1.19", "1.19.1", "1.19.2", "1.19.3", "1.19.4",
    "1.20", "1.20.1", "1.20.2", "1.20.3", "1.20.4", "1.20.5", "1.20.6",
    "1.21", "1.21.1", "1.21.2", "1.21.3", "1.21.4", "1.21.5", "1.21.6",
    "1.21.7", "1.21.8", "1.21.9", "1.21.10", "1.21.11",
    "26.1", "26.1.1", "26.1.2",
]
IDX = {v: i for i, v in enumerate(VERSIONS)}

# CraftBukkit/NMS токен каждой версии (None = релокации нет: 26.1+).
TOKENS = {
    "1.14.4": "v1_14_R1",
    "1.15": "v1_15_R1", "1.15.1": "v1_15_R1", "1.15.2": "v1_15_R1",
    "1.16": "v1_16_R1", "1.16.1": "v1_16_R1",
    "1.16.2": "v1_16_R2", "1.16.3": "v1_16_R2",
    "1.16.4": "v1_16_R3", "1.16.5": "v1_16_R3",
    "1.17": "v1_17_R1", "1.17.1": "v1_17_R1",
    "1.18": "v1_18_R1", "1.18.1": "v1_18_R1", "1.18.2": "v1_18_R2",
    "1.19": "v1_19_R1", "1.19.1": "v1_19_R1", "1.19.2": "v1_19_R1",
    "1.19.3": "v1_19_R2", "1.19.4": "v1_19_R3",
    "1.20": "v1_20_R1", "1.20.1": "v1_20_R1",
    "1.20.2": "v1_20_R2", "1.20.3": "v1_20_R3", "1.20.4": "v1_20_R3",
    "1.20.5": "v1_20_R4", "1.20.6": "v1_20_R4",
    "1.21": "v1_21_R1", "1.21.1": "v1_21_R1",
    "1.21.2": "v1_21_R2", "1.21.3": "v1_21_R2", "1.21.4": "v1_21_R3",
    "1.21.5": "v1_21_R4", "1.21.6": "v1_21_R5", "1.21.7": "v1_21_R5",
    "1.21.8": "v1_21_R5", "1.21.9": "v1_21_R6", "1.21.10": "v1_21_R6",
    "1.21.11": "v1_21_R7",
    "26.1": None, "26.1.1": None, "26.1.2": None,
}

def mr(cls, old, new, comment):
    return {"className": cls, "oldMethod": old, "newMethod": new, "comment": comment}

def br(desc, pattern, fix):
    return {"description": desc, "matchPattern": pattern, "suggestedFix": fix}

# Токен-НЕзависимые правила последовательных переходов (источник — исследование
# по Paper/Spigot changelog, jd.papermc.io, minecraft.wiki; июнь 2026).
TRANSITIONS = {
    ("1.16.5", "1.17"): {
        "apiBreakingChanges": [
            br("Forge перешёл на официальные Mojang-маппинги (1.17)",
               r"func_\d+_[A-Za-z_]*|field_\d+_[A-Za-z_]*",
               "SRG/MCP-имена (func_xxx/field_xxx) заменены официальными именами Mojang"),
        ],
    },
    ("1.19.2", "1.19.3"): {
        "apiBreakingChanges": [
            br("Статические реестры переехали в BuiltInRegistries (1.19.3, MojMap)",
               r"\bRegistry\.(ITEM|BLOCK|ENTITY_TYPE|BIOME|FLUID|SOUND_EVENT|POTION|ENCHANTMENT)\b",
               "net.minecraft.core.registries.BuiltInRegistries.* вместо Registry.* "
               "(затрагивает Fabric/Forge/NMS-моды на Mojang-маппингах)"),
        ],
    },
    ("1.20.1", "1.20.2"): {
        "apiBreakingChanges": [
            br("NeoForge отделился от Forge и сменил пакеты (1.20.2)",
               r"net\.minecraftforge\.",
               "NeoForge 1.20.2+: net.neoforged.* (события, бас, API); "
               "классический Forge остаётся net.minecraftforge — выберите лоадер"),
        ],
    },
    ("1.17.1", "1.18"): {
        "apiBreakingChanges": [
            br("Высота мира расширена до -64..320 (1.18)",
               r"\bgetMaxHeight\(\)|\b256\b",
               "Не используйте константы 0/256: World.getMinHeight()/getMaxHeight()"),
        ],
    },
    ("1.18.2", "1.19"): {
        "apiBreakingChanges": [
            br("AsyncPlayerChatEvent устарел (chat signing, 1.19)",
               r"\bAsyncPlayerChatEvent\b",
               "Перейти на io.papermc.paper.event.player.AsyncChatEvent с Adventure Component"),
        ],
    },
    ("1.20.3", "1.20.4"): {
        "apiBreakingChanges": [
            br("EntityDamageEvent: конструкторы без DamageSource устарели (1.20.4)",
               r"new\s+EntityDamage(ByEntity|ByBlock)?Event\(",
               "Использовать конструкторы с org.bukkit.damage.DamageSource"),
            br("NeoForge: RegistryObject заменён на DeferredHolder (1.20.4)",
               r"\bRegistryObject\b",
               "NeoForge: DeferredHolder/DeferredItem/DeferredBlock из DeferredRegister"),
        ],
    },
    ("1.20.4", "1.20.5"): {
        "methodRenames": [
            mr("org.bukkit.inventory.meta.PotionMeta", "getBasePotionData", "getBasePotionType",
               "extended/upgraded зелья стали отдельными PotionType (1.20.5)"),
            mr("org.bukkit.inventory.meta.PotionMeta", "setBasePotionData", "setBasePotionType",
               "extended/upgraded зелья стали отдельными PotionType (1.20.5)"),
            mr("org.bukkit.entity.Arrow", "getBasePotionData", "getBasePotionType",
               "PotionData заменён на PotionType (1.20.5)"),
            mr("org.bukkit.entity.AreaEffectCloud", "getBasePotionData", "getBasePotionType",
               "PotionData заменён на PotionType (1.20.5)"),
        ],
        "apiBreakingChanges": [
            br("NBT-тег предметов заменён на data components (1.20.5)",
               r"\bNBTTagCompound\b|\.getTag\(\)|\.setTag\(|\bCompoundTag\b",
               "Data Component API: ItemStack.getData/setData с DataComponentTypes; "
               "произвольные данные — в minecraft:custom_data"),
            br("AttributeModifier на UUID устарел (1.20.5/1.21)",
               r"new\s+AttributeModifier\(\s*UUID|AttributeModifier\.getUniqueId\(",
               "AttributeModifier(NamespacedKey, double, Operation, EquipmentSlotGroup); getKey()"),
            br("Редкости и категории зачарований удалены (1.20.5)",
               r"\.getRarity\(\)|\bEnchantmentTarget\b|\.getItemTarget\(",
               "Группировки зачарований теперь через теги и Registry"),
            br("ItemMeta canDestroy/canPlaceOn удалены (1.20.5)",
               r"etCanDestroy\(|etCanPlaceOn\(|etDestroyableKeys\(|etPlaceableKeys\(",
               "DataComponentTypes.CAN_BREAK / CAN_PLACE_ON через ItemStack.getData/setData"),
            br("Paper 1.20.5+ исполняется на Mojang-маппингах",
               r"\bEntityHuman\b|\bPacketPlayIn|\bPacketPlayOut",
               "Заменить Spigot-имена NMS на Mojang (ServerPlayer, Serverbound*/Clientbound*)"),
            br("String-методы интерфейса заменены Adventure API",
               r"\.setDisplayName\(|\.setLore\(|\.setPlayerListName\(|\.setLocalizedName\(",
               "Adventure: displayName(Component), lore(List<Component>), playerListName(Component)"),
            br("Fabric: FabricItemSettings устарел (1.20.5)",
               r"\bFabricItemSettings\b",
               "Использовать ванильный Item.Settings / Item.Properties"),
        ],
    },
    ("1.20.6", "1.21"): {
        "apiBreakingChanges": [
            br("Рецепты оборачиваются в RecipeHolder (1.21, NMS)",
               r"\bRecipeType\b|\.getRecipeFor\(",
               "Методы рецептов возвращают RecipeHolder<...>; доставать рецепт через holder.value()"),
            br("Зачарования стали data-driven (1.21)",
               r"Enchantment\.getByName\(|Enchantment\.getByKey\(",
               "Registry.ENCHANTMENT.get(NamespacedKey) / RegistryAccess (Paper)"),
            br("World.regenerateChunk удалён (1.21)",
               r"\.regenerateChunk\(",
               "Метод удалён без замены — пересоздавать чанк средствами генератора"),
            br("Biome и подобные перестали быть enum (1.21)",
               r"Biome\.values\(\)|EnumSet\.(of|allOf)\(\s*Biome",
               "Итерироваться через Registry.BIOME, не через enum"),
            br("Регистрация команд переходит на Brigadier (Paper 1.21)",
               r"implements\s+CommandExecutor|\.getCommand\(\s*\"",
               "LifecycleEvents.COMMANDS + io.papermc.paper.command.brigadier.Commands "
               "(старый способ пока работает, но устаревает)"),
            br("Зачарования стали Holder<Enchantment> из реестра (1.21, MojMap/Fabric/NeoForge)",
               r"\bEnchantments\.[A-Z_]+|EnchantmentHelper\.get",
               "Получать Holder<Enchantment> через RegistryAccess/HolderLookup"),
        ],
    },
    ("1.21.1", "1.21.2"): {
        "apiBreakingChanges": [
            br("TeleportFlag.Relative переименованы (1.21.2)",
               r"TeleportFlag\.Relative\.",
               "X/Y/Z/YAW/PITCH -> VELOCITY_X/VELOCITY_Y/VELOCITY_Z/VELOCITY_ROTATION"),
            br("Разные лодки стали разными EntityType (1.21.2)",
               r"EntityType\.BOAT\b|EntityType\.CHEST_BOAT\b|\bBoat\.Type\b",
               "Использовать конкретные типы: EntityType.OAK_BOAT, OAK_CHEST_BOAT и т.д."),
        ],
    },
    ("1.21.3", "1.21.4"): {
        "apiBreakingChanges": [
            br("Paper отделился от Spigot — хардфорк (1.21.4)",
               r"org\.spigotmc\.",
               "Проверить Spigot-специфичные API на Paper; часть может отсутствовать"),
        ],
    },
    ("1.21.8", "1.21.9"): {
        "apiBreakingChanges": [
            br("GameRule SPAWN_CHUNK_RADIUS удалён (1.21.9)",
               r"SPAWN_CHUNK_RADIUS",
               "Правило удалено — убрать обращения"),
        ],
    },
    ("1.21.10", "1.21.11"): {
        "apiBreakingChanges": [
            br("Игровые правила перенесены в реестр и переименованы в snake_case (1.21.11)",
               r"GameRule\.[A-Z_]+|setGameRule\(|getGameRuleValue\(",
               "Например announceAdvancements -> minecraft:show_advancement_messages; "
               "использовать новый GameRules API"),
        ],
    },
    ("1.21.11", "26.1"): {
        "apiBreakingChanges": [
            br("Сервер полностью деобфусцирован, Spigot-маппинги мертвы (26.1)",
               r"\bEntityHuman\b|\bPacketPlayIn|\bPacketPlayOut|\bWorldServer\b|\bEntityLiving\b",
               "Использовать только Mojang-имена; reobf-сборки больше не работают"),
            br("Нумерация версий сменилась на год.дроп (26.1)",
               r"(startsWith|equals|contains)\(\s*\"1\.",
               "Не парсить префикс \"1.\" — версии теперь вида 26.1; Bukkit.getMinecraftVersion()"),
            br("Fabric: intermediary-имена уходят вместе с обфускацией (26.1)",
               r"\bclass_\d+\b|\bmethod_\d+\b|\bfield_\d+\b",
               "Использовать официальные имена Mojang вместо intermediary (рефлексия, mixin-цели)"),
        ],
    },
}

# Ключевые NMS-классы: до 1.17 живут в net.minecraft.server.{TOKEN},
# после — в Mojang-пакетах (Mojang-маппинги).
NMS_1_17_RENAMES = [
    ("EntityPlayer", "net.minecraft.server.level.ServerPlayer"),
    ("WorldServer", "net.minecraft.server.level.ServerLevel"),
    ("EntityLiving", "net.minecraft.world.entity.LivingEntity"),
    ("Entity", "net.minecraft.world.entity.Entity"),
    ("World", "net.minecraft.world.level.Level"),
    ("PlayerConnection", "net.minecraft.server.network.ServerGamePacketListenerImpl"),
    ("MinecraftServer", "net.minecraft.server.MinecraftServer"),
    ("ItemStack", "net.minecraft.world.item.ItemStack"),
    ("NBTTagCompound", "net.minecraft.nbt.CompoundTag"),
]


def build_pair(a: str, c: str) -> dict:
    ia, ic = IDX[a], IDX[c]
    methods, classes, packages, breaking = [], [], [], []

    # 1. Токен-независимые правила всех переходов в диапазоне (a..c].
    for (f, t), rules in TRANSITIONS.items():
        if ia < IDX[t] <= ic:
            methods += rules.get("methodRenames", [])
            classes += rules.get("classRenames", [])
            packages += rules.get("packageMoves", [])
            breaking += rules.get("apiBreakingChanges", [])

    tok_a, tok_c = TOKENS[a], TOKENS[c]

    # 2. NMS-реструктуризация 1.17 (если диапазон её пересекает).
    if ia < IDX["1.17"] <= ic and tok_a:
        for old_simple, new_fqn in NMS_1_17_RENAMES:
            classes.append({"oldName": f"net.minecraft.server.{tok_a}.{old_simple}",
                            "newName": new_fqn})
        breaking.append(br(
            "NMS-пакет потерял версию и разделился (1.17)",
            r"net\.minecraft\.server\.v1_\d+_R\d+",
            "Классы разъехались по net.minecraft.* (Mojang-маппинги); ремап покрывает не всё"))

    # 3. CraftBukkit-токен.
    if tok_a and tok_a != tok_c:
        pat = r"org\.bukkit\.craftbukkit\." + re.escape(tok_a)
        if tok_c is None:
            packages.append({"oldPackage": f"org.bukkit.craftbukkit.{tok_a}",
                             "newPackage": "org.bukkit.craftbukkit"})
            breaking.append(br(
                f"CraftBukkit-пакет больше не версионируется (с 26.1 везде, на Paper — с 1.20.5)",
                pat, "Пакет org.bukkit.craftbukkit без токена; версию брать из "
                     "Bukkit.getMinecraftVersion(), не из имени пакета"))
        elif IDX[c] >= IDX["1.20.5"]:
            packages.append({"oldPackage": f"org.bukkit.craftbukkit.{tok_a}",
                             "newPackage": "org.bukkit.craftbukkit"})
            breaking.append(br(
                f"CraftBukkit: на Paper 1.20.5+ релокация удалена (на Spigot токен {tok_c})",
                pat, f"Paper: пакет без токена; Spigot: заменить {tok_a} на {tok_c}; "
                     "версию определять через Bukkit.getMinecraftVersion()"))
        else:
            packages.append({"oldPackage": f"org.bukkit.craftbukkit.{tok_a}",
                             "newPackage": f"org.bukkit.craftbukkit.{tok_c}"})
            breaking.append(br(
                f"CraftBukkit-токен сменился: {tok_a} -> {tok_c}",
                pat, f"Заменить {tok_a} на {tok_c} (рефлексия, Class.forName и т.п.)"))

    def dedupe(items):
        seen, out = set(), []
        for it in items:
            key = json.dumps(it, sort_keys=True, ensure_ascii=False)
            if key not in seen:
                seen.add(key)
                out.append(it)
        return out

    return {
        "version": f"{a}-to-{c}",
        "methodRenames": dedupe(methods),
        "classRenames": dedupe(classes),
        "packageMoves": dedupe(packages),
        "apiBreakingChanges": dedupe(breaking),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    total = empty = 0
    for a, c in itertools.combinations(VERSIONS, 2):
        rules = build_pair(a, c)
        if not any(rules[k] for k in
                   ("methodRenames", "classRenames", "packageMoves", "apiBreakingChanges")):
            empty += 1
        (OUT / f"{a}-to-{c}.json").write_text(
            json.dumps(rules, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        total += 1
    print(f"Сгенерировано {total} файлов правил ({empty} без изменений) в {OUT}")


if __name__ == "__main__":
    main()
