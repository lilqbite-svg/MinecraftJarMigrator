package com.mcmigrator;

import com.mcmigrator.decompiler.DecompilerType;
import com.mcmigrator.pipeline.MigrationConfig;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MigrationConfigTest {

    @Test
    void defaultConfigHasVineflowerDecompiler() {
        MigrationConfig config = new MigrationConfig(
                Path.of("in.jar"), Path.of("out.jar"),
                "1.20.3", "1.21.1", ModType.PAPER,
                false, false, Path.of("/tmp/mappings"),
                List.of(), true);
        assertEquals(DecompilerType.VINEFLOWER, config.decompilerType());
        assertTrue(config.decompileCache());
    }

    @Test
    void configWithDisabledRules() {
        MigrationConfig config = new MigrationConfig(
                Path.of("in.jar"), Path.of("out.jar"),
                "1.20.3", "1.21.1", ModType.FABRIC,
                true, false, Path.of("/tmp/mappings"),
                List.of(), true, List.of("rule1", "rule2"));
        assertEquals(2, config.disabledRules().size());
        assertTrue(config.disabledRules().contains("rule1"));
    }

    @Test
    void newModTypes() {
        assertEquals(ModType.NEOFORGE, ModType.fromString("neoforge"));
        assertEquals(ModType.QUILT, ModType.fromString("quilt"));
        assertEquals(ModType.FORGE, ModType.fromString("forge"));
    }
}
