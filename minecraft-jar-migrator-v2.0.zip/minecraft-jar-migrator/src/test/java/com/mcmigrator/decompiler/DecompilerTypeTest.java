package com.mcmigrator.decompiler;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DecompilerTypeTest {

    @Test
    void allTypesHaveDisplayNames() {
        for (DecompilerType type : DecompilerType.values()) {
            assertNotNull(type.getDisplayName());
            assertFalse(type.getDisplayName().isEmpty());
        }
    }

    @Test
    void vineflowerIsDefault() {
        assertEquals(DecompilerType.VINEFLOWER, DecompilerType.valueOf("VINEFLOWER"));
    }

    @Test
    void cfrIsAvailable() {
        assertNotNull(DecompilerType.CFR);
        assertTrue(DecompilerType.CFR.getDisplayName().contains("CFR"));
    }

    @Test
    void procyonIsAvailable() {
        assertNotNull(DecompilerType.PROCYON);
        assertTrue(DecompilerType.PROCYON.getDisplayName().contains("Procyon"));
    }
}
