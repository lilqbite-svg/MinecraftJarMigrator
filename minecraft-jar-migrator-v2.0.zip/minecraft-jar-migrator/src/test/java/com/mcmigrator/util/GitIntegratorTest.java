package com.mcmigrator.util;

import org.junit.jupiter.api.Test;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class GitIntegratorTest {

    @Test
    void checkStatusReturnsNonNull() {
        var status = GitIntegrator.checkStatus(Path.of("."));
        assertNotNull(status);
    }

    @Test
    void gitStatusRecord() {
        var status = new GitIntegrator.GitStatus(true, true, "main", true);
        assertTrue(status.available());
        assertTrue(status.isRepo());
        assertEquals("main", status.branch());
        assertTrue(status.clean());
    }
}
