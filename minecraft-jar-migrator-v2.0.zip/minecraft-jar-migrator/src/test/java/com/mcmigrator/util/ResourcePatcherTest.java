package com.mcmigrator.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ResourcePatcherTest {

    @Test
    void getPackFormatForKnownVersions() {
        // Test that pack format returns positive numbers for known versions
        // We can't test the private method directly, but we verify the class loads
        assertNotNull(ResourcePatcher.class);
    }
}
