package com.mcmigrator.transform.bytecode;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class AccessWidenerPatcherTest {

    @Test
    void remapsClassNames() {
        AccessWidenerPatcher patcher = new AccessWidenerPatcher(
                java.util.Map.of("net/minecraft/server/v1_20_R3/EntityPlayer",
                        "net/minecraft/server/level/ServerPlayer"),
                java.util.Map.of(),
                java.util.Map.of());

        String widener = "accessible method net.minecraft.server.v1_20_R3.EntityPlayer getMainHandItem ()Lnet/minecraft/world/item/ItemStack;";
        byte[] result = patcher.apply("test.accesswidener", widener.getBytes(StandardCharsets.UTF_8));
        String output = new String(result, StandardCharsets.UTF_8);
        assertTrue(output.contains("ServerPlayer"));
        assertFalse(output.contains("v1_20_R3"));
    }

    @Test
    void doesNotModifyNonAccessWidenerFiles() {
        AccessWidenerPatcher patcher = new AccessWidenerPatcher(
                java.util.Map.of(), java.util.Map.of(), java.util.Map.of());
        byte[] data = "test".getBytes(StandardCharsets.UTF_8);
        byte[] result = patcher.apply("test.json", data);
        assertSame(data, result);
    }
}
