package com.mcmigrator.transform.bytecode;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class MixinConfigPatcherTest {

    @Test
    void updatesCompatibilityLevelToJava21ForNewVersions() {
        MixinConfigPatcher patcher = new MixinConfigPatcher("1.21.0");
        String json = """
                {"required":true,"compatibilityLevel":"JAVA_17","package":"com.test","mixins":[]}""";
        byte[] result = patcher.apply("test.mixins.json", json.getBytes(StandardCharsets.UTF_8));
        String output = new String(result, StandardCharsets.UTF_8);
        assertTrue(output.contains("JAVA_21"));
    }

    @Test
    void doesNotModifyNonMixinFiles() {
        MixinConfigPatcher patcher = new MixinConfigPatcher("1.21.0");
        byte[] data = "some content".getBytes(StandardCharsets.UTF_8);
        byte[] result = patcher.apply("fabric.mod.json", data);
        assertSame(data, result);
    }

    @Test
    void handlesMalformedJson() {
        MixinConfigPatcher patcher = new MixinConfigPatcher("1.21.0");
        byte[] data = "not json".getBytes(StandardCharsets.UTF_8);
        byte[] result = patcher.apply("test.mixins.json", data);
        assertSame(data, result);
    }
}
