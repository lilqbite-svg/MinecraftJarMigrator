package com.mcmigrator.transform.bytecode;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class RefmapPatcherTest {

    @Test
    void remapsMethodNamesInRefmap() {
        RefmapPatcher patcher = new RefmapPatcher(
                Map.of(),
                Map.of("method_1234", "tick"),
                Map.of("field_5678", "age"));

        String refmap = """
                {"mappings":{"com.test.Mixin":{"doThing":"method_1234()V"}}}""";
        byte[] result = patcher.apply("test-refmap.json", refmap.getBytes(StandardCharsets.UTF_8));
        String output = new String(result, StandardCharsets.UTF_8);
        assertTrue(output.contains("tick"));
    }

    @Test
    void doesNotModifyNonRefmapFiles() {
        RefmapPatcher patcher = new RefmapPatcher(Map.of(), Map.of(), Map.of());
        byte[] data = "test".getBytes(StandardCharsets.UTF_8);
        byte[] result = patcher.apply("fabric.mod.json", data);
        assertSame(data, result);
    }

    @Test
    void handlesEmptyMappings() {
        RefmapPatcher patcher = new RefmapPatcher(Map.of(), Map.of(), Map.of());
        String refmap = """
                {"mappings":{}}""";
        byte[] data = refmap.getBytes(StandardCharsets.UTF_8);
        byte[] result = patcher.apply("test-refmap.json", data);
        assertSame(data, result);
    }
}
