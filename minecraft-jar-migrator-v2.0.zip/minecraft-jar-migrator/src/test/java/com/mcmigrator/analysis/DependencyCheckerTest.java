package com.mcmigrator.analysis;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DependencyCheckerTest {

    @Test
    void dependencyReportEmpty() {
        var report = new DependencyChecker.DependencyReport(
                java.util.List.of(), java.util.List.of(), java.util.List.of());
        assertFalse(report.hasIssues());
        assertTrue(report.summary().contains("0"));
    }

    @Test
    void dependencyReportWithIssues() {
        var issue = new DependencyChecker.DependencyIssue(
                "minecraft", ">=1.21.0", "version mismatch", "update");
        var report = new DependencyChecker.DependencyReport(
                java.util.List.of("mod-a"),
                java.util.List.of(issue),
                java.util.List.of());
        assertTrue(report.hasIssues());
        assertTrue(report.summary().contains("1 issues"));
    }
}
