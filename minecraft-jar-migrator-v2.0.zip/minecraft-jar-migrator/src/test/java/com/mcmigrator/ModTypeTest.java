package com.mcmigrator;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ModTypeTest {

    @Test
    void fromStringIsCaseInsensitive() {
        assertEquals(ModType.PAPER, ModType.fromString("paper"));
        assertEquals(ModType.PAPER, ModType.fromString("PAPER"));
        assertEquals(ModType.PAPER, ModType.fromString("Paper"));
    }

    @Test
    void newTypesExist() {
        assertNotNull(ModType.NEOFORGE);
        assertNotNull(ModType.QUILT);
    }

    @Test
    void fromStringNeoForge() {
        assertEquals(ModType.NEOFORGE, ModType.fromString("neoforge"));
        assertEquals(ModType.NEOFORGE, ModType.fromString("NEOFORGE"));
    }

    @Test
    void fromStringQuilt() {
        assertEquals(ModType.QUILT, ModType.fromString("quilt"));
        assertEquals(ModType.QUILT, ModType.fromString("QUILT"));
    }

    @Test
    void invalidTypeThrows() {
        assertThrows(IllegalArgumentException.class, () -> ModType.fromString("invalid"));
    }

    @Test
    void displayNamesAreSet() {
        assertEquals("NeoForge", ModType.NEOFORGE.getDisplayName());
        assertEquals("Quilt", ModType.QUILT.getDisplayName());
        assertEquals("Fabric", ModType.FABRIC.getDisplayName());
    }
}
