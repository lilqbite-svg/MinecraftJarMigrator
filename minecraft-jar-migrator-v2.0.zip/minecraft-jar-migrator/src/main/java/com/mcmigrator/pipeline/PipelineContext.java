package com.mcmigrator.pipeline;

import com.mcmigrator.Constants;
import com.mcmigrator.ModType;
import com.mcmigrator.decompiler.DecompilerType;
import com.mcmigrator.report.MigrationReport;

import java.nio.file.Path;
import java.util.List;

public record PipelineContext(
        Path inputJar,
        Path outputJar,
        String fromVersion,
        String toVersion,
        ModType modType,
        boolean keepSources,
        boolean dryRun,
        List<Path> classpath,
        List<String> disabledRules,
        Path workDir,
        MigrationReport report,
        DecompilerType decompilerType,
        boolean decompileCache,
        boolean parallelDecompile,
        StageProgressListener progressListener) {

    public Path remappedJar() {
        return workDir.resolve(Constants.REMAPPED_JAR);
    }

    public Path sourcesDir() {
        return workDir.resolve(Constants.SOURCES_DIR);
    }

    public Path classesDir() {
        return workDir.resolve(Constants.CLASSES_DIR);
    }

    public void reportProgress(int percent, String detail) {
        if (progressListener != null) {
            progressListener.onStageProgress("pipeline", percent, detail);
        }
    }
}
