package com.mcmigrator.pipeline;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.printer.DefaultPrettyPrinter;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JarTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;
import com.mcmigrator.Constants;
import com.mcmigrator.exception.MigrationException;
import com.mcmigrator.exception.TransformException;
import com.mcmigrator.rules.VersionRuleSet;
import com.mcmigrator.transform.TransformContext;
import com.mcmigrator.transform.TransformRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Этап [4/4], часть 1: применяет правила из {@link VersionRuleSet}
 * ко всем декомпилированным {@code .java} файлам (правка на месте).
 */
public final class TransformStage implements PipelineStage {

    private static final Logger log = LoggerFactory.getLogger(TransformStage.class);

    @Override
    public String name() {
        return "Transform";
    }

    @Override
    public void execute(PipelineContext ctx) throws MigrationException {
        VersionRuleSet ruleSet = VersionRuleSet.load(ctx.fromVersion(), ctx.toVersion());
        log.info("[4/4] Applying transform rules...");
        List<TransformRule> pluginRules = com.mcmigrator.rules.RulePluginLoader.load(
                java.nio.file.Path.of(System.getProperty("user.home"),
                        ".mcmigrator", "plugins"));
        if (ruleSet.isEmpty() && pluginRules.isEmpty()) {
            log.warn("  Нет правил трансформации для пары {} → {} — этап пропущен",
                    ctx.fromVersion(), ctx.toVersion());
            try {
                Files.write(ctx.workDir().resolve(Constants.MODIFIED_LIST), List.of(),
                        StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new TransformException("Не удалось записать список изменённых файлов", e);
            }
            return;
        }

        List<TransformRule> rules = new java.util.ArrayList<>(ruleSet.toRules());
        rules.addAll(pluginRules);
        if (!ctx.disabledRules().isEmpty()) {
            int before = rules.size();
            rules.removeIf(r -> ctx.disabledRules().contains(r.description()));
            log.info("  Интерактивный режим: выключено правил — {}", before - rules.size());
        }
        JavaParser parser = buildParser(ctx);
        DefaultPrettyPrinter printer = new DefaultPrettyPrinter();
        Map<String, Integer> hits = new LinkedHashMap<>();
        List<String> modifiedFiles = new java.util.ArrayList<>();
        int total = 0;
        int changed = 0;

        try (Stream<Path> walk = Files.walk(ctx.sourcesDir())) {
            List<Path> javaFiles = walk
                    .filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().endsWith(Constants.JAVA_EXT))
                    .sorted()
                    .toList();

            for (Path file : javaFiles) {
                total++;
                String source = Files.readString(file, StandardCharsets.UTF_8);
                ParseResult<CompilationUnit> result = parser.parse(source);
                if (!result.isSuccessful() || result.getResult().isEmpty()) {
                    log.warn("  Не удалось распарсить {} — файл пропущен", file.getFileName());
                    continue;
                }
                CompilationUnit unit = result.getResult().get();
                TransformContext tctx = new TransformContext(file, source, ctx.report(), hits);

                for (TransformRule rule : rules) {
                    rule.apply(unit, tctx);
                }

                if (tctx.modified()) {
                    changed++;
                    String rel = ctx.sourcesDir().relativize(file).toString();
                    modifiedFiles.add(rel);
                    String printed = printer.print(unit);
                    writeDiff(ctx, rel, source, printed);
                    if (ctx.dryRun()) {
                        log.debug("  [dry-run] {} был бы изменён", file.getFileName());
                    } else {
                        Files.writeString(file, printed, StandardCharsets.UTF_8);
                    }
                }
            }
        } catch (IOException e) {
            throw new TransformException("Ошибка обхода исходников: " + e.getMessage(), e);
        }

        for (TransformRule rule : rules) {
            Integer count = hits.get(rule.description());
            if (count == null) {
                log.warn("  {}: совпадений не найдено", rule.description());
            } else {
                log.warn("  {}", rule.summarize(count));
            }
        }
        log.info("  {} of {} files modified", changed, total);
        try {
            Files.write(ctx.workDir().resolve(Constants.MODIFIED_LIST), modifiedFiles,
                    StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new TransformException("Не удалось записать список изменённых файлов", e);
        }
    }

    /** Пишет diff «было → стало» в {@code workDir/diffs} для просмотра в GUI. */
    private void writeDiff(PipelineContext ctx, String rel, String before, String after) {
        try {
            java.nio.file.Path diffFile = ctx.workDir().resolve("diffs")
                    .resolve(rel.replace(java.io.File.separatorChar, '_')
                            .replace('/', '_') + ".diff");
            Files.createDirectories(diffFile.getParent());
            Files.writeString(diffFile,
                    com.mcmigrator.util.DiffUtil.unified(before, after),
                    StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.debug("Diff для {} не записан: {}", rel, e.getMessage());
        }
    }

    /**
     * Настраивает парсер с symbol solver: рефлексия (JDK) + декомпилированные
     * исходники + пользовательский classpath. Разрешение типов — best effort.
     */
    private JavaParser buildParser(PipelineContext ctx) {
        CombinedTypeSolver solver = new CombinedTypeSolver(new ReflectionTypeSolver());
        solver.add(new JavaParserTypeSolver(ctx.sourcesDir()));
        for (Path jar : ctx.classpath()) {
            try {
                solver.add(new JarTypeSolver(jar));
            } catch (IOException e) {
                log.warn("  Jar из classpath не прочитан для symbol solver: {} ({})",
                        jar, e.getMessage());
            }
        }
        ParserConfiguration configuration = new ParserConfiguration()
                .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_17)
                .setSymbolResolver(new JavaSymbolSolver(solver));
        return new JavaParser(configuration);
    }
}
