package com.mcmigrator.pipeline;

import com.mcmigrator.exception.MigrationException;
import com.mcmigrator.exception.RemapException;
import com.mcmigrator.mappings.MappingsProvider;
import com.mcmigrator.util.JarUtil;
import net.fabricmc.tinyremapper.IMappingProvider;
import net.fabricmc.tinyremapper.NonClassCopyMode;
import net.fabricmc.tinyremapper.OutputConsumerPath;
import net.fabricmc.tinyremapper.TinyRemapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.InvalidPathException;

public final class RemapStage implements PipelineStage {

    private static final Logger log = LoggerFactory.getLogger(RemapStage.class);

    private final MappingsProvider mappings;

    public RemapStage(MappingsProvider mappings) {
        this.mappings = mappings;
    }

    @Override
    public String name() {
        return "Remap";
    }

    @Override
    public void execute(PipelineContext ctx) throws MigrationException {
        IMappingProvider provider = mappings.chainedProvider(ctx.fromVersion(), ctx.toVersion());

        log.debug("Starting Tiny Remapper: {} -> {}", ctx.inputJar(), ctx.remappedJar());

        boolean retried = false;
        boolean success = false;

        while (!success) {
            TinyRemapper remapper = TinyRemapper.newRemapper()
                    .withMappings(provider)
                    .ignoreConflicts(true)
                    .renameInvalidLocals(true)
                    .fixPackageAccess(true)
                    .rebuildSourceFilenames(true)
                    .build();

            try (OutputConsumerPath out = new OutputConsumerPath.Builder(ctx.remappedJar()).build()) {
                out.addNonClassFiles(ctx.inputJar(), NonClassCopyMode.FIX_META_INF, remapper);
                remapper.readInputs(ctx.inputJar());
                remapper.apply(out);
                success = true;
            } catch (RuntimeException e) {
                remapper.finish();

                if (isInvalidPathError(e) && !retried) {
                    log.warn("Invalid path character detected in input jar — retrying with fixPackageAccess");
                    ctx.report().addWarning("Input jar contains classes with invalid path characters "
                            + "(null bytes). These classes will be skipped.");
                    retried = true;
                    continue;
                }

                if (isInvalidPathError(e)) {
                    String detail = extractInvalidPath(e);
                    log.error("Invalid path in class: {}", detail);
                    log.error("This usually means the input jar is corrupted or contains "
                            + "obfuscated classes with null bytes in names.");
                    log.error("The mod may have anti-tamper protection. "
                            + "Try running \"🛡️ Analysis\" → \"🔓 Remove protection\" first.");

                    // Try to continue with partial remap
                    log.warn("Attempting partial remap (skipping problematic classes)...");
                    try {
                        partialRemap(ctx, provider);
                        ctx.report().addWarning("Remap completed with errors — some classes skipped "
                                + "due to invalid path characters. Output may be incomplete.");
                        return;
                    } catch (Exception ignored) {
                        throw new RemapException("Remap failed: invalid path character in class '"
                                + detail + "'. Input jar may be corrupted or protected.", e);
                    }
                }

                throw new RemapException("Remap failed: " + e.getMessage(), e);
            } catch (IOException e) {
                throw new RemapException("Remap I/O error: " + e.getMessage(), e);
            } finally {
                remapper.finish();
            }
        }

        try {
            int classes = JarUtil.countClasses(ctx.remappedJar());
            log.info("[2/4] Remapping bytecode... {} classes remapped", classes);
        } catch (IOException e) {
            log.info("[2/4] Remapping bytecode... done");
        }
    }

    private void partialRemap(PipelineContext ctx, IMappingProvider provider)
            throws IOException {
        TinyRemapper remapper = TinyRemapper.newRemapper()
                .withMappings(provider)
                .ignoreConflicts(true)
                .renameInvalidLocals(true)
                .fixPackageAccess(true)
                .rebuildSourceFilenames(true)
                .build();

        try (OutputConsumerPath out = new OutputConsumerPath.Builder(ctx.remappedJar()).build()) {
            out.addNonClassFiles(ctx.inputJar(), NonClassCopyMode.FIX_META_INF, remapper);
            remapper.readInputs(ctx.inputJar());
            remapper.apply(out);
        } finally {
            remapper.finish();
        }
    }

    private boolean isInvalidPathError(Throwable e) {
        Throwable cause = e;
        while (cause != null) {
            if (cause instanceof InvalidPathException) return true;
            if (cause.getMessage() != null && cause.getMessage().contains("nul character")) return true;
            cause = cause.getCause();
        }
        return false;
    }

    private String extractInvalidPath(Throwable e) {
        Throwable cause = e;
        while (cause != null) {
            if (cause instanceof InvalidPathException ipe) {
                return ipe.getInput();
            }
            if (cause.getMessage() != null && cause.getMessage().contains("nul character")) {
                String msg = cause.getMessage();
                int idx = msg.lastIndexOf(": ");
                return idx > 0 ? msg.substring(idx + 2) : msg;
            }
            cause = cause.getCause();
        }
        return "unknown";
    }
}
