package com.mcmigrator.pipeline;

import com.mcmigrator.Constants;
import com.mcmigrator.decompiler.DecompilerProvider;
import com.mcmigrator.decompiler.DecompilerType;
import com.mcmigrator.exception.DecompileException;
import com.mcmigrator.exception.MigrationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class DecompileStage implements PipelineStage {

    private static final Logger log = LoggerFactory.getLogger(DecompileStage.class);

    @Override
    public String name() {
        return "Decompile";
    }

    @Override
    public void execute(PipelineContext ctx) throws MigrationException {
        Path sourcesDir = ctx.sourcesDir();
        try {
            Files.createDirectories(sourcesDir);
        } catch (IOException e) {
            throw new DecompileException("Cannot create " + sourcesDir, e);
        }

        DecompilerType decompilerType = ctx.decompilerType();
        // Параллельная декомпиляция оправдана только для Vineflower
        // (CFR/Procyon уже обрабатывают весь jar за один проход).
        boolean parallel = ctx.parallelDecompile()
                && decompilerType == DecompilerType.VINEFLOWER;

        if (ctx.decompileCache()) {
            String hash = computeHash(ctx.remappedJar(), decompilerType);
            Path cacheDir = getCacheDir().resolve(hash);
            if (tryRestoreFromCache(cacheDir, sourcesDir)) {
                log.info("[3/4] Decompiling ({} decompiler cache hit)...", decompilerType.getDisplayName());
                return;
            }
            runDecompile(ctx, sourcesDir, decompilerType, parallel);
            saveToCache(cacheDir, sourcesDir);
        } else {
            runDecompile(ctx, sourcesDir, decompilerType, parallel);
        }
    }

    /** Выбирает параллельный или последовательный путь декомпиляции. */
    private void runDecompile(PipelineContext ctx, Path sourcesDir,
                              DecompilerType type, boolean parallel)
            throws MigrationException {
        if (parallel) {
            try {
                com.mcmigrator.decompiler.ParallelDecompiler.decompileParallel(
                        ctx.remappedJar(), sourcesDir, type, 0);
                return;
            } catch (Exception e) {
                log.warn("Параллельная декомпиляция не удалась ({}), переключаюсь на обычную",
                        e.getMessage());
                // Чистим частичный результат перед повтором.
                try {
                    deleteRecursive(sourcesDir);
                    Files.createDirectories(sourcesDir);
                } catch (IOException ignored) {
                    // best effort
                }
            }
        }
        DecompilerProvider.decompile(ctx.remappedJar(), sourcesDir, type);
    }

    private static Path getCacheDir() {
        return Path.of(System.getProperty("user.home"))
                .resolve(Constants.DECOMPILE_CACHE_DIR);
    }

    private String computeHash(Path jarFile, DecompilerType type) throws DecompileException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream in = Files.newInputStream(jarFile)) {
                byte[] buf = new byte[8192];
                int read;
                while ((read = in.read(buf)) != -1) {
                    digest.update(buf, 0, read);
                }
            }
            digest.update(type.name().getBytes(StandardCharsets.UTF_8));
            byte[] hash = digest.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new DecompileException("Failed to compute hash", e);
        }
    }

    private boolean tryRestoreFromCache(Path cacheDir, Path sourcesDir) {
        if (!Files.isDirectory(cacheDir)) {
            return false;
        }
        try {
            long count;
            try (Stream<Path> walk = Files.walk(cacheDir)) {
                count = walk.filter(p -> p.toString().endsWith(Constants.JAVA_EXT)).count();
            }
            if (count == 0) {
                return false;
            }
            copyDir(cacheDir, sourcesDir);
            log.debug("Restored {} files from decompile cache", count);
            return true;
        } catch (IOException e) {
            log.debug("Cache restore failed: {}", e.getMessage());
            return false;
        }
    }

    private void saveToCache(Path cacheDir, Path sourcesDir) {
        try {
            if (Files.exists(cacheDir)) {
                deleteRecursive(cacheDir);
            }
            copyDir(sourcesDir, cacheDir);
            log.debug("Saved decompile results to cache: {}", cacheDir);
        } catch (IOException e) {
            log.debug("Cache save failed: {}", e.getMessage());
        }
    }

    private static void copyDir(Path src, Path dst) throws IOException {
        Files.createDirectories(dst);
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                    throws IOException {
                Files.createDirectories(dst.resolve(src.relativize(dir)));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                Files.copy(file, dst.resolve(src.relativize(file)));
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private static void deleteRecursive(Path dir) throws IOException {
        if (!Files.exists(dir)) return;
        Files.walkFileTree(dir, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path d, IOException exc)
                    throws IOException {
                Files.delete(d);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
