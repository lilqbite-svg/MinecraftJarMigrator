package com.mcmigrator.pipeline;

import com.mcmigrator.ModType;
import com.mcmigrator.decompiler.DecompilerType;

import java.nio.file.Path;
import java.util.List;

public record MigrationConfig(
        Path inputJar,
        Path outputJar,
        String fromVersion,
        String toVersion,
        ModType modType,
        boolean keepSources,
        boolean dryRun,
        Path mappingsDir,
        List<Path> classpath,
        boolean autoClasspath,
        List<String> disabledRules,
        DecompilerType decompilerType,
        boolean decompileCache,
        boolean parallelDecompile) {

    public MigrationConfig(Path inputJar, Path outputJar, String fromVersion, String toVersion,
                           ModType modType, boolean keepSources, boolean dryRun,
                           Path mappingsDir, List<Path> classpath, boolean autoClasspath) {
        this(inputJar, outputJar, fromVersion, toVersion, modType, keepSources, dryRun,
                mappingsDir, classpath, autoClasspath, List.of(),
                DecompilerType.VINEFLOWER, true, false);
    }

    public MigrationConfig(Path inputJar, Path outputJar, String fromVersion, String toVersion,
                           ModType modType, boolean keepSources, boolean dryRun,
                           Path mappingsDir, List<Path> classpath, boolean autoClasspath,
                           List<String> disabledRules) {
        this(inputJar, outputJar, fromVersion, toVersion, modType, keepSources, dryRun,
                mappingsDir, classpath, autoClasspath, disabledRules,
                DecompilerType.VINEFLOWER, true, false);
    }

    /** Полный конструктор без parallel (обратная совместимость существующих вызовов). */
    public MigrationConfig(Path inputJar, Path outputJar, String fromVersion, String toVersion,
                           ModType modType, boolean keepSources, boolean dryRun,
                           Path mappingsDir, List<Path> classpath, boolean autoClasspath,
                           List<String> disabledRules, DecompilerType decompilerType,
                           boolean decompileCache) {
        this(inputJar, outputJar, fromVersion, toVersion, modType, keepSources, dryRun,
                mappingsDir, classpath, autoClasspath, disabledRules,
                decompilerType, decompileCache, false);
    }
}
