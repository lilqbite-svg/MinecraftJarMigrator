package com.mcmigrator.pipeline;

import com.mcmigrator.exception.MigrationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Пакетная миграция: прогоняет все {@code .jar} из папки через пайплайн
 * (или каскад) и формирует сводную таблицу результатов.
 */
public final class BatchMigration {

    private static final Logger log = LoggerFactory.getLogger(BatchMigration.class);

    /** Итог по одному jar. */
    public record Item(String fileName, Status status, String detail) {
        /** Статус миграции jar. */
        public enum Status { OK, WARNINGS, FAILED }
    }

    private BatchMigration() {
    }

    /**
     * Мигрирует все jar из папки.
     *
     * @param inputDir  папка с jar
     * @param outputDir папка результатов (создаётся)
     * @param template  конфигурация-шаблон (input/output подменяются для каждого jar)
     * @param cascade   идти ли каскадом через промежуточные версии
     * @param callback  колбэк прогресса; может быть {@code null}
     * @return сводка по каждому jar
     * @throws MigrationException если папку нельзя прочитать/создать
     */
    public static List<Item> run(Path inputDir, Path outputDir, MigrationConfig template,
                                 boolean cascade, CascadeMigration.StepCallback callback)
            throws MigrationException {
        List<Path> jars = listJars(inputDir);
        if (jars.isEmpty()) {
            throw new MigrationException("В папке нет .jar файлов: " + inputDir);
        }
        try {
            Files.createDirectories(outputDir);
        } catch (IOException e) {
            throw new MigrationException("Не удалось создать " + outputDir, e);
        }

        List<Item> results = new ArrayList<>();
        int index = 0;
        for (Path jar : jars) {
            index++;
            String name = jar.getFileName().toString();
            if (callback != null) {
                callback.onStep(index, jars.size(), name);
            }
            log.info("════ Пакет {}/{}: {} ════", index, jars.size(), name);

            Path output = outputDir.resolve(
                    name.replace(".jar", "") + "-" + template.toVersion() + ".jar");
            MigrationConfig config = new MigrationConfig(
                    jar, output, template.fromVersion(), template.toVersion(),
                    template.modType(), template.keepSources(), template.dryRun(),
                    template.mappingsDir(), template.classpath(), template.autoClasspath(),
                    template.disabledRules(), template.decompilerType(),
                    template.decompileCache(), template.parallelDecompile());
            try {
                if (cascade) {
                    CascadeMigration.run(config, null);
                } else {
                    new MigrationPipeline().run(config);
                }
                results.add(new Item(name, Item.Status.OK, output.getFileName().toString()));
            } catch (MigrationException e) {
                log.error("  {} не мигрирован: {}", name, e.getMessage());
                results.add(new Item(name, Item.Status.FAILED, e.getMessage()));
            }
        }
        writeSummary(outputDir, results);
        return results;
    }

    private static List<Path> listJars(Path dir) throws MigrationException {
        try (Stream<Path> walk = Files.list(dir)) {
            return walk.filter(p -> p.toString().toLowerCase().endsWith(".jar"))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            throw new MigrationException("Не удалось прочитать папку " + dir, e);
        }
    }

    private static void writeSummary(Path outputDir, List<Item> results) {
        StringBuilder sb = new StringBuilder("=== Сводка пакетной миграции ===\n");
        long ok = results.stream().filter(r -> r.status() == Item.Status.OK).count();
        sb.append("Успешно: ").append(ok).append(" / ").append(results.size()).append("\n\n");
        for (Item item : results) {
            String icon = switch (item.status()) {
                case OK -> "[OK]    ";
                case WARNINGS -> "[WARN]  ";
                case FAILED -> "[FAIL]  ";
            };
            sb.append(icon).append(item.fileName()).append(" — ")
                    .append(item.detail()).append('\n');
        }
        Path summary = outputDir.resolve("batch-summary.txt");
        try {
            Files.writeString(summary, sb.toString(), StandardCharsets.UTF_8);
            log.info("Сводка пакета: {}", summary);
        } catch (IOException e) {
            log.warn("Не удалось записать сводку: {}", e.getMessage());
        }
    }
}
