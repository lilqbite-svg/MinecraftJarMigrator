package com.mcmigrator.pipeline;

import com.mcmigrator.Constants;
import com.mcmigrator.exception.CompileException;
import com.mcmigrator.exception.MigrationException;
import com.mcmigrator.util.JarUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Этап [4/4], часть 2: рекомпилирует трансформированные исходники через
 * {@code javax.tools} в {@code temp/classes/} и упаковывает их вместе
 * с ресурсами исходного jar в выходной архив.
 */
public final class CompileStage implements PipelineStage {

    private static final Logger log = LoggerFactory.getLogger(CompileStage.class);

    private static final int MAX_ERRORS_SHOWN = 10;

    @Override
    public String name() {
        return "Compile";
    }

    @Override
    public void execute(PipelineContext ctx) throws MigrationException {
        if (ctx.dryRun()) {
            log.info("[4/4] Compiling... пропущено (dry-run)");
            return;
        }

        // Перекомпилируем ТОЛЬКО файлы, изменённые трансформациями: остальной
        // байткод уже валиден после ремапа и берётся из remapped.jar как есть.
        List<Path> javaFiles = readModifiedSources(ctx);
        if (javaFiles.isEmpty()) {
            log.info("[4/4] Compiling... пропущено — правила не меняли код, "
                    + "использую ремапнутый байткод");
            try {
                Files.copy(ctx.remappedJar(), ctx.outputJar(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                throw new CompileException("Не удалось записать выходной jar "
                        + ctx.outputJar() + ": " + e.getMessage(), e);
            }
            return;
        }
        log.info("[4/4] Compiling... {} изменённых файлов", javaFiles.size());

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            throw new CompileException(
                    "Системный компилятор Java недоступен — запускайте инструмент на JDK, а не JRE");
        }

        try {
            Files.createDirectories(ctx.classesDir());
        } catch (IOException e) {
            throw new CompileException("Не удалось создать " + ctx.classesDir(), e);
        }

        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager fileManager =
                     compiler.getStandardFileManager(diagnostics, null, StandardCharsets.UTF_8)) {

            fileManager.setLocation(StandardLocation.CLASS_OUTPUT,
                    List.of(ctx.classesDir().toFile()));
            // remapped.jar в classpath: изменённые файлы видят остальные классы мода.
            List<File> cp = new java.util.ArrayList<>();
            cp.add(ctx.remappedJar().toFile());
            ctx.classpath().forEach(pth -> cp.add(pth.toFile()));
            fileManager.setLocation(StandardLocation.CLASS_PATH, cp);

            Iterable<? extends JavaFileObject> units =
                    fileManager.getJavaFileObjectsFromPaths(javaFiles);
            String release = chooseRelease(ctx);
            List<String> options = List.of(
                    "--release", release,
                    "-proc:none",
                    "-nowarn");

            JavaCompiler.CompilationTask task = compiler.getTask(
                    null, fileManager, diagnostics, options, null, units);
            boolean ok = task.call();

            for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics()) {
                if (d.getKind() == Diagnostic.Kind.WARNING
                        || d.getKind() == Diagnostic.Kind.MANDATORY_WARNING) {
                    ctx.report().addWarning(formatDiagnostic(d));
                }
            }

            if (!ok) {
                // Per-file fallback: compile each file individually
                log.warn("  Batch compilation failed, trying per-file compilation...");
                var result = compileIndividually(ctx, javaFiles, release);

                for (String failed : result.failedFiles()) {
                    ctx.report().addManualFix("Compilation failed: " + failed);
                }

                if (result.successCount() > 0) {
                    log.info("  Per-file: {} succeeded, {} failed",
                            result.successCount(), result.failedFiles().size());
                    packPartialJar(ctx, result.successfulClasses());
                    ctx.report().addWarning("Partial compilation: "
                            + result.successCount() + " files compiled, "
                            + result.failedFiles().size()
                            + " files reverted to remapped bytecode. "
                            + "See manual fixes for details.");
                    return;
                }

                String details = buildErrorMessage(diagnostics);
                log.warn("  All files failed to compile — using remapped bytecode only");
                log.warn("{}", details);
                ctx.report().addWarning("Compilation failed completely; "
                        + "output uses remapped bytecode only. " + details);
                Files.copy(ctx.remappedJar(), ctx.outputJar(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                return;
            }
        } catch (IOException e) {
            throw new CompileException("Ошибка ввода-вывода при компиляции: " + e.getMessage(), e);
        }

        try {
            JarUtil.packJar(ctx.classesDir(), ctx.remappedJar(), ctx.outputJar(), true);
        } catch (IOException e) {
            throw new CompileException("Не удалось упаковать выходной jar "
                    + ctx.outputJar() + ": " + e.getMessage(), e);
        }
    }

    /** Читает список изменённых трансформациями исходников из временной директории. */
    private List<Path> readModifiedSources(PipelineContext ctx) throws CompileException {
        Path list = ctx.workDir().resolve(Constants.MODIFIED_LIST);
        if (!Files.isRegularFile(list)) {
            // Списка нет (например, этап трансформации пропущен) — компилировать нечего.
            return List.of();
        }
        try {
            return Files.readAllLines(list, StandardCharsets.UTF_8).stream()
                    .filter(line -> !line.isBlank())
                    .map(rel -> ctx.sourcesDir().resolve(rel))
                    .filter(Files::isRegularFile)
                    .toList();
        } catch (IOException e) {
            throw new CompileException("Не удалось прочитать " + list, e);
        }
    }

    /**
     * Подбирает {@code --release}: минимум Java целевой версии Minecraft
     * (классы classpath новых версий собраны новым байткодом), но не выше
     * возможностей текущей JVM — при нехватке пишет предупреждение.
     */
    private String chooseRelease(PipelineContext ctx) {
        int required = requiredJavaFeature(ctx.toVersion());
        int runtime = Runtime.version().feature();
        int release = Math.min(required, runtime);
        if (release < required) {
            String msg = "Minecraft " + ctx.toVersion() + " требует Java " + required
                    + ", а инструмент запущен на Java " + runtime
                    + " — компиляция может упасть на классах classpath. "
                    + "Пересоберите exe на JDK " + required + "+";
            log.warn("  {}", msg);
            ctx.report().addWarning(msg);
        }
        return String.valueOf(Math.max(17, release));
    }

    /** Minimum Java for Minecraft version (26.x→26, 1.20.5+→21, else 17). */
    private static int requiredJavaFeature(String mcVersion) {
        try {
            String[] parts = mcVersion.split("\\.");
            int major = Integer.parseInt(parts[0]);
            if (major >= 27) {
                return 27;
            }
            if (major >= 26) {
                return 26;
            }
            int minor = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            int patch = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            if (minor > 20 || (minor == 20 && patch >= 5)) {
                return 21;
            }
            return 17;
        } catch (NumberFormatException e) {
            return 17;
        }
    }

    private List<Path> collectSources(Path sourcesDir) throws CompileException {
        try (Stream<Path> walk = Files.walk(sourcesDir)) {
            return walk.filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().endsWith(Constants.JAVA_EXT))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            throw new CompileException("Не удалось обойти " + sourcesDir, e);
        }
    }

    private String buildErrorMessage(DiagnosticCollector<JavaFileObject> diagnostics) {
        List<Diagnostic<? extends JavaFileObject>> errors = diagnostics.getDiagnostics().stream()
                .filter(d -> d.getKind() == Diagnostic.Kind.ERROR)
                .toList();
        StringBuilder sb = new StringBuilder("Компиляция завершилась с ")
                .append(errors.size()).append(" ошибками");
        errors.stream().limit(MAX_ERRORS_SHOWN)
                .forEach(d -> sb.append("\n  ").append(formatDiagnostic(d)));
        if (errors.size() > MAX_ERRORS_SHOWN) {
            sb.append("\n  ... и ещё ").append(errors.size() - MAX_ERRORS_SHOWN);
        }
        sb.append("\nПодсказка: для рекомпиляции обычно нужен server jar / API целевой версии — ")
                .append("передайте их через --classpath");
        boolean intermediary = errors.stream().anyMatch(d -> {
            String m = d.getMessage(null);
            return m != null && m.contains("package net.minecraft") && m.contains("class_");
        });
        if (intermediary) {
            sb.append("\nОбнаружены intermediary-имена Fabric (class_NNNN). Убедитесь, что ")
              .append("выбран тип fabric и включён авто-classpath — он подготовит ")
              .append("client.jar в intermediary-именах.");
        }
        java.util.Set<String> missing = new java.util.TreeSet<>();
        java.util.regex.Pattern pkg =
                java.util.regex.Pattern.compile("package ([\\w.]+) does not exist");
        for (Diagnostic<? extends JavaFileObject> d : errors) {
            String m = d.getMessage(null);
            if (m == null) {
                continue;
            }
            java.util.regex.Matcher matcher = pkg.matcher(m);
            while (matcher.find()) {
                String name = matcher.group(1);
                if (!name.startsWith("net.minecraft") && !name.startsWith("net.fabricmc")
                        && !name.startsWith("org.jetbrains")) {
                    missing.add(name);
                }
            }
        }
        if (!missing.isEmpty()) {
            sb.append("\nНедостающие пакеты (вероятно, моды-зависимости или опциональные ")
              .append("интеграции): ").append(String.join(", ",
                    missing.stream().limit(10).toList()))
              .append(". Их jar можно добавить в classpath; опциональные интеграции ")
              .append("можно удалить из исходников (--keep-sources).");
        }
        return sb.toString();
    }

    private record CompilationResult(int successCount, List<String> failedFiles,
                                     Set<String> successfulClasses) {}

    private CompilationResult compileIndividually(PipelineContext ctx, List<Path> javaFiles,
                                                   String release) {
        int success = 0;
        List<String> failed = new ArrayList<>();
        Set<String> successClasses = new HashSet<>();

        for (Path file : javaFiles) {
            javax.tools.JavaCompiler compiler = javax.tools.ToolProvider.getSystemJavaCompiler();
            if (compiler == null) {
                failed.add(ctx.sourcesDir().relativize(file).toString());
                continue;
            }
            DiagnosticCollector<JavaFileObject> fileDiag = new DiagnosticCollector<>();
            try (StandardJavaFileManager fm = compiler.getStandardFileManager(
                    fileDiag, null, StandardCharsets.UTF_8)) {
                fm.setLocation(StandardLocation.CLASS_OUTPUT,
                        List.of(ctx.classesDir().toFile()));
                List<File> cp = new ArrayList<>();
                cp.add(ctx.remappedJar().toFile());
                ctx.classpath().forEach(pth -> cp.add(pth.toFile()));
                fm.setLocation(StandardLocation.CLASS_PATH, cp);

                List<String> options = List.of("--release", release, "-proc:none", "-nowarn");
                var units = fm.getJavaFileObjectsFromPaths(List.of(file));
                boolean ok = compiler.getTask(null, fm, fileDiag, options, null, units).call();

                if (ok) {
                    success++;
                    String relative = ctx.sourcesDir().relativize(file).toString();
                    String className = relative.replace('\\', '/')
                            .replaceAll("\\.java$", "");
                    successClasses.add(className);
                } else {
                    failed.add(ctx.sourcesDir().relativize(file).toString());
                    for (var d : fileDiag.getDiagnostics()) {
                        if (d.getKind() == Diagnostic.Kind.ERROR) {
                            ctx.report().addWarning(formatDiagnostic(d));
                        }
                    }
                }
            } catch (IOException e) {
                failed.add(ctx.sourcesDir().relativize(file).toString());
            }
        }
        return new CompilationResult(success, failed, successClasses);
    }

    private void packPartialJar(PipelineContext ctx, Set<String> successfulClasses)
            throws MigrationException {
        try {
            Path base = ctx.remappedJar();
            java.util.jar.JarFile baseJar = new java.util.jar.JarFile(base.toFile());
            java.util.jar.Manifest manifest = baseJar.getManifest();
            if (manifest == null) {
                manifest = new java.util.jar.Manifest();
                manifest.getMainAttributes().put(
                        java.util.jar.Attributes.Name.MANIFEST_VERSION, "1.0");
            }
            java.util.Set<String> written = new java.util.HashSet<>();
            try (java.io.OutputStream out = Files.newOutputStream(ctx.outputJar());
                 java.util.jar.JarOutputStream jarOut = new java.util.jar.JarOutputStream(out, manifest)) {

                // 1. Successfully compiled classes from classesDir
                try (Stream<Path> walk = Files.walk(ctx.classesDir())) {
                    for (Path f : walk.filter(Files::isRegularFile).sorted().toList()) {
                        String name = ctx.classesDir().relativize(f).toString().replace('\\', '/');
                        if (written.add(name)) {
                            jarOut.putNextEntry(new java.util.jar.JarEntry(name));
                            Files.newInputStream(f).transferTo(jarOut);
                            jarOut.closeEntry();
                        }
                    }
                }

                // 2. Everything else from remapped jar (including .class for non-recompiled files)
                java.util.Enumeration<java.util.jar.JarEntry> entries = baseJar.entries();
                while (entries.hasMoreElements()) {
                    java.util.jar.JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (entry.isDirectory() || "META-INF/MANIFEST.MF".equals(name)) {
                        continue;
                    }
                    // Skip classes that were successfully recompiled (they're already in)
                    if (name.endsWith(".class")) {
                        String classPath = name.replaceAll("\\.class$", "");
                        if (successfulClasses.contains(classPath)) {
                            continue;
                        }
                    }
                    if (written.add(name)) {
                        jarOut.putNextEntry(new java.util.jar.JarEntry(name));
                        baseJar.getInputStream(entry).transferTo(jarOut);
                        jarOut.closeEntry();
                    }
                }
            }
            baseJar.close();
        } catch (IOException e) {
            throw new MigrationException("Failed to pack partial jar: " + e.getMessage(), e);
        }
    }

    private String formatDiagnostic(Diagnostic<? extends JavaFileObject> d) {
        String source = d.getSource() != null ? d.getSource().getName() : "?";
        return source + ":" + d.getLineNumber() + " " + d.getMessage(null);
    }
}
