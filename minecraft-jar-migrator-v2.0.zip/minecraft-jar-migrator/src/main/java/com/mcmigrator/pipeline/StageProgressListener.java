package com.mcmigrator.pipeline;

@FunctionalInterface
public interface StageProgressListener {
    void onStageProgress(String stageName, int percent, String detail);

    default void onStageStart(String stageName) {
        onStageProgress(stageName, 0, "Starting...");
    }

    default void onStageEnd(String stageName) {
        onStageProgress(stageName, 100, "Done");
    }
}
