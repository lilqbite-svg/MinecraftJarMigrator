package com.mcmigrator.pipeline;

import com.mcmigrator.exception.MigrationException;

/** Один этап пайплайна миграции. */
public interface PipelineStage {

    /** @return человекочитаемое имя этапа для логов */
    String name();

    /**
     * Выполняет этап.
     *
     * @param ctx контекст пайплайна
     * @throws MigrationException при фатальной ошибке этапа
     */
    void execute(PipelineContext ctx) throws MigrationException;
}
