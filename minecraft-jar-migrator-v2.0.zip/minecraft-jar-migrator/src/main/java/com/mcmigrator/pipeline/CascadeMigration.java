package com.mcmigrator.pipeline;

import com.mcmigrator.Constants;
import com.mcmigrator.exception.MigrationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Каскадная миграция: вместо одного прыжка {@code A → Z} прогоняет цепочку
 * через все промежуточные релизы {@code A → B → C → … → Z}. Каждый шаг —
 * обычный запуск {@link MigrationPipeline}; промежуточные jar и отчёты
 * складываются рядом с финальным выходом в папку {@code {output}-cascade}.
 */
public final class CascadeMigration {

    private static final Logger log = LoggerFactory.getLogger(CascadeMigration.class);

    /** Канонический список релизов (синхронизирован с generate_rules.py). */
    public static final List<String> VERSIONS = loadVersions();

    private CascadeMigration() {
    }

    /**
     * Строит маршрут между версиями по каноническому списку релизов.
     *
     * @param from исходная версия
     * @param to   целевая версия
     * @return последовательность версий от {@code from} до {@code to} включительно
     * @throws MigrationException если версия неизвестна или порядок обратный
     */
    public static List<String> route(String from, String to) throws MigrationException {
        int i = VERSIONS.indexOf(from);
        int j = VERSIONS.indexOf(to);
        if (i < 0) {
            throw new MigrationException("Версия не входит в каскадный список: " + from);
        }
        if (j < 0) {
            throw new MigrationException("Версия не входит в каскадный список: " + to);
        }
        if (i >= j) {
            throw new MigrationException(
                    "Каскад поддерживает только миграцию вверх (" + from + " → " + to + ")");
        }
        return VERSIONS.subList(i, j + 1);
    }

    /**
     * Запускает каскадную миграцию.
     *
     * @param config           конфигурация финального результата
     * @param progressCallback колбэк прогресса (номер шага, всего шагов, описание); может быть {@code null}
     * @throws MigrationException при ошибке любого шага (с указанием шага)
     */
    public static void run(MigrationConfig config, StepCallback progressCallback)
            throws MigrationException {
        List<String> route = route(config.fromVersion(), config.toVersion());
        int steps = route.size() - 1;
        log.info("[*] Каскадная миграция: {} шагов ({})", steps, String.join(" → ", route));

        Path workDir = config.outputJar().resolveSibling(
                stripJar(config.outputJar().getFileName().toString()) + "-cascade");
        try {
            Files.createDirectories(workDir);
        } catch (IOException e) {
            throw new MigrationException("Не удалось создать " + workDir, e);
        }

        Path currentInput = config.inputJar();
        for (int step = 0; step < steps; step++) {
            String from = route.get(step);
            String to = route.get(step + 1);
            boolean last = step == steps - 1;
            Path stepOutput = last
                    ? config.outputJar()
                    : workDir.resolve(stripJar(config.inputJar().getFileName().toString())
                            + "-" + to + ".jar");

            if (progressCallback != null) {
                progressCallback.onStep(step + 1, steps, from + " → " + to);
            }
            log.info("[*] Каскад {}/{}: {} → {}", step + 1, steps, from, to);

            MigrationConfig stepConfig = new MigrationConfig(
                    currentInput, stepOutput, from, to, config.modType(),
                    last && config.keepSources(), config.dryRun(),
                    config.mappingsDir(), config.classpath(), config.autoClasspath(),
                    config.disabledRules(), config.decompilerType(),
                    config.decompileCache(), config.parallelDecompile());
            try {
                new MigrationPipeline().run(stepConfig);
            } catch (MigrationException e) {
                throw new MigrationException("Каскад остановлен на шаге " + (step + 1) + "/"
                        + steps + " (" + from + " → " + to + "): " + e.getMessage(), e);
            }
            currentInput = stepOutput;
        }
        log.info("[*] Каскад завершён: {} шагов, промежуточные результаты в {}",
                steps, workDir);
    }

    private static String stripJar(String name) {
        return name.endsWith(".jar") ? name.substring(0, name.length() - 4) : name;
    }

    private static List<String> loadVersions() {
        // Источник истины — ресурс versions.txt (генерируется вместе с правилами).
        try (InputStream in = CascadeMigration.class.getResourceAsStream("/versions.txt")) {
            if (in != null) {
                List<String> list = new ArrayList<>();
                for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
                    if (!line.isBlank()) {
                        list.add(line.trim());
                    }
                }
                if (!list.isEmpty()) {
                    return List.copyOf(list);
                }
            }
        } catch (IOException ignored) {
            // упадём на встроенный список
        }
        return List.of(
                "1.14.4", "1.15", "1.15.1", "1.15.2",
                "1.16", "1.16.1", "1.16.2", "1.16.3", "1.16.4", "1.16.5",
                "1.17", "1.17.1", "1.18", "1.18.1", "1.18.2",
                "1.19", "1.19.1", "1.19.2", "1.19.3", "1.19.4",
                "1.20", "1.20.1", "1.20.2", "1.20.3", "1.20.4", "1.20.5", "1.20.6",
                "1.21", "1.21.1", "1.21.2", "1.21.3", "1.21.4", "1.21.5", "1.21.6",
                "1.21.7", "1.21.8", "1.21.9", "1.21.10", "1.21.11",
                "26.1", "26.1.1", "26.1.2");
    }

    /** Колбэк прогресса каскада. */
    @FunctionalInterface
    public interface StepCallback {
        /**
         * @param step        номер текущего шага (с 1)
         * @param total       всего шагов
         * @param description описание шага, например {@code "1.20.3 → 1.20.4"}
         */
        void onStep(int step, int total, String description);
    }
}
