package com.mcmigrator.pipeline;

import com.mcmigrator.exception.MigrationException;
import com.mcmigrator.transform.bytecode.AccessWidenerPatcher;
import com.mcmigrator.transform.bytecode.BytecodeTransformRule;
import com.mcmigrator.transform.bytecode.MixinConfigPatcher;
import com.mcmigrator.transform.bytecode.RefmapPatcher;
import net.fabricmc.mappingio.tree.MappingTree;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;

public final class BytecodeTransformStage implements PipelineStage {

    private static final Logger log = LoggerFactory.getLogger(BytecodeTransformStage.class);

    @Override
    public String name() {
        return "BytecodeTransform";
    }

    @Override
    public void execute(PipelineContext ctx) throws MigrationException {
        List<BytecodeTransformRule> rules = buildRules(ctx);
        if (rules.isEmpty()) {
            log.debug("[1.5/4] Bytecode transform: no rules, skipped");
            return;
        }
        log.info("[1.5/4] Applying bytecode transforms ({} rules)...", rules.size());

        Path input = ctx.remappedJar();
        Path output = ctx.workDir().resolve("bc-transformed.jar");
        try {
            byte[] jarBytes = Files.readAllBytes(input);
            int[] hits = {0};
            jarBytes = transformJar(jarBytes, rules, hits);
            Files.write(output, jarBytes);
            Files.copy(output, input, StandardCopyOption.REPLACE_EXISTING);
            Files.deleteIfExists(output);
            if (hits[0] > 0) {
                log.info("[1.5/4] Bytecode transforms applied: {} entries modified", hits[0]);
            } else {
                log.info("[1.5/4] Bytecode transforms: no entries needed modification");
            }
            for (BytecodeTransformRule rule : rules) {
                ctx.report().addTransformation("[BC] " + rule.description());
            }
        } catch (IOException e) {
            throw new MigrationException("Bytecode transform failed: " + e.getMessage(), e);
        }
    }

    private List<BytecodeTransformRule> buildRules(PipelineContext ctx) {
        List<BytecodeTransformRule> rules = new ArrayList<>();
        rules.add(new MixinConfigPatcher(ctx.toVersion()));
        Map<String, String> empty = Map.of();
        rules.add(new RefmapPatcher(empty, empty, empty));
        rules.add(new AccessWidenerPatcher(empty, empty, empty));
        return rules;
    }

    private byte[] transformJar(byte[] jarBytes, List<BytecodeTransformRule> rules, int[] hits)
            throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(jarBytes.length);
        try (JarFile srcJar = writeToTemp(jarBytes);
             JarOutputStream out = new JarOutputStream(buffer)) {
            Enumeration<JarEntry> entries = srcJar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.isDirectory()) {
                    out.putNextEntry(new JarEntry(entry.getName()));
                    out.closeEntry();
                    continue;
                }
                byte[] data = readAll(srcJar.getInputStream(entry));
                for (BytecodeTransformRule rule : rules) {
                    try {
                        byte[] result = rule.apply(entry.getName(), data);
                        if (result != data) {
                            hits[0]++;
                            data = result;
                        }
                    } catch (Exception e) {
                        log.debug("Rule '{}' skipped for {}: {}",
                                rule.description(), entry.getName(), e.getMessage());
                    }
                }
                out.putNextEntry(new JarEntry(entry.getName()));
                out.write(data);
                out.closeEntry();
            }
        }
        return buffer.toByteArray();
    }

    private JarFile writeToTemp(byte[] jarBytes) throws IOException {
        Path tmp = Files.createTempFile("bc-transform-", ".jar");
        Files.write(tmp, jarBytes);
        tmp.toFile().deleteOnExit();
        return new JarFile(tmp.toFile());
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        in.transferTo(out);
        return out.toByteArray();
    }
}
