package com.mcmigrator.pipeline;

import com.mcmigrator.Constants;
import com.mcmigrator.exception.MigrationException;
import com.mcmigrator.mappings.MappingsProvider;
import com.mcmigrator.report.MigrationReport;
import com.mcmigrator.util.TempDirManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Stream;

/**
 * Оркестратор миграции: последовательно выполняет этапы
 * remap → decompile → transform → compile во временной директории,
 * затем записывает отчёт и, при необходимости, исходники.
 */
public final class MigrationPipeline {

    private static final Logger log = LoggerFactory.getLogger(MigrationPipeline.class);

    /**
     * Запускает полный пайплайн миграции.
     *
     * @param config конфигурация запуска
     * @throws MigrationException при фатальной ошибке любого этапа
     */
    public void run(MigrationConfig config) throws MigrationException {
        run(config, null);
    }

    public void run(MigrationConfig config, StageProgressListener progressListener) throws MigrationException {
        try (TempDirManager temp = TempDirManager.create()) {
            MigrationReport report = new MigrationReport(
                    config.inputJar().getFileName() + " : "
                            + config.fromVersion() + " -> " + config.toVersion()
                            + " (" + config.modType().name().toLowerCase(java.util.Locale.ROOT) + ")");

            MappingsProvider mappings = new MappingsProvider(config.mappingsDir());

            List<java.nio.file.Path> classpath = config.classpath();
            if (classpath.isEmpty() && config.autoClasspath()) {
                log.info("[*] Auto-classpath for {} ({})...",
                        config.toVersion(), config.modType().name().toLowerCase(java.util.Locale.ROOT));
                java.nio.file.Path cpCache = config.mappingsDir().getParent() != null
                        ? config.mappingsDir().getParent().resolve("classpath")
                        : config.mappingsDir().resolve("classpath");
                classpath = new com.mcmigrator.classpath.ClasspathProvider(mappings, cpCache)
                        .autoClasspath(config.toVersion(), config.modType(), report, config.inputJar());
                log.info("[*] Auto-classpath: {} jars prepared", classpath.size());
            }

            PipelineContext ctx = new PipelineContext(
                    config.inputJar(), config.outputJar(),
                    config.fromVersion(), config.toVersion(),
                    config.modType(), config.keepSources(), config.dryRun(),
                    classpath, config.disabledRules(), temp.root(), report,
                    config.decompilerType(), config.decompileCache(),
                    config.parallelDecompile(),
                    progressListener);

            List<PipelineStage> stages = List.of(
                    new RemapStage(mappings),
                    new BytecodeTransformStage(),
                    new DecompileStage(),
                    new TransformStage(),
                    new CompileStage());

            // Validate input jar for corrupted entries
            validateInputJar(config.inputJar(), report);

            // Pre-check Mixins against target version jar (Fabric/Quilt).
            if (config.modType() == com.mcmigrator.ModType.FABRIC
                    || config.modType() == com.mcmigrator.ModType.QUILT) {
                preflightMixins(config, classpath, report);
            }

            // Dependency compatibility check
            try {
                var depReport = com.mcmigrator.analysis.DependencyChecker.analyze(
                        config.inputJar(), config.fromVersion(), config.toVersion());
                if (depReport.hasIssues()) {
                    log.warn("[*] Dependency check: {}", depReport.summary());
                    for (var issue : depReport.issues()) {
                        report.addWarning("Dependency: " + issue.modId() + " — " + issue.reason());
                    }
                } else {
                    log.info("[*] Dependency check: {}", depReport.summary());
                }
            } catch (Exception e) {
                log.debug("Dependency check skipped: {}", e.getMessage());
            }

            // Protection / obfuscation pre-check: предупреждаем заранее, до того
            // как ремап «споткнётся» на защищённых классах.
            try (java.util.jar.JarFile jf = new java.util.jar.JarFile(config.inputJar().toFile())) {
                var protection = com.mcmigrator.protection.ProtectionAnalyzer.analyze(jf);
                if (protection.hasProtections()) {
                    log.info("[*] Protection scan: {}", protection.summary());
                    boolean illegalNames = protection.protections().stream().anyMatch(p ->
                            p.type() == com.mcmigrator.protection.ProtectionAnalyzer
                                    .ProtectionType.ILLEGAL_NAME_OBFUSCATION);
                    if (illegalNames) {
                        log.warn("[!] Мод использует обфускацию имён классов недопустимыми "
                                + "символами — ремап и декомпиляция почти наверняка не пройдут. "
                                + "Это защита автора; миграция такого мода обычно невозможна "
                                + "без его официальной сборки под целевую версию.");
                        report.addWarning("Обфускация имён классов (illegal-name): миграция, "
                                + "скорее всего, невозможна — нужна официальная версия мода");
                    }
                    if (!protection.decompilable()) {
                        report.addWarning("Обнаружена защита (score "
                                + Math.round(protection.protectionScore())
                                + "/10): " + protection.summary());
                    }
                }
            } catch (Exception e) {
                log.debug("Protection scan skipped: {}", e.getMessage());
            }

            int totalStages = stages.size();
            for (int i = 0; i < totalStages; i++) {
                PipelineStage stage = stages.get(i);
                if (progressListener != null) {
                    int percent = (i * 100) / totalStages;
                    progressListener.onStageProgress(stage.name(), percent, "Running...");
                }
                log.debug("Stage started: {}", stage.name());
                stage.execute(ctx);
                log.debug("Stage completed: {}", stage.name());
                if (progressListener != null) {
                    int percent = ((i + 1) * 100) / totalStages;
                    progressListener.onStageProgress(stage.name(), percent, "Done");
                }
            }

            finish(ctx);
        } catch (IOException e) {
            throw new MigrationException(
                    "Не удалось подготовить временную директорию: " + e.getMessage(), e);
        }
    }

    private void finish(PipelineContext ctx) {
        if (ctx.dryRun()) {
            log.info("Dry-run завершён — файлы не записаны. Отчёт:");
            ctx.report().render().lines().forEach(line -> log.info("{}", line));
            return;
        }

        if (ctx.keepSources()) {
            copySources(ctx);
        }

        exportExtras(ctx);

        // Resource file patching (fabric.mod.json, plugin.yml, pack.mcmeta, etc.)
        try {
            int patched = com.mcmigrator.util.FabricMetadataPatcher.patch(
                    ctx.outputJar(), ctx.toVersion());
            if (patched > 0) {
                log.info("fabric.mod.json updated: minecraft -> >={} ({} files)",
                        ctx.toVersion(), patched);
            }
        } catch (IOException e) {
            log.warn("Failed to update fabric.mod.json: {}", e.getMessage());
        }

        try {
            int resPatched = com.mcmigrator.util.ResourcePatcher.patchAll(
                    ctx.outputJar(), ctx.toVersion());
            if (resPatched > 0) {
                log.info("Resource files patched: {} entries updated for {}",
                        resPatched, ctx.toVersion());
                ctx.report().addTransformation("[Resource] " + resPatched
                        + " resource file(s) updated for " + ctx.toVersion());
            }
        } catch (IOException e) {
            log.warn("Resource patching failed: {}", e.getMessage());
        }

        Path reportPath = reportPath(ctx.outputJar());
        try {
            ctx.report().writeTo(reportPath);
        } catch (IOException e) {
            log.warn("Failed to write report {}: {}", reportPath, e.getMessage());
        }

        // Export HTML and Markdown reports
        try {
            com.mcmigrator.report.HtmlReportExporter.writeHtml(ctx.report(), reportPath);
            com.mcmigrator.report.HtmlReportExporter.writeMarkdown(ctx.report(), reportPath);
        } catch (IOException e) {
            log.debug("HTML/MD report export failed: {}", e.getMessage());
        }

        try {
            long sizeKb = Files.size(ctx.outputJar()) / 1024;
            log.info("Done! -> {} ({} KB)", ctx.outputJar().getFileName(), sizeKb);
        } catch (IOException e) {
            log.info("Done! -> {}", ctx.outputJar().getFileName());
        }
        log.info("Report: {}", reportPath);
        if (ctx.report().hasManualFixes()) {
            log.warn("{} locations require manual fixes - see report",
                    ctx.report().manualFixCount());
        }
    }

    /** Mixin-предпроверка: вердикт в лог и отчёт, кандидаты-замены для сломанных целей. */
    private void preflightMixins(MigrationConfig config, List<java.nio.file.Path> classpath,
                                 MigrationReport report) {
        java.nio.file.Path mcJar = findMinecraftJar(classpath, config.toVersion());
        if (mcJar == null) {
            log.debug("Mixin-проверка пропущена: jar Minecraft не найден в classpath");
            return;
        }
        try {
            var summary = com.mcmigrator.analysis.MixinAnalyzer.analyze(
                    config.inputJar(), mcJar);
            log.info("[*] Mixin-проверка: {}", summary.verdict());
            if (summary.broken() == 0) {
                return;
            }
            report.addWarning("Mixin-проверка: " + summary.verdict());
            int listed = 0;
            for (var result : summary.results()) {
                if (result.ok() || listed >= 20) {
                    continue;
                }
                listed++;
                if (!result.targetExists()) {
                    report.addManualFix("Mixin " + result.mixinClass()
                            + ": целевой класс " + result.targetClass()
                            + " отсутствует в " + config.toVersion());
                    continue;
                }
                for (String missing : result.missingMembers()) {
                    StringBuilder line = new StringBuilder("Mixin ")
                            .append(result.mixinClass()).append(": в ")
                            .append(result.targetClass()).append(" нет — ").append(missing);
                    if (missing.startsWith("метод ")) {
                        try {
                            var candidates = com.mcmigrator.analysis.MixinPortSuggester
                                    .suggestMethod(mcJar, result.targetClass(),
                                            missing.substring("метод ".length()));
                            if (!candidates.isEmpty()) {
                                line.append("; кандидаты с той же сигнатурой: ")
                                        .append(String.join(", ", candidates));
                            }
                        } catch (IOException ignored) {
                            // подсказка опциональна
                        }
                    }
                    report.addManualFix(line.toString());
                }
            }
        } catch (IOException e) {
            log.warn("Mixin-проверка не удалась: {}", e.getMessage());
        }
    }

    private static java.nio.file.Path findMinecraftJar(List<java.nio.file.Path> classpath,
                                                       String version) {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "(client|server)-" + java.util.regex.Pattern.quote(version)
                        + "-(mojmap|intermediary).*\\.jar");
        return classpath.stream()
                .filter(path -> p.matcher(path.getFileName().toString()).matches())
                .findFirst().orElse(null);
    }

    /** HTML/Markdown-версии отчёта, тест-скрипт и папка diff рядом с выходом. */
    private void exportExtras(PipelineContext ctx) {
        java.nio.file.Path reportPath = reportPath(ctx.outputJar());
        try {
            com.mcmigrator.report.HtmlReportExporter.writeHtml(ctx.report(), reportPath);
            com.mcmigrator.report.HtmlReportExporter.writeMarkdown(ctx.report(), reportPath);
            log.info("Отчёт также сохранён в HTML и Markdown");
        } catch (IOException e) {
            log.warn("HTML/MD-экспорт отчёта не удался: {}", e.getMessage());
        }

        if (ctx.modType() == com.mcmigrator.ModType.FABRIC) {
            try {
                java.nio.file.Path script = com.mcmigrator.util.TestServerScriptGenerator
                        .generate(ctx.outputJar(), ctx.toVersion());
                log.info("Smoke-тест: {} (двойной клик — проверка загрузки мода на сервере)",
                        script.getFileName());
            } catch (IOException e) {
                log.warn("Тест-скрипт не создан: {}", e.getMessage());
            }
        }

        java.nio.file.Path diffsSrc = ctx.workDir().resolve("diffs");
        if (Files.isDirectory(diffsSrc)) {
            java.nio.file.Path diffsDst = ctx.outputJar().resolveSibling(
                    stripJarExtension(ctx.outputJar().getFileName().toString()) + "-diffs");
            try (Stream<java.nio.file.Path> walk = Files.walk(diffsSrc)) {
                for (java.nio.file.Path src : walk.filter(Files::isRegularFile).toList()) {
                    java.nio.file.Path dst = diffsDst.resolve(diffsSrc.relativize(src).toString());
                    Files.createDirectories(dst.getParent());
                    Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
                }
                log.info("Diff изменённых файлов: {}", diffsDst);
            } catch (IOException e) {
                log.warn("Diff не скопированы: {}", e.getMessage());
            }
        }
    }

    private void copySources(PipelineContext ctx) {
        Path target = ctx.outputJar().resolveSibling(
                stripJarExtension(ctx.outputJar().getFileName().toString())
                        + Constants.SOURCES_OUT_SUFFIX);
        try (Stream<Path> walk = Files.walk(ctx.sourcesDir())) {
            List<Path> files = walk.toList();
            for (Path source : files) {
                Path dest = target.resolve(ctx.sourcesDir().relativize(source).toString());
                if (Files.isDirectory(source)) {
                    Files.createDirectories(dest);
                } else {
                    Files.createDirectories(dest.getParent());
                    Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
                }
            }
            log.info("Исходники сохранены: {}", target);
        } catch (IOException e) {
            log.warn("Не удалось сохранить исходники в {}: {}", target, e.getMessage());
        }
    }

    /**
     * Путь к файлу отчёта рядом с выходным jar:
     * {@code my-plugin-1.21.1.jar → my-plugin-1.21.1.report.txt}.
     *
     * @param outputJar путь к выходному jar
     * @return путь к файлу отчёта
     */
    public static Path reportPath(Path outputJar) {
        String name = stripJarExtension(outputJar.getFileName().toString())
                + Constants.REPORT_SUFFIX;
        return outputJar.resolveSibling(name);
    }

    private static String stripJarExtension(String fileName) {
        return fileName.endsWith(".jar")
                ? fileName.substring(0, fileName.length() - ".jar".length())
                : fileName;
    }

    private static void validateInputJar(Path jar, MigrationReport report) {
        try (java.util.jar.JarFile jarFile = new java.util.jar.JarFile(jar.toFile())) {
            int corrupted = 0;
            java.util.Enumeration<java.util.jar.JarEntry> entries = jarFile.entries();
            while (entries.hasMoreElements()) {
                java.util.jar.JarEntry entry = entries.nextElement();
                String name = entry.getName();
                for (int i = 0; i < name.length(); i++) {
                    char c = name.charAt(i);
                    if (c == '\0' || c == '\u0001' || c == '\u0002') {
                        corrupted++;
                        log.warn("Corrupted entry in input jar: contains null/control char at index {}",
                                i);
                        break;
                    }
                }
            }
            if (corrupted > 0) {
                report.addWarning("Input jar contains " + corrupted
                        + " entry(ies) with null/control characters in names. "
                        + "These may cause remap errors. Consider running protection removal first.");
                log.warn("Input jar has {} corrupted entries — remap may fail on these classes", corrupted);
            }
        } catch (IOException e) {
            log.debug("Could not validate input jar: {}", e.getMessage());
        }
    }
}
