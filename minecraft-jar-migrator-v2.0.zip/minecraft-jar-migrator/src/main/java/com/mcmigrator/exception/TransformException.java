package com.mcmigrator.exception;

/** Ошибка этапа трансформации исходников (JavaParser / правила). */
public final class TransformException extends MigrationException {

    /** @param message описание проблемы */
    public TransformException(String message) {
        super(message);
    }

    /**
     * @param message описание проблемы
     * @param cause   исходная причина
     */
    public TransformException(String message, Throwable cause) {
        super(message, cause);
    }
}
