package com.mcmigrator.exception;

/**
 * Базовое исключение пайплайна миграции. Запечатано (sealed): допустимые
 * подтипы — по одному на этап пайплайна плюс ошибки работы с маппингами.
 */
public sealed class MigrationException extends Exception
        permits RemapException, DecompileException, TransformException, CompileException, MappingsException {

    /** @param message понятное человеку описание проблемы */
    public MigrationException(String message) {
        super(message);
    }

    /**
     * @param message понятное человеку описание проблемы
     * @param cause   исходная причина
     */
    public MigrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
