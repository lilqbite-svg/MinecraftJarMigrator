package com.mcmigrator.exception;

/** Ошибка этапа ремаппинга байткода (Tiny Remapper). */
public final class RemapException extends MigrationException {

    /** @param message описание проблемы */
    public RemapException(String message) {
        super(message);
    }

    /**
     * @param message описание проблемы
     * @param cause   исходная причина
     */
    public RemapException(String message, Throwable cause) {
        super(message, cause);
    }
}
