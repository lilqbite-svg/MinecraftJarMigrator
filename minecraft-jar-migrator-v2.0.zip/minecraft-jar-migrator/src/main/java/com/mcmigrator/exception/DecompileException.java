package com.mcmigrator.exception;

/** Ошибка этапа декомпиляции (Vineflower). */
public final class DecompileException extends MigrationException {

    /** @param message описание проблемы */
    public DecompileException(String message) {
        super(message);
    }

    /**
     * @param message описание проблемы
     * @param cause   исходная причина
     */
    public DecompileException(String message, Throwable cause) {
        super(message, cause);
    }
}
