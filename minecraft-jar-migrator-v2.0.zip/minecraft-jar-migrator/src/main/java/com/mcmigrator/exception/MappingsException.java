package com.mcmigrator.exception;

/** Ошибка загрузки, скачивания или конвертации таблиц маппингов. */
public final class MappingsException extends MigrationException {

    /** @param message описание проблемы */
    public MappingsException(String message) {
        super(message);
    }

    /**
     * @param message описание проблемы
     * @param cause   исходная причина
     */
    public MappingsException(String message, Throwable cause) {
        super(message, cause);
    }
}
