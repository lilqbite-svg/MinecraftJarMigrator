package com.mcmigrator.exception;

/** Ошибка этапа рекомпиляции (javax.tools) или сборки выходного jar. */
public final class CompileException extends MigrationException {

    /** @param message описание проблемы */
    public CompileException(String message) {
        super(message);
    }

    /**
     * @param message описание проблемы
     * @param cause   исходная причина
     */
    public CompileException(String message, Throwable cause) {
        super(message, cause);
    }
}
