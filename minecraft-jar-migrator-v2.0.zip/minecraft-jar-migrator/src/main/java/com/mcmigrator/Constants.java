package com.mcmigrator;

/**
 * Все константы инструмента в одном месте — никаких «магических строк»
 * в остальном коде.
 */
public final class Constants {

    /** Имя инструмента для баннера и версии CLI. */
    public static final String TOOL_NAME = "MinecraftJarMigrator";

    /** Версия инструмента. */
    public static final String TOOL_VERSION = "1.0";

    /** Манифест всех версий Minecraft (Mojang). */
    public static final String VERSION_MANIFEST_URL =
            "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";

    /** Неймспейс обфусцированных имён в tiny-маппингах. */
    public static final String NS_OFFICIAL = "official";

    /** Неймспейс читаемых (MojMap) имён в tiny-маппингах. */
    public static final String NS_NAMED = "named";

    /** Суффикс кэшированного tiny-файла маппингов. */
    public static final String MOJMAP_TINY_SUFFIX = "-mojmap-full.tiny";

    /** Суффикс скачанного ProGuard-файла маппингов. */
    public static final String MOJMAP_PROGUARD_SUFFIX = "-mojmap.txt";

    /** Ключ ссылки на серверные маппинги в version.json. */
    public static final String SERVER_MAPPINGS_KEY = "server_mappings";

    /** Ключ ссылки на клиентские маппинги в version.json. */
    public static final String CLIENT_MAPPINGS_KEY = "client_mappings";

    /** Папка кэша маппингов по умолчанию (относительно домашней директории). */
    public static final String DEFAULT_MAPPINGS_DIR = ".mcmigrator/mappings";

    /** Папка кэша результатов декомпиляции. */
    public static final String DECOMPILE_CACHE_DIR = ".mcmigrator/decompile-cache";

    /** Имя промежуточного ремапнутого jar во временной директории. */
    public static final String REMAPPED_JAR = "remapped.jar";

    /** Имя папки с декомпилированными исходниками во временной директории. */
    public static final String SOURCES_DIR = "sources";

    /** Имя папки со скомпилированными классами во временной директории. */
    public static final String CLASSES_DIR = "classes";

    /** Список изменённых трансформациями исходников (во временной директории). */
    public static final String MODIFIED_LIST = "modified-sources.txt";

    /** Префикс временной директории пайплайна. */
    public static final String TEMP_PREFIX = "mcmigrator-";

    /** Шаблон пути к ресурсу с JSON-правилами для пары версий. */
    public static final String RULES_RESOURCE_PATTERN = "/rules/%s-to-%s.json";

    /** Суффикс файла отчёта (добавляется к имени выходного jar без .jar). */
    public static final String REPORT_SUFFIX = ".report.txt";

    /** Суффикс папки с исходниками при --keep-sources. */
    public static final String SOURCES_OUT_SUFFIX = "-sources";

    /** Версия Java для рекомпиляции (--release). */
    public static final String JAVA_RELEASE = "17";

    /** Расширение class-файлов. */
    public static final String CLASS_EXT = ".class";

    /** Расширение java-файлов. */
    public static final String JAVA_EXT = ".java";

    private Constants() {
    }
}
