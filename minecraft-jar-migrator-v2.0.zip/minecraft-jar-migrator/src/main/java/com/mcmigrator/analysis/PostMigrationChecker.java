package com.mcmigrator.analysis;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class PostMigrationChecker {

    private static final Logger log = LoggerFactory.getLogger(PostMigrationChecker.class);

    public record CheckResult(
            List<String> missingClasses,
            List<String> missingMethods,
            List<String> missingFields,
            int totalChecked,
            double compatibilityScore) {

        public boolean isFullyCompatible() {
            return missingClasses.isEmpty() && missingMethods.isEmpty() && missingFields.isEmpty();
        }

        public String summary() {
            if (isFullyCompatible()) {
                return "Fully compatible — no missing references found";
            }
            return String.format("%.0f%% compatible — %d missing classes, %d methods, %d fields",
                    compatibilityScore * 100, missingClasses.size(),
                    missingMethods.size(), missingFields.size());
        }
    }

    private PostMigrationChecker() {
    }

    public static CheckResult check(Path migratedJar, Path targetClasspath) throws IOException {
        Set<String> availableClasses = new HashSet<>();
        Set<String> availableMethods = new HashSet<>();
        Set<String> availableFields = new HashSet<>();

        try (JarFile cp = new JarFile(targetClasspath.toFile())) {
            Enumeration<JarEntry> entries = cp.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (!entry.getName().endsWith(".class")) continue;
                String className = entry.getName().replace('/', '.').replaceAll("\\.class$", "");
                availableClasses.add(className);

                try (InputStream is = cp.getInputStream(entry)) {
                    new ClassReader(is.readAllBytes()).accept(new ClassVisitor(Opcodes.ASM9) {
                        @Override
                        public MethodVisitor visitMethod(int access, String name, String desc,
                                                         String sig, String[] exc) {
                            availableMethods.add(className + "." + name + desc);
                            return null;
                        }
                        @Override
                        public org.objectweb.asm.FieldVisitor visitField(int access, String name,
                                String desc, String sig, Object val) {
                            availableFields.add(className + "." + name);
                            return null;
                        }
                    }, ClassReader.SKIP_CODE);
                }
            }
        }

        List<String> missingClasses = new ArrayList<>();
        List<String> missingMethods = new ArrayList<>();
        List<String> missingFields = new ArrayList<>();
        int totalChecked = 0;

        try (JarFile mod = new JarFile(migratedJar.toFile())) {
            Enumeration<JarEntry> entries = mod.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (!entry.getName().endsWith(".class")) continue;
                totalChecked++;

                try (InputStream is = mod.getInputStream(entry)) {
                    new ClassReader(is.readAllBytes()).accept(new ClassVisitor(Opcodes.ASM9) {
                        @Override
                        public void visit(int version, int access, String name, String signature,
                                          String superName, String[] interfaces) {
                            String superFqn = superName.replace('/', '.');
                            if (!availableClasses.contains(superFqn)
                                    && !superFqn.startsWith("java.")
                                    && !superFqn.equals("java.lang.Object")) {
                                missingClasses.add(superFqn);
                            }
                            if (interfaces != null) {
                                for (String iface : interfaces) {
                                    String fqn = iface.replace('/', '.');
                                    if (!availableClasses.contains(fqn)) {
                                        missingClasses.add(fqn);
                                    }
                                }
                            }
                        }

                        @Override
                        public MethodVisitor visitMethod(int access, String mname, String desc,
                                                         String sig, String[] exc) {
                            return new MethodVisitor(Opcodes.ASM9) {
                                @Override
                                public void visitMethodInsn(int opcode, String owner, String name,
                                                            String descriptor, boolean isInterface) {
                                    String fqn = owner.replace('/', '.');
                                    String key = fqn + "." + name + descriptor;
                                    if (!availableMethods.contains(key)
                                            && availableClasses.contains(fqn)) {
                                        missingMethods.add(key);
                                    }
                                }

                                @Override
                                public void visitFieldInsn(int opcode, String owner, String name,
                                                           String descriptor) {
                                    String fqn = owner.replace('/', '.');
                                    String key = fqn + "." + name;
                                    if (!availableFields.contains(key)
                                            && availableClasses.contains(fqn)) {
                                        missingFields.add(key);
                                    }
                                }
                            };
                        }
                    }, ClassReader.SKIP_CODE);
                }
            }
        }

        int total = missingClasses.size() + missingMethods.size() + missingFields.size();
        double score = totalChecked > 0 ? 1.0 - ((double) total / Math.max(totalChecked * 2, 1)) : 1.0;
        score = Math.max(0, Math.min(1, score));

        return new CheckResult(missingClasses, missingMethods, missingFields, totalChecked, score);
    }
}
