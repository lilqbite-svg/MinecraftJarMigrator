package com.mcmigrator.analysis;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mcmigrator.gui.ModAnalyzer;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Быстрая пред-проверка jar перед миграцией.
 *
 * <p>Цель — поймать самые частые проблемы заранее: source-архив вместо
 * собранного jar, отсутствующие class-файлы, mixin-конфиги с классами,
 * которых нет в архиве, и вложенные библиотеки в {@code META-INF/jars/}.</p>
 */
public final class PreflightChecker {

    private PreflightChecker() {
    }

    /**
     * Результат пред-проверки.
     */
    public record Result(
            boolean readable,
            boolean hasClasses,
            boolean hasSources,
            boolean hasDescriptor,
            String descriptorType,
            List<String> nestedJars,
            List<String> mixinConfigs,
            List<String> missingMixinClasses,
            List<String> warnings,
            List<String> suggestions,
            String graph) {

        public static Result empty() {
            return new Result(false, false, false, false, "не найден",
                    List.of(), List.of(), List.of(), List.of(), List.of(),
                    "Проверка не выполнялась.");
        }
    }

    /**
     * Анализирует jar и возвращает краткий отчёт.
     */
    public static Result inspect(Path jarPath, ModAnalyzer.ModInfo info) {
        try (JarFile jar = new JarFile(jarPath.toFile())) {
            boolean hasClasses = false;
            boolean hasSources = false;
            boolean hasDescriptor = false;
            String descriptorType = "не найден";
            List<String> nestedJars = new ArrayList<>();
            List<String> mixinConfigs = new ArrayList<>();
            List<String> missingMixinClasses = new ArrayList<>();
            List<String> warnings = new ArrayList<>();
            List<String> suggestions = new ArrayList<>();
            List<String> graph = new ArrayList<>();
            Set<String> visitedMixinConfigs = new LinkedHashSet<>();

            graph.add("Jar: " + jarPath.getFileName());

            JarEntry fabric = jar.getJarEntry("fabric.mod.json");
            JarEntry quilt = jar.getJarEntry("quilt.mod.json");
            JarEntry forge = jar.getJarEntry("META-INF/mods.toml");
            JarEntry neoforge = jar.getJarEntry("META-INF/neoforge.mods.toml");
            JarEntry paper = jar.getJarEntry("paper-plugin.yml");
            JarEntry plugin = jar.getJarEntry("plugin.yml");

            if (fabric != null) {
                hasDescriptor = true;
                descriptorType = "fabric.mod.json";
            } else if (quilt != null) {
                hasDescriptor = true;
                descriptorType = "quilt.mod.json";
            } else if (neoforge != null) {
                hasDescriptor = true;
                descriptorType = "META-INF/neoforge.mods.toml";
            } else if (forge != null) {
                hasDescriptor = true;
                descriptorType = "META-INF/mods.toml";
            } else if (paper != null) {
                hasDescriptor = true;
                descriptorType = "paper-plugin.yml";
            } else if (plugin != null) {
                hasDescriptor = true;
                descriptorType = "plugin.yml";
            }

            graph.add("Descriptor: " + descriptorType);

            int scanned = 0;
            for (var entries = jar.entries(); entries.hasMoreElements() && scanned < 6000; scanned++) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                if (name.endsWith(".class")) {
                    hasClasses = true;
                } else if (name.endsWith(".java")) {
                    hasSources = true;
                } else if (name.startsWith("META-INF/jars/") && name.endsWith(".jar")) {
                    nestedJars.add(name.substring("META-INF/jars/".length()));
                } else if (isMixinConfig(name)) {
                    if (visitedMixinConfigs.add(name)) {
                        mixinConfigs.add(name);
                        scanMixinConfig(jar, name, missingMixinClasses, warnings, graph);
                    }
                }
            }

            if (!hasClasses && hasSources) {
                warnings.add("Внутри есть .java, но нет .class — это похоже на source archive, а не на собранный jar.");
                suggestions.add("Собрать проект через Gradle и положить в mods именно готовый jar.");
            }
            if (!hasClasses && !hasSources && !hasDescriptor) {
                warnings.add("Jar не похож на мод/плагин: не найдено ни descriptor-файла, ни классов.");
            }
            if (!nestedJars.isEmpty()) {
                graph.add("Nested jars: " + nestedJars.size());
            }
            if (!mixinConfigs.isEmpty()) {
                graph.add("Mixin configs: " + mixinConfigs.size());
            }
            if (!missingMixinClasses.isEmpty()) {
                warnings.add("В mixin-конфиге найдены классы, которых нет в jar.");
                suggestions.add("Проверьте, что проект собран из исходников, а не упакован source archive.");
            }
            if (info != null && info.intermediary()) {
                suggestions.add("Это production Fabric (intermediary): classpath и mixin-проверка должны учитывать intermediary-имена.");
            }

            StringBuilder graphText = new StringBuilder();
            for (String line : graph) {
                graphText.append(line).append('\n');
            }
            if (!nestedJars.isEmpty()) {
                graphText.append('\n').append("Вложенные библиотеки:\n");
                for (String lib : nestedJars) {
                    graphText.append("  ├─ ").append(lib).append('\n');
                }
            }
            if (!mixinConfigs.isEmpty()) {
                graphText.append('\n').append("Mixin-конфиги:\n");
                for (String cfg : mixinConfigs) {
                    graphText.append("  ├─ ").append(cfg).append('\n');
                }
            }
            if (!missingMixinClasses.isEmpty()) {
                graphText.append('\n').append("Отсутствующие mixin-классы:\n");
                for (String missing : missingMixinClasses) {
                    graphText.append("  ├─ ").append(missing).append('\n');
                }
            }

            return new Result(
                    true,
                    hasClasses,
                    hasSources,
                    hasDescriptor,
                    descriptorType,
                    Collections.unmodifiableList(nestedJars),
                    Collections.unmodifiableList(mixinConfigs),
                    Collections.unmodifiableList(missingMixinClasses),
                    Collections.unmodifiableList(warnings),
                    Collections.unmodifiableList(suggestions),
                    graphText.isEmpty() ? "Проверка не выявила отдельных проблем." : graphText.toString().trim());
        } catch (IOException e) {
            return new Result(false, false, false, false, "ошибка чтения",
                    List.of(), List.of(), List.of(),
                    List.of("Не удалось открыть jar: " + e.getMessage()),
                    List.of(), "Проверка не выполнена: " + e.getMessage());
        }
    }

    private static boolean isMixinConfig(String name) {
        if (!name.endsWith(".json")) {
            return false;
        }
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.contains("mixin") || lower.contains("mixins");
    }

    private static void scanMixinConfig(JarFile jar, String entryName,
                                        List<String> missingMixinClasses,
                                        List<String> warnings,
                                        List<String> graph) {
        try {
            JarEntry entry = jar.getJarEntry(entryName);
            if (entry == null) {
                return;
            }
            String json;
            try (InputStream in = jar.getInputStream(entry)) {
                json = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonObject()) {
                return;
            }
            var obj = root.getAsJsonObject();
            String pkg = obj.has("package") && obj.get("package").isJsonPrimitive()
                    ? obj.get("package").getAsString() : null;
            if (pkg == null || pkg.isBlank()) {
                return;
            }
            List<String> local = new ArrayList<>();
            collectMixinNames(obj.get("mixins"), pkg, jar, missingMixinClasses, local);
            collectMixinNames(obj.get("client"), pkg, jar, missingMixinClasses, local);
            collectMixinNames(obj.get("server"), pkg, jar, missingMixinClasses, local);
            if (!local.isEmpty()) {
                graph.add("  mixins from " + entryName + ": " + String.join(", ", local));
            }
            if (obj.has("refmap")) {
                warnings.add("Mixin config " + entryName + " uses refmap: "
                        + obj.get("refmap").getAsString());
            }
        } catch (Exception e) {
            warnings.add("Не удалось проверить mixin-конфиг " + entryName + ": " + e.getMessage());
        }
    }

    private static void collectMixinNames(JsonElement element, String pkg, JarFile jar,
                                          List<String> missingMixinClasses, List<String> found) {
        if (element == null || element.isJsonNull()) {
            return;
        }
        if (element.isJsonPrimitive()) {
            String name = element.getAsString();
            if (!name.isBlank()) {
                String classPath = pkg.replace('.', '/') + "/" + name.replace('.', '/') + ".class";
                found.add(name);
                if (jar.getEntry(classPath) == null) {
                    missingMixinClasses.add(pkg + "." + name);
                }
            }
            return;
        }
        if (element.isJsonArray()) {
            JsonArray arr = element.getAsJsonArray();
            for (JsonElement item : arr) {
                collectMixinNames(item, pkg, jar, missingMixinClasses, found);
            }
        }
    }
}
