package com.mcmigrator.analysis;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Анализ Mixin'ов мода ДО миграции: для каждой цели (@Mixin target,
 * @Shadow поля/методы) проверяется существование в jar целевой версии
 * Minecraft. Позволяет за секунды узнать, заведётся ли мод, не запуская игру.
 */
public final class MixinAnalyzer {

    private static final Logger log = LoggerFactory.getLogger(MixinAnalyzer.class);

    /** Результат проверки одного миксина. */
    public record MixinResult(
            String mixinClass,
            String targetClass,
            boolean targetExists,
            List<String> missingMembers) {

        /** @return {@code true}, если миксин применится без проблем */
        public boolean ok() {
            return targetExists && missingMembers.isEmpty();
        }
    }

    /** Сводный итог анализа. */
    public record Summary(List<MixinResult> results, int total, int broken) {

        /** @return краткий вердикт для статуса/лога */
        public String verdict() {
            if (total == 0) {
                return "Mixin'ов не найдено";
            }
            if (broken == 0) {
                return "Все " + total + " mixin'ов применятся";
            }
            return broken + " из " + total + " mixin'ов целятся в отсутствующие "
                    + "классы/члены — мод, скорее всего, не заведётся без ручного порта";
        }
    }

    private MixinAnalyzer() {
    }

    /**
     * Анализирует все mixin-конфигурации мода против jar целевой версии.
     *
     * @param modJar          jar мода
     * @param targetMinecraft jar Minecraft целевой версии (в тех же именах, что и мод)
     * @return сводка по каждому миксину
     * @throws IOException при ошибке чтения архивов
     */
    public static Summary analyze(Path modJar, Path targetMinecraft) throws IOException {
        List<MixinResult> results = new ArrayList<>();
        try (JarFile mod = new JarFile(modJar.toFile());
             JarFile mc = new JarFile(targetMinecraft.toFile())) {

            Map<String, String> refmapCache = new HashMap<>();
            for (String config : findMixinConfigs(mod)) {
                JsonObject json = readJson(mod, config);
                if (json == null) {
                    continue;
                }
                String pkg = json.has("package") ? json.get("package").getAsString() : "";
                String refmapName = json.has("refmap") ? json.get("refmap").getAsString() : null;
                JsonObject refmap = refmapName != null
                        ? readRefmap(mod, refmapName, refmapCache) : null;

                for (String list : List.of("mixins", "client", "server")) {
                    if (!json.has(list)) {
                        continue;
                    }
                    for (JsonElement el : json.getAsJsonArray(list)) {
                        String mixinClass = pkg + "." + el.getAsString();
                        results.addAll(checkMixin(mod, mc, mixinClass, refmap));
                    }
                }
            }
        }
        int broken = (int) results.stream().filter(r -> !r.ok()).count();
        return new Summary(results, results.size(), broken);
    }

    private static List<String> findMixinConfigs(JarFile mod) throws IOException {
        List<String> configs = new ArrayList<>();
        // Объявленные в fabric.mod.json
        JsonObject fabricJson = readJson(mod, "fabric.mod.json");
        if (fabricJson != null && fabricJson.has("mixins")) {
            for (JsonElement el : fabricJson.getAsJsonArray("mixins")) {
                if (el.isJsonPrimitive()) {
                    configs.add(el.getAsString());
                } else if (el.isJsonObject() && el.getAsJsonObject().has("config")) {
                    configs.add(el.getAsJsonObject().get("config").getAsString());
                }
            }
        }
        // Плюс все *.mixins.json в корне (Forge и вложенные)
        Enumeration<JarEntry> entries = mod.entries();
        while (entries.hasMoreElements()) {
            String name = entries.nextElement().getName();
            if (!name.contains("/") && name.endsWith(".mixins.json")
                    && !configs.contains(name)) {
                configs.add(name);
            }
        }
        return configs;
    }

    private static List<MixinResult> checkMixin(JarFile mod, JarFile mc,
                                                String mixinClass, JsonObject refmap)
            throws IOException {
        String entryName = mixinClass.replace('.', '/') + ".class";
        JarEntry entry = mod.getJarEntry(entryName);
        if (entry == null) {
            return List.of();
        }
        byte[] bytes;
        try (InputStream in = mod.getInputStream(entry)) {
            bytes = in.readAllBytes();
        }

        MixinClassInfo info = MixinClassInfo.read(bytes);
        List<MixinResult> results = new ArrayList<>();
        for (String rawTarget : info.targets) {
            String target = resolveRef(refmap, mixinClass, rawTarget)
                    .replace('.', '/');
            TargetMembers members = loadTarget(mc, target);
            if (members == null) {
                results.add(new MixinResult(mixinClass, target.replace('/', '.'),
                        false, List.of()));
                continue;
            }
            List<String> missing = new ArrayList<>();
            for (String shadow : info.shadowMethods) {
                String resolved = resolveRef(refmap, mixinClass, shadow);
                if (!members.methods.contains(stripOwner(resolved))) {
                    missing.add("метод " + stripOwner(resolved));
                }
            }
            for (String shadow : info.shadowFields) {
                String resolved = resolveRef(refmap, mixinClass, shadow);
                if (!members.fields.contains(fieldName(resolved))) {
                    missing.add("поле " + fieldName(resolved));
                }
            }
            results.add(new MixinResult(mixinClass, target.replace('/', '.'),
                    true, missing));
        }
        return results;
    }

    /** Подстановка из refmap (production-моды хранят там intermediary-имена). */
    private static String resolveRef(JsonObject refmap, String mixinClass, String name) {
        if (refmap == null || !refmap.has("mappings")) {
            return name;
        }
        JsonObject mappings = refmap.getAsJsonObject("mappings");
        JsonObject classMap = mappings.has(mixinClass)
                ? mappings.getAsJsonObject(mixinClass) : null;
        if (classMap != null && classMap.has(name)) {
            return classMap.get(name).getAsString();
        }
        return name;
    }

    private static String stripOwner(String ref) {
        // "Lnet/minecraft/class_310;method_16011()L...;" → "method_16011()L...;"
        int semicolon = ref.indexOf(';');
        if (ref.startsWith("L") && semicolon > 0 && semicolon < ref.length() - 1) {
            return ref.substring(semicolon + 1);
        }
        return ref;
    }

    private static String fieldName(String ref) {
        String stripped = stripOwner(ref);
        int colon = stripped.indexOf(':');
        return colon > 0 ? stripped.substring(0, colon) : stripped;
    }

    private static TargetMembers loadTarget(JarFile mc, String internalName)
            throws IOException {
        JarEntry entry = mc.getJarEntry(internalName + ".class");
        if (entry == null) {
            return null;
        }
        byte[] bytes;
        try (InputStream in = mc.getInputStream(entry)) {
            bytes = in.readAllBytes();
        }
        TargetMembers members = new TargetMembers();
        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override
            public MethodVisitor visitMethod(int access, String name, String descriptor,
                                             String signature, String[] exceptions) {
                members.methods.add(name + descriptor);
                return null;
            }

            @Override
            public FieldVisitor visitField(int access, String name, String descriptor,
                                           String signature, Object value) {
                members.fields.add(name);
                return null;
            }
        }, ClassReader.SKIP_CODE);
        return members;
    }

    private static JsonObject readJson(JarFile jar, String name) throws IOException {
        JarEntry entry = jar.getJarEntry(name);
        if (entry == null) {
            return null;
        }
        try (InputStream in = jar.getInputStream(entry)) {
            try {
                return JsonParser.parseString(
                        new String(in.readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
            } catch (RuntimeException e) {
                log.debug("Не распарсился {}: {}", name, e.getMessage());
                return null;
            }
        }
    }

    private static JsonObject readRefmap(JarFile jar, String name, Map<String, String> cache)
            throws IOException {
        return readJson(jar, name);
    }

    private static final class TargetMembers {
        final Set<String> methods = new HashSet<>();
        final Set<String> fields = new HashSet<>();
    }

    /** Чтение аннотаций @Mixin/@Shadow из class-файла миксина. */
    private static final class MixinClassInfo {
        final List<String> targets = new ArrayList<>();
        final List<String> shadowMethods = new ArrayList<>();
        final List<String> shadowFields = new ArrayList<>();

        static MixinClassInfo read(byte[] bytes) {
            MixinClassInfo info = new MixinClassInfo();
            new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
                @Override
                public org.objectweb.asm.AnnotationVisitor visitAnnotation(
                        String descriptor, boolean visible) {
                    if (!"Lorg/spongepowered/asm/mixin/Mixin;".equals(descriptor)) {
                        return null;
                    }
                    return new org.objectweb.asm.AnnotationVisitor(Opcodes.ASM9) {
                        @Override
                        public org.objectweb.asm.AnnotationVisitor visitArray(String name) {
                            return new org.objectweb.asm.AnnotationVisitor(Opcodes.ASM9) {
                                @Override
                                public void visit(String n, Object value) {
                                    if (value instanceof Type type) {
                                        info.targets.add(type.getClassName());
                                    } else if (value instanceof String s) {
                                        info.targets.add(s);
                                    }
                                }
                            };
                        }
                    };
                }

                @Override
                public MethodVisitor visitMethod(int access, String name, String descriptor,
                                                 String signature, String[] exceptions) {
                    return new MethodVisitor(Opcodes.ASM9) {
                        @Override
                        public org.objectweb.asm.AnnotationVisitor visitAnnotation(
                                String desc, boolean visible) {
                            if ("Lorg/spongepowered/asm/mixin/Shadow;".equals(desc)) {
                                info.shadowMethods.add(name + descriptor);
                            }
                            return null;
                        }
                    };
                }

                @Override
                public FieldVisitor visitField(int access, String name, String descriptor,
                                               String signature, Object value) {
                    return new FieldVisitor(Opcodes.ASM9) {
                        @Override
                        public org.objectweb.asm.AnnotationVisitor visitAnnotation(
                                String desc, boolean visible) {
                            if ("Lorg/spongepowered/asm/mixin/Shadow;".equals(desc)) {
                                info.shadowFields.add(name);
                            }
                            return null;
                        }
                    };
                }
            }, ClassReader.SKIP_CODE);
            return info;
        }
    }
}
