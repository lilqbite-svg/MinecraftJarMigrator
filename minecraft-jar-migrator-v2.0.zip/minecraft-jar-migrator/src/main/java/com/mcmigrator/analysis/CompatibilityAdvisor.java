package com.mcmigrator.analysis;

import com.mcmigrator.gui.ModAnalyzer;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Простой слой рекомендаций по совместимости.
 *
 * <p>Находит основные зависимости, риски конфликтов и строит
 * текстовый «граф» зависимостей для GUI.</p>
 */
public final class CompatibilityAdvisor {

    private CompatibilityAdvisor() {
    }

    public record Report(
            String summary,
            String matrix,
            String graph,
            List<String> notes,
            List<String> recommendations) {
        public static Report empty() {
            return new Report("Совместимость не рассчитана.",
                    "Нет данных.", "Нет данных.", List.of(), List.of());
        }
    }

    public static Report analyze(ModAnalyzer.ModInfo info, PreflightChecker.Result preflight) {
        List<LibraryCatalog.LibraryMatch> libs = info == null || info.libraries() == null
                ? List.of() : info.libraries();
        Map<LibraryCatalog.Category, List<String>> grouped = new LinkedHashMap<>();
        for (LibraryCatalog.Category category : LibraryCatalog.Category.values()) {
            grouped.put(category, new ArrayList<>());
        }
        for (LibraryCatalog.LibraryMatch match : libs) {
            grouped.get(match.category()).add(match.displayName());
        }

        List<String> notes = new ArrayList<>();
        List<String> recommendations = new ArrayList<>();

        if (info != null && info.loader() != null && info.loader().name().equals("FABRIC")) {
            notes.add("Загрузчик: Fabric.");
        }
        if (info != null && info.intermediary()) {
            notes.add("Класс-файлы собраны в intermediary-именах (production Fabric).");
            recommendations.add("Classpath и mixin-проверку нужно держать в intermediary-режиме.");
        }
        if (preflight != null) {
            if (!preflight.hasClasses() && preflight.hasSources()) {
                recommendations.add("В архиве найден source archive. Для запуска нужен собранный .jar.");
            }
            if (!preflight.missingMixinClasses().isEmpty()) {
                recommendations.add("Mixin-конфиг ссылается на отсутствующие классы: "
                        + String.join(", ", preflight.missingMixinClasses()));
            }
            if (!preflight.nestedJars().isEmpty()) {
                notes.add("Вложенные библиотеки: " + preflight.nestedJars().size());
            }
        }

        boolean hasFabricApi = contains(libs, "fabric api");
        boolean hasMixin = contains(libs, "mixin");
        boolean hasAsm = contains(libs, "asm");
        if (hasFabricApi || hasMixin || hasAsm) {
            notes.add("Базовый стек: Fabric API / Mixin / ASM.");
        }

        boolean hasIris = contains(libs, "iris");
        boolean hasSodium = contains(libs, "sodium");
        boolean hasDimLib = contains(libs, "dimlib");
        if (hasIris || hasSodium) {
            recommendations.add("Рендер-стек нужно держать согласованным: Iris/Sodium/Indium/Canvas могут конфликтовать.");
        }
        if (info != null) {
            String nameId = (safe(info.name()) + " " + safe(info.id())).toLowerCase(Locale.ROOT);
            if (nameId.contains("immersive") && nameId.contains("portal") && !hasDimLib) {
                recommendations.add("Для Immersive Portals ожидается DimLib.");
            }
        }

        StringBuilder matrix = new StringBuilder();
        for (var entry : grouped.entrySet()) {
            if (!entry.getValue().isEmpty()) {
                matrix.append(entry.getKey().label())
                        .append(": ")
                        .append(String.join(", ", entry.getValue()))
                        .append('\n');
            }
        }
        if (matrix.isEmpty()) {
            matrix.append("Библиотеки не обнаружены.\n");
        }

        StringBuilder graph = new StringBuilder();
        graph.append("Проект\n");
        graph.append(" ├─ Loader: ").append(info == null || info.loaderName() == null ? "неизвестен" : info.loaderName()).append('\n');
        graph.append(" ├─ Descriptor: ").append(preflight == null ? "не проверен" : preflight.descriptorType()).append('\n');
        if (info != null && info.name() != null) {
            graph.append(" ├─ Mod: ").append(info.name()).append('\n');
        }
        for (var entry : grouped.entrySet()) {
            if (entry.getValue().isEmpty()) {
                continue;
            }
            graph.append(" ├─ ").append(entry.getKey().label()).append('\n');
            for (int i = 0; i < entry.getValue().size(); i++) {
                graph.append(i == entry.getValue().size() - 1 ? " │   └─ " : " │   ├─ ")
                        .append(entry.getValue().get(i))
                        .append('\n');
            }
        }
        if (preflight != null && !preflight.nestedJars().isEmpty()) {
            graph.append(" └─ Nested jars: ").append(preflight.nestedJars().size()).append('\n');
        }

        String summary = buildSummary(info, preflight, libs.size(), recommendations.size());
        return new Report(summary, matrix.toString().trim(), graph.toString().trim(),
                List.copyOf(notes), List.copyOf(recommendations));
    }

    private static String buildSummary(ModAnalyzer.ModInfo info, PreflightChecker.Result preflight,
                                       int libraryCount, int recommendationCount) {
        String mod = info == null ? "неизвестный мод" : safe(info.name());
        String loader = info == null ? "unknown" : safe(info.loaderName());
        String preflightState = preflight == null ? "без preflight" : (preflight.hasClasses() ? "классы найдены" : "классов нет");
        return mod + " • " + loader + " • библиотек: " + libraryCount
                + " • советов: " + recommendationCount + " • " + preflightState;
    }

    private static boolean contains(List<LibraryCatalog.LibraryMatch> libs, String needle) {
        String n = needle.toLowerCase(Locale.ROOT);
        for (LibraryCatalog.LibraryMatch match : libs) {
            if (match.displayName().toLowerCase(Locale.ROOT).contains(n)) {
                return true;
            }
        }
        return false;
    }

    private static String safe(String value) {
        return value == null || value.isBlank() ? "—" : value;
    }
}
