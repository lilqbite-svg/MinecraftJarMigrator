package com.mcmigrator.analysis;

import com.mcmigrator.ModType;
import com.mcmigrator.rules.VersionRuleSet;
import com.mcmigrator.transform.TransformRule;
import com.mcmigrator.transform.ApiBreakingChangeRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarFile;

public final class ComplexityAnalyzer {

    private static final Logger log = LoggerFactory.getLogger(ComplexityAnalyzer.class);

    public enum Level { TRIVIAL, EASY, MEDIUM, HARD, MANUAL }

    public record ComplexityReport(
            Level level,
            int score,
            int methodRenames,
            int classRenames,
            int packageMoves,
            int breakingChanges,
            int estimatedMixins,
            int classCount,
            List<String> risks,
            String summary) {

        public String levelIcon() {
            return switch (level) {
                case TRIVIAL -> "GREEN";
                case EASY -> "GREEN";
                case MEDIUM -> "YELLOW";
                case HARD -> "RED";
                case MANUAL -> "RED";
            };
        }
    }

    private ComplexityAnalyzer() {
    }

    public static ComplexityReport analyze(Path jar, String from, String to, ModType type) {
        List<String> risks = new ArrayList<>();
        int score = 0;

        VersionRuleSet ruleSet;
        try {
            ruleSet = VersionRuleSet.load(from, to);
        } catch (Exception e) {
            log.debug("Could not load rules for {} -> {}: {}", from, to, e.getMessage());
            return new ComplexityReport(Level.EASY, 0, 0, 0, 0, 0, 0, 0,
                    List.of("Rules not available for this version pair"),
                    "Cannot determine complexity — rules not loaded");
        }
        int methodRenames = 0;
        int classRenames = 0;
        int packageMoves = 0;
        int breakingChanges = 0;

        for (TransformRule rule : ruleSet.toRules()) {
            if (rule instanceof ApiBreakingChangeRule) {
                breakingChanges++;
                score += 10;
            } else if (rule.description().contains("Rename")) {
                methodRenames++;
                score += 1;
            } else if (rule.description().contains("Class")) {
                classRenames++;
                score += 2;
            } else if (rule.description().contains("Package")) {
                packageMoves++;
                score += 3;
            }
        }

        int classCount = 0;
        int estimatedMixins = 0;
        try (JarFile jarFile = new JarFile(jar.toFile())) {
            classCount = (int) jarFile.stream()
                    .filter(e -> e.getName().endsWith(".class"))
                    .count();
            estimatedMixins = (int) jarFile.stream()
                    .filter(e -> e.getName().endsWith(".mixins.json")
                            || e.getName().contains("Mixin"))
                    .count();
        } catch (IOException e) {
            log.debug("Could not read jar for complexity analysis: {}", e.getMessage());
        }

        if (classCount > 500) {
            score += 10;
            risks.add("Large mod (" + classCount + " classes) — migration may take longer");
        }
        if (estimatedMixins > 0) {
            score += estimatedMixins * 5;
            risks.add("Mixin usage detected — may require manual porting");
        }

        int fromMinor = parseMinor(from);
        int toMinor = parseMinor(to);
        int versionGap = Math.abs(toMinor - fromMinor);
        if (versionGap > 5) {
            score += versionGap * 3;
            risks.add("Large version gap (" + versionGap + " minor versions)");
        }
        if (fromMinor < 17 && toMinor >= 17) {
            score += 20;
            risks.add("Crosses 1.17 boundary — NMS package restructuring");
        }
        if (fromMinor < 20 && toMinor >= 20) {
            score += 15;
            risks.add("Crosses 1.20.5 boundary — data components replace NBT");
        }

        if (type == ModType.FORGE || type == ModType.NEOFORGE) {
            score += 10;
            risks.add("Forge/NeoForge — additional classpath complexity");
        }

        Level level;
        if (score <= 10) level = Level.TRIVIAL;
        else if (score <= 30) level = Level.EASY;
        else if (score <= 60) level = Level.MEDIUM;
        else if (score <= 100) level = Level.HARD;
        else level = Level.MANUAL;

        String summary = buildSummary(level, score, methodRenames, breakingChanges, classCount);

        return new ComplexityReport(level, score, methodRenames, classRenames,
                packageMoves, breakingChanges, estimatedMixins, classCount, risks, summary);
    }

    private static int parseMinor(String version) {
        try {
            String[] parts = version.split("\\.");
            return Integer.parseInt(parts[1]);
        } catch (Exception e) {
            return 0;
        }
    }

    private static String buildSummary(Level level, int score, int renames, int breaking, int classes) {
        return switch (level) {
            case TRIVIAL -> "Trivial migration — mostly automatic, few changes needed";
            case EASY -> "Easy migration — " + renames + " renames, should work with minimal effort";
            case MEDIUM -> "Medium complexity — " + breaking + " breaking changes, expect some manual work";
            case HARD -> "Hard migration — significant API changes, expect 1-4 hours of manual work";
            case MANUAL -> "Manual rewrite recommended — too many breaking changes for automatic migration";
        };
    }
}
