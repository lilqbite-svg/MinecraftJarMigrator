package com.mcmigrator.analysis;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class MixinPortSuggester {

    private MixinPortSuggester() {
    }

    public static List<String> suggestMethod(Path minecraftJar, String targetClass,
                                             String missingMethod) throws IOException {
        int paren = missingMethod.indexOf('(');
        if (paren < 0) {
            return List.of();
        }
        String descriptor = missingMethod.substring(paren);
        List<String> candidates = new ArrayList<>();
        try (JarFile jar = new JarFile(minecraftJar.toFile())) {
            JarEntry entry = jar.getJarEntry(targetClass.replace('.', '/') + ".class");
            if (entry == null) {
                return List.of();
            }
            byte[] bytes;
            try (InputStream in = jar.getInputStream(entry)) {
                bytes = in.readAllBytes();
            }
            new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
                @Override
                public MethodVisitor visitMethod(int access, String name, String desc,
                                                 String signature, String[] exceptions) {
                    if (desc.equals(descriptor) && candidates.size() < 5) {
                        candidates.add(name + desc);
                    }
                    return null;
                }
            }, ClassReader.SKIP_CODE);
        }
        return candidates;
    }

    public static List<String> suggestField(Path minecraftJar, String targetClass,
                                            String missingField) throws IOException {
        String fieldName = missingField.contains(":")
                ? missingField.substring(0, missingField.indexOf(':'))
                : missingField;
        String fieldDesc = missingField.contains(":")
                ? missingField.substring(missingField.indexOf(':'))
                : null;

        List<String> candidates = new ArrayList<>();
        try (JarFile jar = new JarFile(minecraftJar.toFile())) {
            JarEntry entry = jar.getJarEntry(targetClass.replace('.', '/') + ".class");
            if (entry == null) {
                return List.of();
            }
            byte[] bytes;
            try (InputStream in = jar.getInputStream(entry)) {
                bytes = in.readAllBytes();
            }
            new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
                @Override
                public FieldVisitor visitField(int access, String name, String desc,
                                               String signature, Object value) {
                    if (fieldDesc == null || fieldDesc.equals(desc)) {
                        if (!name.equals(fieldName) && candidates.size() < 5) {
                            candidates.add(fieldDesc != null ? name + ":" + desc : name);
                        }
                    }
                    return null;
                }
            }, ClassReader.SKIP_CODE);
        }
        return candidates;
    }

    public record AutoPortResult(
            String originalRef,
            String suggestedRef,
            boolean exactMatch,
            String confidence) {}

    public static List<AutoPortResult> findAutoPortable(
            Path minecraftJar, MixinAnalyzer.Summary summary) throws IOException {
        List<AutoPortResult> results = new ArrayList<>();
        for (var result : summary.results()) {
            if (result.ok()) continue;
            for (String missing : result.missingMembers()) {
                if (missing.startsWith("method ")) {
                    String methodSig = missing.substring("method ".length());
                    List<String> suggestions = suggestMethod(
                            minecraftJar, result.targetClass(), methodSig);
                    if (suggestions.size() == 1) {
                        results.add(new AutoPortResult(
                                methodSig, suggestions.get(0), true, "HIGH"));
                    } else if (!suggestions.isEmpty()) {
                        results.add(new AutoPortResult(
                                methodSig, suggestions.get(0), false, "MEDIUM"));
                    }
                } else if (missing.startsWith("field ")) {
                    String fieldSig = missing.substring("field ".length());
                    List<String> suggestions = suggestField(
                            minecraftJar, result.targetClass(), fieldSig);
                    if (suggestions.size() == 1) {
                        results.add(new AutoPortResult(
                                fieldSig, suggestions.get(0), true, "HIGH"));
                    } else if (!suggestions.isEmpty()) {
                        results.add(new AutoPortResult(
                                fieldSig, suggestions.get(0), false, "MEDIUM"));
                    }
                }
            }
        }
        return results;
    }
}
