package com.mcmigrator.analysis;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.regex.Pattern;

/**
 * Каталог широко используемых библиотек, API, core-модов и фреймворков
 * для Minecraft-моддинга.
 *
 * <p>Используется для «best effort» распознавания: анализирует метаданные,
 * manifest, имена файлов внутри архива и сигнатуры пакетов/ресурсов.</p>
 */
public final class LibraryCatalog {

    /**
     * Крупная группа библиотек, чтобы в GUI не показывать длинный плоский список.
     */
    public enum Category {
        CORE("Базовые библиотеки"),
        FRAMEWORK("Фреймворки и совместимость"),
        CONFIG("Конфиги и настройки"),
        GUI("GUI и интерфейсы"),
        ANIMATION("Анимации"),
        RENDERING("Рендеринг"),
        WORLD("Мир и генерация"),
        ENTITY("Сущности и AI"),
        ENERGY("Энергия и машины"),
        NETWORK("Сети"),
        JAVA("Java-библиотеки");

        private final String label;

        Category(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    /**
     * Результат распознавания.
     *
     * @param displayName имя, которое показываем пользователю
     * @param category    категория библиотеки
     * @param evidence    по какому алиасу/сигнатуре совпало
     */
    public record LibraryMatch(String displayName, Category category, String evidence) {
    }

    private record LibrarySpec(String displayName, Category category, String... aliases) {
    }

    private static final int MAX_ENTRY_SCAN = 3500;
    private static final Path CUSTOM_CATALOG = Path.of(System.getProperty("user.home"), ".mcmigrator", "library-catalog.json");
    private static final List<LibrarySpec> BASE_SPECS = List.of(
            // Базовые библиотеки / API / core-библиотеки
            spec("Fabric API", Category.FRAMEWORK, "fabric api", "fabric-api", "fabricmc"),
            spec("Architectury API", Category.FRAMEWORK, "architectury api", "architectury"),
            spec("DimLib", Category.FRAMEWORK, "dimlib"),
            spec("Mixin", Category.FRAMEWORK, "mixin"),
            spec("Mixin Extras", Category.FRAMEWORK, "mixin extras", "mixinextras"),
            spec("ASM", Category.FRAMEWORK, "asm", "org.objectweb.asm"),
            spec("ByteBuddy", Category.FRAMEWORK, "bytebuddy", "byte buddy"),

            spec("Resourceful Lib", Category.CORE, "resourceful lib", "resourceful-lib"),
            spec("Moonlight Lib (Selene)", Category.CORE, "moonlight lib", "selene", "moonlight"),
            spec("Bookshelf", Category.CORE, "bookshelf"),
            spec("Balm", Category.CORE, "balm"),
            spec("Puzzles Lib", Category.CORE, "puzzles lib", "puzzles-lib"),
            spec("Kiwi", Category.CORE, "kiwi"),
            spec("Collective", Category.CORE, "collective"),
            spec("Framework", Category.CORE, "framework"),
            spec("Iceberg", Category.CORE, "iceberg"),
            spec("Blueprint", Category.CORE, "blueprint"),
            spec("Citadel", Category.CORE, "citadel"),
            spec("CorgiLib", Category.CORE, "corgilib", "corgi lib"),
            spec("Botarium", Category.CORE, "botarium"),
            spec("Cupboard", Category.CORE, "cupboard"),
            spec("OctoLib", Category.CORE, "octolib", "octo lib"),
            spec("Cristel Lib", Category.CORE, "cristel lib", "cristellib"),
            spec("GlitchCore", Category.CORE, "glitchcore"),
            spec("CoroUtil", Category.CORE, "coroutil", "coro util"),
            spec("Obscure API", Category.CORE, "obscure api", "obscure-api"),
            spec("Satako Library", Category.CORE, "satako library", "satako"),
            spec("Almanac Lib", Category.CORE, "almanac lib", "almanac"),
            spec("Structure Gel API", Category.CORE, "structure gel api", "structure gel"),
            spec("McJtyLib", Category.CORE, "mcjtylib", "mcjty lib"),
            spec("CodeChickenLib", Category.CORE, "codechickenlib", "code chicken lib"),
            spec("Brandon's Core", Category.CORE, "brandon's core", "brandons core", "brandonscore"),
            spec("Mantle", Category.CORE, "mantle"),
            spec("Cyclops Core", Category.CORE, "cyclops core", "cyclopscore"),
            spec("Athena", Category.CORE, "athena"),
            spec("Fusion", Category.CORE, "fusion"),
            spec("Library Ferret", Category.CORE, "library ferret"),

            // Конфиги
            spec("Cloth Config API", Category.CONFIG, "cloth config", "cloth-config"),
            spec("YACL", Category.CONFIG, "yacl", "yacl3", "yet another config lib"),
            spec("MidnightLib", Category.CONFIG, "midnightlib", "midnight lib"),
            spec("AutoConfig", Category.CONFIG, "autoconfig", "auto config"),
            spec("Omega Config", Category.CONFIG, "omega config"),
            spec("Forge Config API Port", Category.CONFIG, "forge config api port"),
            spec("Resourceful Config", Category.CONFIG, "resourceful config"),
            spec("Configured", Category.CONFIG, "configured"),
            spec("Konkrete", Category.CONFIG, "konkrete"),

            // GUI
            spec("Mod Menu", Category.GUI, "mod menu", "modmenu"),
            spec("EMI", Category.GUI, "emi"),
            spec("REI", Category.GUI, "rei"),
            spec("JEI", Category.GUI, "jei"),
            spec("Jade", Category.GUI, "jade"),
            spec("WTHIT", Category.GUI, "wthit"),
            spec("LibGUI", Category.GUI, "libgui", "lib gui"),
            spec("Cotton GUI", Category.GUI, "cotton gui"),
            spec("owo-lib", Category.GUI, "owo lib", "owo-lib"),
            spec("SpruceUI", Category.GUI, "spruceui", "spruce ui"),

            // Анимации
            spec("GeckoLib", Category.ANIMATION, "geckolib"),
            spec("AzureLib", Category.ANIMATION, "azurelib"),
            spec("Player Animator", Category.ANIMATION, "player animator"),
            spec("BendyLib", Category.ANIMATION, "bendylib"),
            spec("KosmX Animator", Category.ANIMATION, "kosmx animator", "kosm x animator"),
            spec("Not Enough Animations API", Category.ANIMATION, "not enough animations", "not enough animations api"),

            // Рендеринг
            spec("Sodium", Category.RENDERING, "sodium"),
            spec("Iris", Category.RENDERING, "iris"),
            spec("Indium", Category.RENDERING, "indium"),
            spec("Canvas", Category.RENDERING, "canvas"),
            spec("FREX", Category.RENDERING, "frex"),
            spec("Satin API", Category.RENDERING, "satin api", "satin"),
            spec("ImmediatelyFast API", Category.RENDERING, "immediatelyfast", "immediately fast"),
            spec("Entity Model Features (EMF)", Category.RENDERING, "entity model features", "emf"),
            spec("Entity Texture Features (ETF)", Category.RENDERING, "entity texture features", "etf"),

            // Мир и генерация
            spec("TerraBlender", Category.WORLD, "terrablender"),
            spec("Terra", Category.WORLD, "terra"),
            spec("Lithostitched", Category.WORLD, "lithostitched"),
            spec("Terraform API", Category.WORLD, "terraform api", "terraform"),
            spec("YUNG's API", Category.WORLD, "yung's api", "yungs api", "yung api"),
            spec("Dynamic Trees API", Category.WORLD, "dynamic trees api", "dynamic trees"),
            spec("Repurposed Structures API", Category.WORLD, "repurposed structures", "repurposed structures api"),

            // Сущности и AI
            spec("SmartBrainLib", Category.ENTITY, "smartbrainlib"),
            spec("GeckoLib AI Extensions", Category.ENTITY, "geckolib ai", "geckolib ai extensions"),
            spec("Pehkui", Category.ENTITY, "pehkui"),
            spec("Reach Entity Attributes", Category.ENTITY, "reach entity attributes"),
            spec("Additional Entity Attributes", Category.ENTITY, "additional entity attributes"),
            spec("Cardinal Components API", Category.ENTITY, "cardinal components api", "cardinal components"),

            // Энергия и машины
            spec("Team Reborn Energy", Category.ENERGY, "team reborn energy", "reborn energy", "techreborn energy"),
            spec("Botarium Energy", Category.ENERGY, "botarium energy", "botarium"),
            spec("Fabric Transfer API", Category.ENERGY, "fabric transfer api", "fabric-transfer-api"),
            spec("TechReborn API", Category.ENERGY, "techreborn api", "techreborn"),
            spec("Create Fabric API", Category.ENERGY, "create fabric api", "create-fabric-api", "create fabric"),

            // Сети
            spec("Fabric Networking API", Category.NETWORK, "fabric networking api", "fabric-networking-api"),
            spec("Netty", Category.NETWORK, "netty", "io.netty"),
            spec("KryoNet", Category.NETWORK, "kryonet"),
            spec("PacketLib", Category.NETWORK, "packetlib"),
            spec("WebSocket Java", Category.NETWORK, "websocket", "web socket", "tyrus"),

            // Java-библиотеки
            spec("Guava", Category.JAVA, "guava", "com.google.common"),
            spec("Gson", Category.JAVA, "gson", "google gson"),
            spec("Jackson", Category.JAVA, "jackson", "com.fasterxml.jackson"),
            spec("FastUtil", Category.JAVA, "fastutil", "fast util", "it.unimi.dsi.fastutil"),
            spec("Apache Commons Lang", Category.JAVA, "apache commons lang", "commons-lang", "commonslang"),
            spec("Apache Commons IO", Category.JAVA, "apache commons io", "commons-io", "commonsio"),
            spec("Apache Commons Math", Category.JAVA, "apache commons math", "commons-math"),
            spec("JOML", Category.JAVA, "joml"),
            spec("SLF4J", Category.JAVA, "slf4j"),
            spec("Log4j", Category.JAVA, "log4j"),
            spec("Caffeine", Category.JAVA, "caffeine"),
            spec("SQLite JDBC", Category.JAVA, "sqlite jdbc", "sqlite-jdbc"),
            spec("H2 Database", Category.JAVA, "h2 database", "h2"),
            spec("PostgreSQL JDBC", Category.JAVA, "postgresql jdbc", "postgresql"),
            spec("MySQL Connector/J", Category.JAVA, "mysql connector", "mysql connector/j", "mysql-connector"),
            spec("OkHttp", Category.JAVA, "okhttp"),
            spec("Retrofit", Category.JAVA, "retrofit"),
            spec("Jsoup", Category.JAVA, "jsoup"),
            spec("SnakeYAML", Category.JAVA, "snakeyaml", "snake yaml"),
            spec("Protocol Buffers", Category.JAVA, "protocol buffers", "protobuf"),
            spec("FlatBuffers", Category.JAVA, "flatbuffers", "flat buffers"),
            spec("MessagePack", Category.JAVA, "messagepack", "message pack"),
            spec("Kotlin Coroutines", Category.JAVA, "kotlin coroutines", "kotlinx coroutines"),
            spec("kotlinx.serialization", Category.JAVA, "kotlinx serialization", "kotlinx.serialization")
    );


    private static List<LibrarySpec> allSpecs() {
        List<LibrarySpec> specs = new ArrayList<>(BASE_SPECS);
        specs.addAll(loadExternalSpecs());
        return specs;
    }

    private static List<LibrarySpec> loadExternalSpecs() {
        if (!Files.isRegularFile(CUSTOM_CATALOG)) {
            return List.of();
        }
        try {
            String json = Files.readString(CUSTOM_CATALOG, StandardCharsets.UTF_8);
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonArray()) {
                return List.of();
            }
            List<LibrarySpec> out = new ArrayList<>();
            JsonArray arr = root.getAsJsonArray();
            for (JsonElement item : arr) {
                if (!item.isJsonObject()) {
                    continue;
                }
                JsonObject obj = item.getAsJsonObject();
                String displayName = getString(obj, "displayName", "name");
                String categoryName = getString(obj, "category");
                if (displayName == null || categoryName == null) {
                    continue;
                }
                Category category;
                try {
                    category = Category.valueOf(categoryName.toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException ignored) {
                    continue;
                }
                List<String> aliases = new ArrayList<>();
                JsonElement aliasesEl = obj.get("aliases");
                if (aliasesEl != null && aliasesEl.isJsonArray()) {
                    for (JsonElement alias : aliasesEl.getAsJsonArray()) {
                        if (alias.isJsonPrimitive()) {
                            String text = alias.getAsString();
                            if (text != null && !text.isBlank()) {
                                aliases.add(text);
                            }
                        }
                    }
                }
                if (aliases.isEmpty()) {
                    aliases.add(displayName);
                }
                out.add(new LibrarySpec(displayName, category, aliases.toArray(String[]::new)));
            }
            return out;
        } catch (Exception e) {
            return List.of();
        }
    }

    private static String getString(JsonObject obj, String... keys) {
        for (String key : keys) {
            JsonElement el = obj.get(key);
            if (el != null && el.isJsonPrimitive()) {
                String value = el.getAsString();
                if (value != null && !value.isBlank()) {
                    return value;
                }
            }
        }
        return null;
    }

    private LibraryCatalog() {
    }

    public static List<LibraryMatch> detect(JarFile jar) throws IOException {
        String signals = collectSignals(jar);
        if (signals.isBlank()) {
            return List.of();
        }
        String normalized = normalize(signals);
        List<LibraryMatch> matches = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (LibrarySpec spec : allSpecs()) {
            String evidence = findEvidence(normalized, spec.aliases());
            if (evidence != null && seen.add(spec.displayName())) {
                matches.add(new LibraryMatch(spec.displayName(), spec.category(), evidence));
            }
        }
        return Collections.unmodifiableList(matches);
    }

    private static LibrarySpec spec(String displayName, Category category, String... aliases) {
        return new LibrarySpec(displayName, category, aliases);
    }

    private static String collectSignals(JarFile jar) throws IOException {
        StringBuilder sb = new StringBuilder(64_000);

        Manifest manifest = jar.getManifest();
        if (manifest != null) {
            Attributes attrs = manifest.getMainAttributes();
            for (String key : List.of(
                    "Implementation-Title",
                    "Implementation-Version",
                    "Implementation-Vendor",
                    "Specification-Title",
                    "Specification-Version",
                    "Automatic-Module-Name",
                    "Built-By")) {
                appendIfPresent(sb, attrs.getValue(key));
            }
        }

        for (String entryName : List.of(
                "fabric.mod.json",
                "quilt.mod.json",
                "META-INF/mods.toml",
                "META-INF/neoforge.mods.toml",
                "paper-plugin.yml",
                "plugin.yml")) {
            appendEntry(sb, jar, entryName);
        }

        Enumeration<JarEntry> entries = jar.entries();
        int scanned = 0;
        while (entries.hasMoreElements() && scanned < MAX_ENTRY_SCAN) {
            JarEntry entry = entries.nextElement();
            String name = entry.getName();
            if (name.startsWith("META-INF/jars/") && name.endsWith(".jar")) {
                appendIfPresent(sb, name);
            } else if (name.endsWith(".class")) {
                appendIfPresent(sb, name.replace('/', '.'));
            } else if (name.endsWith(".json") || name.endsWith(".yml") || name.endsWith(".toml")) {
                appendIfPresent(sb, name);
            }
            scanned++;
        }

        return sb.toString();
    }

    private static void appendEntry(StringBuilder sb, JarFile jar, String entryName) throws IOException {
        JarEntry entry = jar.getJarEntry(entryName);
        if (entry == null) {
            return;
        }
        try (InputStream in = jar.getInputStream(entry)) {
            sb.append('\n').append(new String(in.readAllBytes(), StandardCharsets.UTF_8));
        }
    }

    private static void appendIfPresent(StringBuilder sb, String text) {
        if (text != null && !text.isBlank()) {
            sb.append('\n').append(text);
        }
    }

    private static String findEvidence(String normalizedSignals, String[] aliases) {
        for (String alias : aliases) {
            String normAlias = normalize(alias);
            if (normAlias.isBlank()) {
                continue;
            }
            Pattern pattern = Pattern.compile("(^|\\s)" + Pattern.quote(normAlias) + "(\\s|$)");
            if (pattern.matcher(normalizedSignals).find()) {
                return alias;
            }
        }
        return null;
    }

    private static String normalize(String text) {
        return text == null ? ""
                : text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }
}
