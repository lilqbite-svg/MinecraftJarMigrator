package com.mcmigrator.analysis;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class DependencyChecker {

    private static final Logger log = LoggerFactory.getLogger(DependencyChecker.class);

    public record DependencyIssue(
            String modId,
            String requiredVersion,
            String reason,
            String suggestion) {}

    public record DependencyReport(
            List<String> dependencies,
            List<DependencyIssue> issues,
            List<String> warnings) {

        public boolean hasIssues() {
            return !issues.isEmpty();
        }

        public String summary() {
            if (issues.isEmpty() && warnings.isEmpty()) {
                return dependencies.size() + " dependencies found, all compatible.";
            }
            return dependencies.size() + " deps, " + issues.size()
                    + " issues, " + warnings.size() + " warnings.";
        }
    }

    private DependencyChecker() {
    }

    public static DependencyReport analyze(Path modJar, String fromVersion, String toVersion) {
        List<String> dependencies = new ArrayList<>();
        List<DependencyIssue> issues = new ArrayList<>();
        List<String> warnings = new ArrayList<>();

        try (JarFile jar = new JarFile(modJar.toFile())) {
            analyzeFabricModJson(jar, fromVersion, toVersion, dependencies, issues, warnings);
            analyzeModsToml(jar, fromVersion, toVersion, dependencies, issues, warnings);
            analyzePluginYml(jar, fromVersion, toVersion, dependencies, issues, warnings);
        } catch (IOException e) {
            warnings.add("Could not read jar for dependency analysis: " + e.getMessage());
        }

        return new DependencyReport(dependencies, issues, warnings);
    }

    private static void analyzeFabricModJson(JarFile jar, String from, String to,
            List<String> deps, List<DependencyIssue> issues, List<String> warnings) {
        JsonObject json = readJson(jar, "fabric.mod.json");
        if (json == null) return;

        if (json.has("depends")) {
            JsonObject depends = json.getAsJsonObject("depends");
            for (String key : depends.keySet()) {
                deps.add(key);
                JsonElement val = depends.get(key);
                if (val.isJsonPrimitive()) {
                    String version = val.getAsString();
                    checkFabricDep(key, version, to, issues, warnings);
                } else if (val.isJsonArray()) {
                    for (JsonElement el : val.getAsJsonArray()) {
                        checkFabricDep(key, el.getAsString(), to, issues, warnings);
                    }
                }
            }
        }

        if (json.has("suggests")) {
            JsonObject suggests = json.getAsJsonObject("suggests");
            for (String key : suggests.keySet()) {
                deps.add(key + " (suggested)");
            }
        }

        if (json.has("breaks")) {
            JsonObject breaks = json.getAsJsonObject("breaks");
            for (String key : breaks.keySet()) {
                JsonElement val = breaks.get(key);
                if (val.isJsonPrimitive()) {
                    issues.add(new DependencyIssue(key, val.getAsString(),
                            "Listed in 'breaks' section",
                            "Remove or update the breaks constraint for " + key));
                }
            }
        }
    }

    private static void checkFabricDep(String depId, String constraint, String toVersion,
            List<DependencyIssue> issues, List<String> warnings) {
        if ("minecraft".equals(depId)) {
            if (constraint.startsWith("=") || constraint.startsWith("~")) {
                String required = constraint.substring(1).trim();
                if (!versionSatisfies(required, toVersion)) {
                    issues.add(new DependencyIssue(depId, constraint,
                            "Minecraft version constraint " + constraint
                                    + " may not match target " + toVersion,
                            "Update 'depends.minecraft' to '>=" + toVersion + "'"));
                }
            }
        }
        if ("fabricloader".equals(depId)) {
            if (constraint.startsWith(">=")) {
                String minLoader = constraint.substring(2).trim();
                if (compareVersions(minLoader, "0.15.0") > 0) {
                    warnings.add("Requires Fabric Loader " + constraint
                            + " — ensure the target environment has this version.");
                }
            }
        }
    }

    private static void analyzeModsToml(JarFile jar, String from, String to,
            List<String> deps, List<DependencyIssue> issues, List<String> warnings) {
        String content = readText(jar, "META-INF/mods.toml");
        if (content == null) {
            content = readText(jar, "META-INF/neoforge.mods.toml");
        }
        if (content == null) return;

        for (String line : content.split("\n")) {
            line = line.trim();
            if (line.startsWith("modId")) {
                String id = extractTomlValue(line);
                if (id != null) deps.add(id);
            }
        }

        if (content.contains("minecraft") && content.contains("[[dependencies.")) {
            int mcIdx = content.indexOf("minecraft", content.indexOf("[[dependencies."));
            if (mcIdx > 0) {
                String after = content.substring(Math.max(0, mcIdx - 200), 
                        Math.min(content.length(), mcIdx + 200));
                if (after.contains("versionRange")) {
                    String range = extractTomlQuoted(after, "versionRange");
                    if (range != null && range.startsWith("[")) {
                        String minVersion = range.substring(1, range.indexOf(',')).trim();
                        if (!versionSatisfies(minVersion, to)) {
                            issues.add(new DependencyIssue("minecraft", range,
                                    "Forge/NeoForge version range may not match " + to,
                                    "Update versionRange to include " + to));
                        }
                    }
                }
            }
        }
    }

    private static void analyzePluginYml(JarFile jar, String from, String to,
            List<String> deps, List<DependencyIssue> issues, List<String> warnings) {
        String content = readText(jar, "plugin.yml");
        if (content == null) {
            content = readText(jar, "paper-plugin.yml");
        }
        if (content == null) return;

        for (String line : content.split("\n")) {
            line = line.trim();
            if (line.startsWith("name:") || line.startsWith("name :")) {
                deps.add(extractYamlValue(line));
            }
            if (line.startsWith("api-version:")) {
                String apiVer = extractYamlValue(line);
                if (apiVer != null) {
                    String toMajor = to.contains(".") ? to.substring(0, to.lastIndexOf('.')) : to;
                    if (!apiVer.equals(toMajor) && !apiVer.equals(to)) {
                        issues.add(new DependencyIssue("Bukkit API", apiVer,
                                "api-version " + apiVer + " may not match " + to,
                                "Set api-version to \"" + toMajor + "\""));
                    }
                }
            }
            if (line.startsWith("depend:") || line.startsWith("softdepend:")) {
                warnings.add("Plugin declares dependencies — verify compatibility with " + to);
            }
        }
    }

    private static boolean versionSatisfies(String required, String actual) {
        return compareVersions(required, actual) <= 0;
    }

    private static int compareVersions(String a, String b) {
        String[] pa = a.split("\\.");
        String[] pb = b.split("\\.");
        int len = Math.max(pa.length, pb.length);
        for (int i = 0; i < len; i++) {
            int na = i < pa.length ? parseInt(pa[i]) : 0;
            int nb = i < pb.length ? parseInt(pb[i]) : 0;
            if (na != nb) return na - nb;
        }
        return 0;
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return 0; }
    }

    private static JsonObject readJson(JarFile jar, String name) {
        JarEntry entry = jar.getJarEntry(name);
        if (entry == null) return null;
        try (InputStream in = jar.getInputStream(entry)) {
            return JsonParser.parseString(new String(in.readAllBytes(), StandardCharsets.UTF_8))
                    .getAsJsonObject();
        } catch (Exception e) {
            log.debug("Failed to parse {}: {}", name, e.getMessage());
            return null;
        }
    }

    private static String readText(JarFile jar, String name) {
        JarEntry entry = jar.getJarEntry(name);
        if (entry == null) return null;
        try (InputStream in = jar.getInputStream(entry)) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    private static String extractTomlValue(String line) {
        int eq = line.indexOf('=');
        if (eq < 0) return null;
        return line.substring(eq + 1).trim().replace("\"", "");
    }

    private static String extractTomlQuoted(String text, String key) {
        int idx = text.indexOf(key);
        if (idx < 0) return null;
        int eq = text.indexOf('=', idx);
        if (eq < 0) return null;
        int start = text.indexOf('"', eq);
        int end = text.indexOf('"', start + 1);
        if (start < 0 || end < 0) return null;
        return text.substring(start + 1, end);
    }

    private static String extractYamlValue(String line) {
        int colon = line.indexOf(':');
        if (colon < 0) return null;
        return line.substring(colon + 1).trim().replace("\"", "");
    }
}
