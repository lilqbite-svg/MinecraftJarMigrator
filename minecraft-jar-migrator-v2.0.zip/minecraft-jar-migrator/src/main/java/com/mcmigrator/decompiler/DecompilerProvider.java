package com.mcmigrator.decompiler;

import com.mcmigrator.Constants;
import com.mcmigrator.exception.DecompileException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.Manifest;
import java.util.ArrayList;
import java.util.List;

public final class DecompilerProvider {

    private static final Logger log = LoggerFactory.getLogger(DecompilerProvider.class);

    private DecompilerProvider() {
    }

    public static void decompile(Path remappedJar, Path sourcesDir, DecompilerType type)
            throws DecompileException {
        switch (type) {
            case VINEFLOWER -> decompileVineflower(remappedJar, sourcesDir);
            case CFR -> decompileCfr(remappedJar, sourcesDir);
            case PROCYON -> decompileProcyon(remappedJar, sourcesDir);
        }
    }

    public static DecompileResult decompileWithFallback(Path remappedJar, Path sourcesDir)
            throws DecompileException {
        DecompilerType[] order = {DecompilerType.VINEFLOWER, DecompilerType.CFR, DecompilerType.PROCYON};
        List<String> errors = new ArrayList<>();

        for (DecompilerType type : order) {
            try {
                Path tempDir = Files.createTempDirectory("decompile-" + type.name().toLowerCase());
                decompile(remappedJar, tempDir, type);
                long count = Files.walk(tempDir)
                        .filter(p -> p.toString().endsWith(Constants.JAVA_EXT))
                        .count();
                if (count > 0) {
                    copyDir(tempDir, sourcesDir);
                    deleteRecursive(tempDir);
                    log.info("[3/4] Fallback decompile ({}) — {} classes", type.getDisplayName(), count);
                    return new DecompileResult(type, (int) count, errors);
                }
                errors.add(type.getDisplayName() + ": 0 classes produced");
                deleteRecursive(tempDir);
            } catch (Exception e) {
                errors.add(type.getDisplayName() + ": " + e.getMessage());
                log.debug("Decompiler {} failed: {}", type.getDisplayName(), e.getMessage());
            }
        }
        throw new DecompileException("All decompilers failed: " + String.join("; ", errors));
    }

    public record DecompileResult(DecompilerType used, int classCount, List<String> errors) {}

    private static void decompileVineflower(Path remappedJar, Path sourcesDir)
            throws DecompileException {
        try {
            Files.createDirectories(sourcesDir);
        } catch (IOException e) {
            throw new DecompileException("Failed to create " + sourcesDir, e);
        }

        java.util.Map<String, Object> options = new java.util.HashMap<>();
        options.put("din", "1");
        options.put("rsy", "1");
        options.put("inn", "0");
        options.put("ind", "    ");

        VineflowerSaver saver = new VineflowerSaver(sourcesDir);
        org.jetbrains.java.decompiler.main.Fernflower decompiler =
                new org.jetbrains.java.decompiler.main.Fernflower(
                        saver, options, new VineflowerLogger());
        try {
            decompiler.addSource(remappedJar.toFile());
            decompiler.decompileContext();
        } catch (java.io.UncheckedIOException e) {
            throw new DecompileException("Write error: " + e.getMessage(), e.getCause());
        } catch (RuntimeException e) {
            throw new DecompileException("Vineflower failed: " + e.getMessage(), e);
        } finally {
            decompiler.clearContext();
        }

        int count = saver.savedCount();
        if (count == 0) {
            throw new DecompileException("Decompilation produced 0 .java files");
        }
        log.info("[3/4] Decompiling (Vineflower)... {} classes decompiled", count);
    }

    private static void decompileCfr(Path remappedJar, Path sourcesDir)
            throws DecompileException {
        try {
            Files.createDirectories(sourcesDir);
        } catch (IOException e) {
            throw new DecompileException("Failed to create " + sourcesDir, e);
        }
        log.info("[3/4] Decompiling (CFR)...");

        AtomicInteger count = new AtomicInteger();
        // CFR отдаёт результат через sink; пишем .java сами по имени класса.
        org.benf.cfr.reader.api.OutputSinkFactory sinkFactory =
                new org.benf.cfr.reader.api.OutputSinkFactory() {
            @Override
            public java.util.List<SinkClass> getSupportedSinks(
                    SinkType sinkType, java.util.Collection<SinkClass> available) {
                if (sinkType == SinkType.JAVA && available.contains(SinkClass.DECOMPILED)) {
                    return java.util.List.of(SinkClass.DECOMPILED, SinkClass.STRING);
                }
                return java.util.Collections.singletonList(SinkClass.STRING);
            }

            @Override
            public <T> Sink<T> getSink(SinkType sinkType, SinkClass sinkClass) {
                if (sinkType == SinkType.JAVA && sinkClass == SinkClass.DECOMPILED) {
                    return obj -> writeCfrClass(
                            (org.benf.cfr.reader.api.SinkReturns.Decompiled) obj,
                            sourcesDir, count);
                }
                if (sinkType == SinkType.EXCEPTION) {
                    return obj -> log.debug("CFR: {}", obj);
                }
                return obj -> { };
            }
        };

        java.util.Map<String, String> opts = new java.util.HashMap<>();
        opts.put("silent", "true");
        opts.put("comments", "false");
        org.benf.cfr.reader.api.CfrDriver driver =
                new org.benf.cfr.reader.api.CfrDriver.Builder()
                        .withOutputSink(sinkFactory)
                        .withOptions(opts)
                        .build();
        try {
            driver.analyse(java.util.List.of(remappedJar.toAbsolutePath().toString()));
        } catch (RuntimeException e) {
            throw new DecompileException("CFR decompilation failed: " + e.getMessage(), e);
        }

        if (count.get() == 0) {
            throw new DecompileException("CFR produced 0 .java files");
        }
        log.info("[3/4] Decompiling (CFR)... {} classes decompiled", count.get());
    }

    /** Пишет один декомпилированный CFR-класс в дерево исходников. */
    private static void writeCfrClass(org.benf.cfr.reader.api.SinkReturns.Decompiled decompiled,
                                      Path sourcesDir, AtomicInteger count) {
        String pkg = decompiled.getPackageName();
        String relative = (pkg == null || pkg.isEmpty() ? "" : pkg.replace('.', '/') + "/")
                + decompiled.getClassName() + Constants.JAVA_EXT;
        try {
            Path target = sourcesDir.resolve(relative).normalize();
            if (!target.startsWith(sourcesDir)) {
                return;
            }
            Files.createDirectories(target.getParent());
            Files.writeString(target, decompiled.getJava(), StandardCharsets.UTF_8);
            count.incrementAndGet();
        } catch (IOException e) {
            log.debug("CFR: failed to write {}: {}", relative, e.getMessage());
        }
    }

    private static void decompileProcyon(Path remappedJar, Path sourcesDir)
            throws DecompileException {
        try {
            Files.createDirectories(sourcesDir);
        } catch (IOException e) {
            throw new DecompileException("Failed to create " + sourcesDir, e);
        }
        log.info("[3/4] Decompiling (Procyon)...");

        java.util.List<String> internalNames = new ArrayList<>();
        try (java.util.jar.JarFile jar = new java.util.jar.JarFile(remappedJar.toFile())) {
            var entries = jar.entries();
            while (entries.hasMoreElements()) {
                String name = entries.nextElement().getName();
                if (name.endsWith(".class") && !name.contains("$")) {
                    internalNames.add(name.substring(0, name.length() - ".class".length()));
                }
            }
        } catch (IOException e) {
            throw new DecompileException("Procyon: cannot read jar: " + e.getMessage(), e);
        }

        com.strobel.decompiler.DecompilerSettings settings =
                com.strobel.decompiler.DecompilerSettings.javaDefaults();
        com.strobel.decompiler.languages.java.JavaLanguage language =
                new com.strobel.decompiler.languages.java.JavaLanguage();
        int count = 0;
        try (java.util.jar.JarFile jar = new java.util.jar.JarFile(remappedJar.toFile())) {
            settings.setTypeLoader(new com.strobel.assembler.metadata.JarTypeLoader(jar));
            com.strobel.decompiler.DecompilationOptions context =
                    new com.strobel.decompiler.DecompilationOptions();
            context.setSettings(settings);
            com.strobel.assembler.metadata.MetadataSystem metadataSystem =
                    new com.strobel.assembler.metadata.MetadataSystem(settings.getTypeLoader());

            for (String internalName : internalNames) {
                try {
                    var typeRef = metadataSystem.lookupType(internalName);
                    if (typeRef == null) {
                        continue;
                    }
                    var resolved = typeRef.resolve();
                    if (resolved == null) {
                        continue;
                    }
                    java.io.StringWriter writer = new java.io.StringWriter();
                    language.decompileType(resolved,
                            new com.strobel.decompiler.PlainTextOutput(writer), context);
                    String java = writer.toString();
                    if (java.isBlank()) {
                        continue;
                    }
                    Path target = sourcesDir.resolve(internalName + Constants.JAVA_EXT).normalize();
                    if (!target.startsWith(sourcesDir)) {
                        continue;
                    }
                    Files.createDirectories(target.getParent());
                    Files.writeString(target, java, StandardCharsets.UTF_8);
                    count++;
                } catch (RuntimeException | IOException e) {
                    log.debug("Procyon: skipped {}: {}", internalName, e.getMessage());
                }
            }
        } catch (IOException e) {
            throw new DecompileException("Procyon: cannot read jar: " + e.getMessage(), e);
        }

        if (count == 0) {
            throw new DecompileException("Procyon produced 0 .java files");
        }
        log.info("[3/4] Decompiling (Procyon)... {} classes decompiled", count);
    }

    private static final class VineflowerSaver
            implements org.jetbrains.java.decompiler.main.extern.IResultSaver {

        private final Path root;
        private final AtomicInteger saved = new AtomicInteger();

        VineflowerSaver(Path root) {
            this.root = root;
        }

        int savedCount() {
            return saved.get();
        }

        @Override
        public void saveClassFile(String path, String qualifiedName, String entryName,
                                  String content, int[] mapping) {
            write(qualifiedName + Constants.JAVA_EXT, content);
        }

        @Override
        public void saveClassEntry(String path, String archiveName, String qualifiedName,
                                   String entryName, String content) {
            write(entryName, content);
        }

        private void write(String relative, String content) {
            if (content == null) return;
            try {
                Path target = root.resolve(relative).normalize();
                if (!target.startsWith(root)) return;
                Files.createDirectories(target.getParent());
                Files.writeString(target, content, StandardCharsets.UTF_8);
                saved.incrementAndGet();
            } catch (IOException e) {
                throw new java.io.UncheckedIOException(e);
            }
        }

        @Override public void saveFolder(String path) {}
        @Override public void copyFile(String source, String path, String entryName) {}
        @Override public void createArchive(String path, String archiveName, Manifest manifest) {}
        @Override public void saveDirEntry(String path, String archiveName, String entryName) {}
        @Override public void copyEntry(String source, String path, String archiveName, String entry) {}
        @Override public void closeArchive(String path, String archiveName) {}
    }

    private static final class VineflowerLogger
            extends org.jetbrains.java.decompiler.main.extern.IFernflowerLogger {

        @Override
        public void writeMessage(String message, Severity severity) {
            logBySeverity(message, severity, null);
        }

        @Override
        public void writeMessage(String message, Severity severity, Throwable t) {
            logBySeverity(message, severity, t);
        }

        private void logBySeverity(String message, Severity severity, Throwable t) {
            switch (severity) {
                case ERROR -> log.error("Decompiler: {}", message, t);
                case WARN -> log.warn("Decompiler: {}", message);
                default -> log.debug("Decompiler: {}", message);
            }
        }
    }

    private static void copyDir(Path src, Path dst) throws IOException {
        Files.createDirectories(dst);
        java.nio.file.SimpleFileVisitor<Path> visitor = new java.nio.file.SimpleFileVisitor<>() {
            @Override
            public java.nio.file.FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) throws IOException {
                Files.createDirectories(dst.resolve(src.relativize(dir)));
                return java.nio.file.FileVisitResult.CONTINUE;
            }
            @Override
            public java.nio.file.FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) throws IOException {
                Files.copy(file, dst.resolve(src.relativize(file)));
                return java.nio.file.FileVisitResult.CONTINUE;
            }
        };
        Files.walkFileTree(src, visitor);
    }

    private static void deleteRecursive(Path dir) {
        try {
            if (!Files.exists(dir)) return;
            Files.walkFileTree(dir, new java.nio.file.SimpleFileVisitor<>() {
                @Override
                public java.nio.file.FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) throws IOException {
                    Files.delete(file);
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
                @Override
                public java.nio.file.FileVisitResult postVisitDirectory(Path d, IOException exc) throws IOException {
                    Files.delete(d);
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) {}
    }
}
