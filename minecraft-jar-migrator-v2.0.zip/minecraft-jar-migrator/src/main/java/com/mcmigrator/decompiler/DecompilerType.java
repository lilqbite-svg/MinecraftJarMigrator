package com.mcmigrator.decompiler;

public enum DecompilerType {
    VINEFLOWER("Vineflower (Recommended)"),
    CFR("CFR"),
    PROCYON("Procyon");

    private final String displayName;

    DecompilerType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
