package com.mcmigrator.decompiler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.ServiceLoader;

public final class DecompilerPluginLoader {

    private static final Logger log = LoggerFactory.getLogger(DecompilerPluginLoader.class);

    public interface DecompilerPlugin {
        String name();
        String version();
        void decompile(Path jar, Path outputDir) throws Exception;
    }

    private DecompilerPluginLoader() {
    }

    public static List<DecompilerPlugin> loadPlugins(Path pluginDir) {
        List<DecompilerPlugin> plugins = new ArrayList<>();
        if (!Files.isDirectory(pluginDir)) return plugins;

        try {
            List<URL> urls = new ArrayList<>();
            try (var stream = Files.list(pluginDir)) {
                stream.filter(p -> p.toString().endsWith(".jar"))
                        .forEach(p -> {
                            try { urls.add(p.toUri().toURL()); }
                            catch (Exception ignored) {}
                        });
            }

            if (urls.isEmpty()) return plugins;

            URLClassLoader cl = new URLClassLoader(urls.toArray(new URL[0]),
                    DecompilerPluginLoader.class.getClassLoader());
            ServiceLoader<DecompilerPlugin> loader = ServiceLoader.load(
                    DecompilerPlugin.class, cl);
            for (DecompilerPlugin plugin : loader) {
                plugins.add(plugin);
                log.info("Loaded decompiler plugin: {} v{}", plugin.name(), plugin.version());
            }
        } catch (Exception e) {
            log.debug("Failed to load decompiler plugins: {}", e.getMessage());
        }
        return plugins;
    }
}
