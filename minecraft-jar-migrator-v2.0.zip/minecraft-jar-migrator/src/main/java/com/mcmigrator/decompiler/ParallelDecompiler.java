package com.mcmigrator.decompiler;

import com.mcmigrator.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class ParallelDecompiler {

    private static final Logger log = LoggerFactory.getLogger(ParallelDecompiler.class);
    private static final int DEFAULT_THREADS = Runtime.getRuntime().availableProcessors();

    public static void decompileParallel(Path remappedJar, Path sourcesDir,
                                          DecompilerType type, int threads) throws Exception {
        if (threads <= 0) threads = DEFAULT_THREADS;
        log.info("[3/4] Parallel decompilation ({} threads, {})...", threads, type.getDisplayName());

        List<String> classNames = new ArrayList<>();
        try (JarFile jar = new JarFile(remappedJar.toFile())) {
            jar.stream()
                    .filter(e -> e.getName().endsWith(".class"))
                    .forEach(e -> classNames.add(e.getName()));
        }

        int chunkSize = Math.max(1, classNames.size() / threads);
        List<List<String>> chunks = new ArrayList<>();
        for (int i = 0; i < classNames.size(); i += chunkSize) {
            chunks.add(classNames.subList(i, Math.min(i + chunkSize, classNames.size())));
        }

        Files.createDirectories(sourcesDir);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        List<Future<Integer>> futures = new ArrayList<>();

        for (List<String> chunk : chunks) {
            futures.add(pool.submit(() -> {
                Path chunkDir = Files.createTempDirectory("decompile-chunk-");
                try {
                    Path chunkJar = createChunkJar(remappedJar, chunk, chunkDir);
                    DecompilerProvider.decompile(chunkJar, chunkDir.resolve("src"), type);
                    copyJavaFiles(chunkDir.resolve("src"), sourcesDir);
                    return chunk.size();
                } finally {
                    deleteRecursive(chunkDir);
                }
            }));
        }

        int total = 0;
        for (Future<Integer> f : futures) {
            try { total += f.get(); }
            catch (Exception e) { log.debug("Chunk failed: {}", e.getMessage()); }
        }
        pool.shutdown();
        log.info("[3/4] Parallel decompilation done: {} classes", total);
    }

    private static Path createChunkJar(Path sourceJar, List<String> entries, Path tmpDir)
            throws IOException {
        Path chunkJar = tmpDir.resolve("chunk.jar");
        try (var out = new java.util.jar.JarOutputStream(Files.newOutputStream(chunkJar));
             var src = new JarFile(sourceJar.toFile())) {
            for (String name : entries) {
                JarEntry entry = src.getJarEntry(name);
                if (entry == null) continue;
                out.putNextEntry(new JarEntry(name));
                src.getInputStream(entry).transferTo(out);
                out.closeEntry();
            }
        }
        return chunkJar;
    }

    private static void copyJavaFiles(Path src, Path dst) throws IOException {
        if (!Files.exists(src)) return;
        Files.walk(src).filter(p -> p.toString().endsWith(".java")).forEach(file -> {
            try {
                Path rel = src.relativize(file);
                Path target = dst.resolve(rel);
                Files.createDirectories(target.getParent());
                Files.copy(file, target);
            } catch (IOException ignored) {}
        });
    }

    private static void deleteRecursive(Path dir) {
        try {
            if (!Files.exists(dir)) return;
            Files.walk(dir).sorted(java.util.Comparator.reverseOrder())
                    .forEach(p -> { try { Files.delete(p); } catch (IOException ignored) {} });
        } catch (IOException ignored) {}
    }
}
