package com.mcmigrator.rules;

import com.mcmigrator.transform.TransformRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.ServiceLoader;
import java.util.stream.Stream;

/**
 * Плагин-система правил: загружает пользовательские {@link TransformRule}
 * из jar в {@code ~/.mcmigrator/plugins/} через стандартный
 * {@link ServiceLoader} (файл
 * {@code META-INF/services/com.mcmigrator.transform.TransformRule}).
 *
 * <p>Плагины применяются ко ВСЕМ парам версий — фильтрацию по версии
 * плагин делает сам внутри {@code apply()}, если нужна.</p>
 */
public final class RulePluginLoader {

    private static final Logger log = LoggerFactory.getLogger(RulePluginLoader.class);

    private RulePluginLoader() {
    }

    /**
     * Загружает все правила из плагинов.
     *
     * @param pluginsDir папка с jar-плагинами
     * @return найденные правила (пусто, если папки нет)
     */
    public static List<TransformRule> load(Path pluginsDir) {
        if (!Files.isDirectory(pluginsDir)) {
            return List.of();
        }
        List<URL> urls = new ArrayList<>();
        try (Stream<Path> walk = Files.list(pluginsDir)) {
            walk.filter(p -> p.toString().endsWith(".jar")).sorted().forEach(p -> {
                try {
                    urls.add(p.toUri().toURL());
                } catch (IOException e) {
                    log.warn("Плагин пропущен (некорректный путь): {}", p);
                }
            });
        } catch (IOException e) {
            log.warn("Папка плагинов не читается: {}", e.getMessage());
            return List.of();
        }
        if (urls.isEmpty()) {
            return List.of();
        }

        List<TransformRule> rules = new ArrayList<>();
        // ClassLoader намеренно не закрывается: классы правил живут весь прогон.
        URLClassLoader loader = new URLClassLoader(
                urls.toArray(new URL[0]), RulePluginLoader.class.getClassLoader());
        try {
            for (TransformRule rule : ServiceLoader.load(TransformRule.class, loader)) {
                rules.add(rule);
                log.info("  Плагин-правило загружено: {}", rule.description());
            }
        } catch (java.util.ServiceConfigurationError e) {
            log.warn("Ошибка загрузки плагин-правил: {}", e.getMessage());
        }
        if (!rules.isEmpty()) {
            log.info("  Плагинов-правил: {} (из {})", rules.size(), pluginsDir);
        }
        return rules;
    }
}
