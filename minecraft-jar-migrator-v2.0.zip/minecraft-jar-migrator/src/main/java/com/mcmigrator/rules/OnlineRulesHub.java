package com.mcmigrator.rules;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public final class OnlineRulesHub {

    private static final Logger log = LoggerFactory.getLogger(OnlineRulesHub.class);
    private static final String GITHUB_API = "https://api.github.com";
    private static final String DEFAULT_REPO = "minecraft-jar-migrator/rules";
    private static final long CACHE_TTL_HOURS = 24;

    private final Path cacheDir;
    private final HttpClient http;

    public OnlineRulesHub(Path cacheDir) {
        this.cacheDir = cacheDir;
        this.http = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(15))
                .build();
    }

    public record RemoteRule(String version, String downloadUrl, String sha, long size) {}

    public record UpdateResult(
            List<RemoteRule> available,
            List<String> downloaded,
            List<String> errors) {}

    public UpdateResult checkAndUpdate(String repo) {
        if (repo == null) repo = DEFAULT_REPO;
        List<RemoteRule> available = new ArrayList<>();
        List<String> downloaded = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        try {
            Files.createDirectories(cacheDir);
            available = listRemoteRules(repo);
            for (RemoteRule rule : available) {
                if (shouldDownload(rule)) {
                    try {
                        downloadRule(rule);
                        downloaded.add(rule.version());
                    } catch (Exception e) {
                        errors.add(rule.version() + ": " + e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            errors.add("Failed to check remote rules: " + e.getMessage());
        }

        return new UpdateResult(available, downloaded, errors);
    }

    public List<String> listCachedRules() {
        List<String> result = new ArrayList<>();
        if (!Files.isDirectory(cacheDir)) return result;
        try (var stream = Files.list(cacheDir)) {
            stream.filter(p -> p.toString().endsWith(".json"))
                    .forEach(p -> result.add(p.getFileName().toString()
                            .replace(".json", "")));
        } catch (IOException e) {
            log.debug("Failed to list cached rules: {}", e.getMessage());
        }
        return result;
    }

    public Path getCachedRule(String version) {
        Path file = cacheDir.resolve(version + ".json");
        return Files.isRegularFile(file) ? file : null;
    }

    public boolean hasUpdate(String version) {
        Path cached = getCachedRule(version);
        if (cached == null) return true;
        try {
            Instant modified = Files.getLastModifiedTime(cached).toInstant();
            return Duration.between(modified, Instant.now()).toHours() >= CACHE_TTL_HOURS;
        } catch (IOException e) {
            return true;
        }
    }

    private List<RemoteRule> listRemoteRules(String repo) throws IOException, InterruptedException {
        String url = GITHUB_API + "/repos/" + repo + "/contents/rules";
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "MinecraftJarMigrator")
                .header("Accept", "application/vnd.github.v3+json")
                .GET().build();

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IOException("GitHub API returned " + response.statusCode());
        }

        List<RemoteRule> rules = new ArrayList<>();
        var array = JsonParser.parseString(response.body()).getAsJsonArray();
        for (var element : array) {
            JsonObject obj = element.getAsJsonObject();
            String name = obj.get("name").getAsString();
            if (!name.endsWith(".json")) continue;
            String version = name.replace(".json", "");
            rules.add(new RemoteRule(
                    version,
                    obj.has("download_url") ? obj.get("download_url").getAsString() : "",
                    obj.has("sha") ? obj.get("sha").getAsString() : "",
                    obj.has("size") ? obj.get("size").getAsLong() : 0));
        }
        return rules;
    }

    private boolean shouldDownload(RemoteRule rule) {
        Path cached = getCachedRule(rule.version());
        if (cached == null) return true;
        if (!rule.sha().isEmpty()) {
            try {
                String content = Files.readString(cached, StandardCharsets.UTF_8);
                String localSha = sha1(content);
                return !localSha.equals(rule.sha());
            } catch (IOException e) {
                return true;
            }
        }
        return hasUpdate(rule.version());
    }

    private void downloadRule(RemoteRule rule) throws IOException, InterruptedException {
        if (rule.downloadUrl().isEmpty()) return;
        HttpRequest request = HttpRequest.newBuilder(URI.create(rule.downloadUrl()))
                .header("User-Agent", "MinecraftJarMigrator")
                .GET().build();
        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IOException("Download failed: HTTP " + response.statusCode());
        }
        Path target = cacheDir.resolve(rule.version() + ".json");
        Files.writeString(target, response.body(), StandardCharsets.UTF_8);
        log.info("Downloaded online rule: {}", rule.version());
    }

    private static String sha1(String input) {
        try {
            var md = java.security.MessageDigest.getInstance("SHA-1");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
