package com.mcmigrator.rules;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.mcmigrator.Constants;
import com.mcmigrator.exception.TransformException;
import com.mcmigrator.transform.ApiBreakingChangeRule;
import com.mcmigrator.transform.ClassRenameRule;
import com.mcmigrator.transform.MethodRenameRule;
import com.mcmigrator.transform.PackageChangeRule;
import com.mcmigrator.transform.TransformRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Набор правил трансформации для пары версий, загружаемый из ресурса
 * {@code /rules/{from}-to-{to}.json}.
 *
 * @param version            идентификатор пары версий, например {@code "1.20.3-to-1.21.1"}
 * @param methodRenames      переименованные методы
 * @param classRenames       переименованные классы
 * @param packageMoves       перенесённые пакеты
 * @param apiBreakingChanges сломанные API (только детект для отчёта)
 */
public record VersionRuleSet(
        String version,
        List<MethodRename> methodRenames,
        List<ClassRename> classRenames,
        List<PackageMove> packageMoves,
        List<ApiBreakingChange> apiBreakingChanges) {

    private static final Logger log = LoggerFactory.getLogger(VersionRuleSet.class);
    private static final Gson GSON = new Gson();

    /**
     * Переименование метода.
     *
     * @param className FQN класса, где объявлен метод
     * @param oldMethod старое имя
     * @param newMethod новое имя
     * @param comment   пояснение (опционально)
     */
    public record MethodRename(String className, String oldMethod, String newMethod, String comment) {
    }

    /**
     * Переименование класса.
     *
     * @param oldName старое полное имя
     * @param newName новое полное имя
     */
    public record ClassRename(String oldName, String newName) {
    }

    /**
     * Перенос пакета.
     *
     * @param oldPackage старый пакет
     * @param newPackage новый пакет
     */
    public record PackageMove(String oldPackage, String newPackage) {
    }

    /**
     * Сломанное API (только репорт, без автоправки).
     *
     * @param description  описание изменения
     * @param matchPattern регулярное выражение для поиска
     * @param suggestedFix рекомендация по исправлению
     */
    public record ApiBreakingChange(String description, String matchPattern, String suggestedFix) {
    }

    /**
     * Загружает набор правил для пары версий из ресурсов приложения.
     *
     * @param from исходная версия
     * @param to   целевая версия
     * @return набор правил; пустой, если файла правил для пары нет
     * @throws TransformException если файл правил есть, но не читается/невалиден
     */
    public static VersionRuleSet load(String from, String to) throws TransformException {
        // 1) Локальное/сетевое переопределение из ~/.mcmigrator/rules имеет приоритет.
        java.nio.file.Path override = new RuleUpdater(
                java.nio.file.Path.of(System.getProperty("user.home"), ".mcmigrator", "rules"))
                .localOrFetched(from, to);
        if (override != null) {
            try (Reader reader = java.nio.file.Files.newBufferedReader(
                    override, StandardCharsets.UTF_8)) {
                VersionRuleSet parsed = GSON.fromJson(reader, VersionRuleSet.class);
                log.info("  Правила {}-to-{} взяты из переопределения: {}", from, to, override);
                return parsed == null ? empty(from + "-to-" + to) : parsed.normalized();
            } catch (IOException | JsonParseException e) {
                log.warn("  Переопределение правил не читается ({}), беру встроенные",
                        e.getMessage());
            }
        }
        // 2) Встроенный ресурс.
        String resource = Constants.RULES_RESOURCE_PATTERN.formatted(from, to);
        InputStream in = VersionRuleSet.class.getResourceAsStream(resource);
        if (in == null) {
            log.debug("Файл правил {} не найден — правила не применяются", resource);
            return empty(from + "-to-" + to);
        }
        try (Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            VersionRuleSet parsed = GSON.fromJson(reader, VersionRuleSet.class);
            if (parsed == null) {
                return empty(from + "-to-" + to);
            }
            return parsed.normalized();
        } catch (IOException | JsonParseException e) {
            throw new TransformException("Невалидный файл правил " + resource + ": " + e.getMessage(), e);
        }
    }

    private static VersionRuleSet empty(String version) {
        return new VersionRuleSet(version, List.of(), List.of(), List.of(), List.of());
    }

    /** @return копия набора, где все {@code null}-списки заменены пустыми */
    public VersionRuleSet normalized() {
        return new VersionRuleSet(
                version,
                methodRenames == null ? List.of() : methodRenames,
                classRenames == null ? List.of() : classRenames,
                packageMoves == null ? List.of() : packageMoves,
                apiBreakingChanges == null ? List.of() : apiBreakingChanges);
    }

    /** @return {@code true}, если набор не содержит ни одного правила */
    public boolean isEmpty() {
        return methodRenames().isEmpty() && classRenames().isEmpty()
                && packageMoves().isEmpty() && apiBreakingChanges().isEmpty();
    }

    /**
     * Собирает исполняемые экземпляры правил из описаний.
     *
     * @return список правил в порядке: методы, классы, пакеты, breaking changes
     */
    public List<TransformRule> toRules() {
        List<TransformRule> rules = new ArrayList<>();
        for (MethodRename r : methodRenames()) {
            rules.add(new MethodRenameRule(r.className(), r.oldMethod(), r.newMethod(), r.comment()));
        }
        for (ClassRename r : classRenames()) {
            rules.add(new ClassRenameRule(r.oldName(), r.newName()));
        }
        for (PackageMove r : packageMoves()) {
            rules.add(new PackageChangeRule(r.oldPackage(), r.newPackage()));
        }
        for (ApiBreakingChange r : apiBreakingChanges()) {
            rules.add(new ApiBreakingChangeRule(r.description(), r.matchPattern(), r.suggestedFix()));
        }
        return rules;
    }
}
