package com.mcmigrator.rules;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Обновление правил без релиза программы: при наличии переопределения
 * в {@code ~/.mcmigrator/rules/} оно имеет приоритет над встроенными
 * ресурсами; метод {@link #fetch} умеет скачивать правило пары с
 * настраиваемого URL (например, raw.githubusercontent.com).
 *
 * <p>URL-шаблон задаётся файлом {@code ~/.mcmigrator/rules-source.txt}
 * (одна строка, плейсхолдеры {@code {from}} и {@code {to}}); если файла
 * нет — сетевые обновления выключены, работают только локальные
 * переопределения.</p>
 */
public final class RuleUpdater {

    private static final Logger log = LoggerFactory.getLogger(RuleUpdater.class);
    private static final Duration MAX_AGE = Duration.of(7, ChronoUnit.DAYS);

    private final Path rulesDir;
    private final HttpClient http = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    /** @param rulesDir папка локальных правил, обычно {@code ~/.mcmigrator/rules} */
    public RuleUpdater(Path rulesDir) {
        this.rulesDir = rulesDir;
    }

    /**
     * Возвращает локально переопределённый файл правил пары, при возможности
     * освежив его из настроенного источника. Сетевые ошибки не фатальны.
     *
     * @param from исходная версия
     * @param to   целевая версия
     * @return путь к локальному файлу правил или {@code null}, если переопределения нет
     */
    public Path localOrFetched(String from, String to) {
        Path local = rulesDir.resolve(from + "-to-" + to + ".json");
        String template = readSourceTemplate();
        if (template != null && isStale(local)) {
            fetch(template, from, to, local);
        }
        return Files.isRegularFile(local) ? local : null;
    }

    private boolean isStale(Path file) {
        try {
            return !Files.isRegularFile(file)
                    || Files.getLastModifiedTime(file).toInstant()
                            .isBefore(Instant.now().minus(MAX_AGE));
        } catch (IOException e) {
            return true;
        }
    }

    private String readSourceTemplate() {
        Path source = rulesDir.resolveSibling("rules-source.txt");
        if (!Files.isRegularFile(source)) {
            return null;
        }
        try {
            String template = Files.readString(source).trim();
            return template.isEmpty() ? null : template;
        } catch (IOException e) {
            return null;
        }
    }

    private void fetch(String template, String from, String to, Path target) {
        String url = template.replace("{from}", from).replace("{to}", to);
        try {
            Files.createDirectories(rulesDir);
            HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(15)).GET().build();
            HttpResponse<Path> response =
                    http.send(request, HttpResponse.BodyHandlers.ofFile(target));
            if (response.statusCode() == 200) {
                log.info("  Правила {}-to-{} обновлены из сети", from, to);
            } else {
                Files.deleteIfExists(target);
                log.debug("Правила {}-to-{}: HTTP {} от {}", from, to,
                        response.statusCode(), url);
            }
        } catch (IOException e) {
            log.debug("Сетевое обновление правил недоступно: {}", e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
