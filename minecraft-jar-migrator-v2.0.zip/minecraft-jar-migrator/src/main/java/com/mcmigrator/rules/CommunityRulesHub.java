package com.mcmigrator.rules;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

public final class CommunityRulesHub {

    private static final Logger log = LoggerFactory.getLogger(CommunityRulesHub.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path ratingsFile;
    private final HttpClient http;

    public CommunityRulesHub(Path baseDir) {
        this.ratingsFile = baseDir.resolve("rule-ratings.json");
        this.http = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    public record Rating(String ruleVersion, int helpful, int harmful, double score) {}

    public void rate(String ruleVersion, boolean helpful) {
        Map<String, int[]> ratings = loadRatings();
        int[] counts = ratings.computeIfAbsent(ruleVersion, k -> new int[]{0, 0});
        if (helpful) counts[0]++; else counts[1]++;
        saveRatings(ratings);
    }

    public Rating getRating(String ruleVersion) {
        Map<String, int[]> ratings = loadRatings();
        int[] counts = ratings.getOrDefault(ruleVersion, new int[]{0, 0});
        int total = counts[0] + counts[1];
        double score = total > 0 ? (double) counts[0] / total : 0.5;
        return new Rating(ruleVersion, counts[0], counts[1], score);
    }

    public Map<String, Rating> getAllRatings() {
        Map<String, int[]> raw = loadRatings();
        Map<String, Rating> result = new LinkedHashMap<>();
        for (var entry : raw.entrySet()) {
            int[] c = entry.getValue();
            int total = c[0] + c[1];
            double score = total > 0 ? (double) c[0] / total : 0.5;
            result.put(entry.getKey(), new Rating(entry.getKey(), c[0], c[1], score));
        }
        return result;
    }

    public boolean submitRating(String ruleVersion, boolean helpful) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("rule", ruleVersion);
            body.addProperty("helpful", helpful);
            HttpRequest request = HttpRequest.newBuilder(
                            URI.create("https://api.github.com/repos/minecraft-jar-migrator/rules/ratings"))
                    .header("User-Agent", "MinecraftJarMigrator")
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            GSON.toJson(body), StandardCharsets.UTF_8))
                    .build();
            HttpResponse<String> resp = http.send(request, HttpResponse.BodyHandlers.ofString());
            return resp.statusCode() == 200 || resp.statusCode() == 201;
        } catch (Exception e) {
            log.debug("Rating submission failed: {}", e.getMessage());
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, int[]> loadRatings() {
        if (!Files.isRegularFile(ratingsFile)) return new LinkedHashMap<>();
        try {
            String json = Files.readString(ratingsFile, StandardCharsets.UTF_8);
            Map<String, int[]> map = GSON.fromJson(json, LinkedHashMap.class);
            return map != null ? map : new LinkedHashMap<>();
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    private void saveRatings(Map<String, int[]> ratings) {
        try {
            Files.createDirectories(ratingsFile.getParent());
            Files.writeString(ratingsFile, GSON.toJson(ratings), StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.debug("Failed to save ratings: {}", e.getMessage());
        }
    }
}
