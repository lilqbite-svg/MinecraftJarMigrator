package com.mcmigrator.rules;

import com.mcmigrator.transform.TransformRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public final class InteractiveRuleSelector {

    private static final Logger log = LoggerFactory.getLogger(InteractiveRuleSelector.class);

    private InteractiveRuleSelector() {
    }

    public static List<String> selectDisabledRules(List<TransformRule> rules) {
        if (rules.isEmpty()) {
            return List.of();
        }

        System.out.println("\n=== Interactive Rule Selection ===");
        System.out.println("The following rules will be applied during transformation:");
        System.out.println();

        for (int i = 0; i < rules.size(); i++) {
            TransformRule rule = rules.get(i);
            String type = ruleTypeName(rule);
            System.out.printf("  [%3d] (%s) %s%n", i + 1, type, rule.description());
        }

        System.out.println();
        System.out.println("Enter rule numbers to DISABLE (comma-separated), or press Enter to keep all enabled:");
        System.out.print("> ");

        List<String> disabled = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String line = reader.readLine();
            if (line != null && !line.isBlank()) {
                for (String token : line.split("[,\\s]+")) {
                    try {
                        int index = Integer.parseInt(token.trim()) - 1;
                        if (index >= 0 && index < rules.size()) {
                            disabled.add(rules.get(index).description());
                            System.out.println("  Disabled: " + rules.get(index).description());
                        } else {
                            System.out.println("  Ignoring out-of-range: " + token);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("  Ignoring invalid input: " + token);
                    }
                }
            }
        } catch (IOException e) {
            log.warn("Failed to read interactive input: {}", e.getMessage());
        }

        if (!disabled.isEmpty()) {
            System.out.println("\n" + disabled.size() + " rule(s) disabled.");
        } else {
            System.out.println("\nAll rules enabled.");
        }
        System.out.println();

        return disabled;
    }

    public static List<String> selectBreakingChanges(
            List<com.mcmigrator.transform.ApiBreakingChangeRule> rules) {
        if (rules.isEmpty()) {
            return List.of();
        }

        System.out.println("\n=== Breaking Changes Preview ===");
        System.out.println("The following breaking changes were detected:");
        System.out.println();

        for (int i = 0; i < rules.size(); i++) {
            var rule = rules.get(i);
            System.out.printf("  [%3d] %s%n", i + 1, rule.description());
            if (rule.suggestedFix() != null && !rule.suggestedFix().isEmpty()) {
                System.out.printf("        Suggested fix: %s%n", rule.suggestedFix());
            }
        }

        System.out.println();
        System.out.println("Enter rule numbers to DISABLE checking (comma-separated), or Enter to check all:");
        System.out.print("> ");

        List<String> disabled = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String line = reader.readLine();
            if (line != null && !line.isBlank()) {
                for (String token : line.split("[,\\s]+")) {
                    try {
                        int index = Integer.parseInt(token.trim()) - 1;
                        if (index >= 0 && index < rules.size()) {
                            disabled.add(rules.get(index).description());
                            System.out.println("  Disabled: " + rules.get(index).description());
                        }
                    } catch (NumberFormatException e) {
                        // skip
                    }
                }
            }
        } catch (IOException e) {
            log.warn("Failed to read input: {}", e.getMessage());
        }

        return disabled;
    }

    private static String ruleTypeName(TransformRule rule) {
        String name = rule.getClass().getSimpleName();
        if (name.contains("Method")) return "method";
        if (name.contains("Class")) return "class";
        if (name.contains("Package")) return "package";
        if (name.contains("ApiBreaking")) return "breaking";
        return "transform";
    }
}
