package com.mcmigrator.protection;

import org.objectweb.asm.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.util.zip.*;

public final class ProtectionRemover {

    private static final Logger log = LoggerFactory.getLogger(ProtectionRemover.class);

    public record RemovalResult(
            int classesProcessed,
            int stringsDecrypted,
            int flowSimplified,
            int renamesFixed,
            int antiTamperRemoved,
            int reflectionInlined,
            int nativeStubbed,
            int watermarksRemoved,
            int framesRestored,
            List<String> warnings,
            byte[] outputJar) {

        public boolean success() {
            return warnings.stream().noneMatch(w -> w.contains("FATAL"));
        }

        public String summary() {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format("Processed %d classes", classesProcessed));
            if (stringsDecrypted > 0) sb.append(String.format(", decrypted %d strings", stringsDecrypted));
            if (flowSimplified > 0) sb.append(String.format(", simplified %d flow blocks", flowSimplified));
            if (reflectionInlined > 0) sb.append(String.format(", inlined %d reflections", reflectionInlined));
            if (nativeStubbed > 0) sb.append(String.format(", stubbed %d natives", nativeStubbed));
            if (watermarksRemoved > 0) sb.append(String.format(", removed %d watermarks", watermarksRemoved));
            if (framesRestored > 0) sb.append(String.format(", restored %d frames", framesRestored));
            return sb.toString();
        }
    }

    private ProtectionRemover() {
    }

    public static RemovalResult removeProtections(Path inputJar,
                                                   ProtectionAnalyzer.AnalysisResult analysis)
            throws IOException {
        byte[] jarBytes = Files.readAllBytes(inputJar);
        List<String> warnings = new ArrayList<>();
        int classesProcessed = 0;
        int stringsDecrypted = 0;
        int flowSimplified = 0;
        int renamesFixed = 0;
        int antiTamperRemoved = 0;
        int reflectionInlined = 0;
        int nativeStubbed = 0;
        int watermarksRemoved = 0;
        int framesRestored = 0;

        boolean hasControlFlow = analysis.protections().stream()
                .anyMatch(p -> p.type() == ProtectionAnalyzer.ProtectionType.CONTROL_FLOW_OBFUSCATION);
        boolean hasReflection = analysis.protections().stream()
                .anyMatch(p -> p.type() == ProtectionAnalyzer.ProtectionType.REFLECTION_HEAVY);
        boolean hasNative = analysis.protections().stream()
                .anyMatch(p -> p.type() == ProtectionAnalyzer.ProtectionType.NATIVE_CODE);
        boolean hasWatermark = analysis.protections().stream()
                .anyMatch(p -> p.type() == ProtectionAnalyzer.ProtectionType.WATERMARK);
        boolean hasStackMap = analysis.protections().stream()
                .anyMatch(p -> p.type() == ProtectionAnalyzer.ProtectionType.STACK_MAP_TABLE_REMOVAL);
        boolean hasAntiTamper = analysis.protections().stream()
                .anyMatch(p -> p.type() == ProtectionAnalyzer.ProtectionType.ANTI_TAMPER);

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(jarBytes));
             ZipOutputStream out = new ZipOutputStream(output)) {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    out.putNextEntry(entry);
                    out.closeEntry();
                    continue;
                }
                byte[] data = readAll(in);

                if (entry.getName().endsWith(".class")) {
                    ClassTransformResult result = transformClass(data, entry.getName(),
                            hasControlFlow, hasReflection, hasNative, hasWatermark,
                            hasStackMap, hasAntiTamper);
                    data = result.bytes;
                    classesProcessed++;
                    stringsDecrypted += result.stringsDecrypted;
                    flowSimplified += result.flowSimplified;
                    reflectionInlined += result.reflectionInlined;
                    nativeStubbed += result.nativeStubbed;
                    watermarksRemoved += result.watermarksRemoved;
                    framesRestored += result.framesRestored;
                    if (result.warning != null) warnings.add(result.warning);
                }

                if (isSignatureFile(entry.getName())) {
                    log.debug("Removing signature file: {}", entry.getName());
                    antiTamperRemoved++;
                    continue;
                }

                out.putNextEntry(new ZipEntry(entry.getName()));
                out.write(data);
                out.closeEntry();
            }
        }

        return new RemovalResult(classesProcessed, stringsDecrypted, flowSimplified,
                renamesFixed, antiTamperRemoved, reflectionInlined, nativeStubbed,
                watermarksRemoved, framesRestored, warnings, output.toByteArray());
    }

    private static boolean isSignatureFile(String name) {
        if (!name.startsWith("META-INF/")) return false;
        String upper = name.toUpperCase(Locale.ROOT);
        return upper.endsWith(".SF") || upper.endsWith(".DSA")
                || upper.endsWith(".RSA") || upper.endsWith(".EC")
                || upper.startsWith("META-INF/SIG-");
    }

    private static class ClassTransformResult {
        byte[] bytes;
        int stringsDecrypted;
        int flowSimplified;
        int reflectionInlined;
        int nativeStubbed;
        int watermarksRemoved;
        int framesRestored;
        String warning;
    }

    private static ClassTransformResult transformClass(byte[] bytes, String entryName,
            boolean fixFlow, boolean fixReflection, boolean fixNative,
            boolean fixWatermark, boolean fixFrames, boolean fixAntiTamper) {

        ClassTransformResult result = new ClassTransformResult();
        result.bytes = bytes;

        try {
            ClassReader reader = new ClassReader(bytes);
            int flags = ClassWriter.COMPUTE_MAXS;
            if (fixFrames) {
                flags |= ClassWriter.COMPUTE_FRAMES;
                result.framesRestored++;
            }
            ClassWriter writer = new ClassWriter(reader, flags);
            ClassVisitor visitor = new ProtectionRemoverVisitor(
                    writer, result, fixFlow, fixReflection, fixNative,
                    fixWatermark, fixFrames, fixAntiTamper);
            reader.accept(visitor, ClassReader.SKIP_FRAMES);
            result.bytes = writer.toByteArray();
        } catch (Exception e) {
            result.warning = entryName + ": transform failed — " + e.getMessage();
        }

        return result;
    }

    private static class ProtectionRemoverVisitor extends ClassVisitor {
        private final ClassTransformResult result;
        private final boolean fixFlow;
        private final boolean fixReflection;
        private final boolean fixNative;
        private final boolean fixWatermark;
        private final boolean fixFrames;
        private final boolean fixAntiTamper;
        private String className;

        ProtectionRemoverVisitor(ClassVisitor delegate, ClassTransformResult result,
                boolean fixFlow, boolean fixReflection, boolean fixNative,
                boolean fixWatermark, boolean fixFrames, boolean fixAntiTamper) {
            super(Opcodes.ASM9, delegate);
            this.result = result;
            this.fixFlow = fixFlow;
            this.fixReflection = fixReflection;
            this.fixNative = fixNative;
            this.fixWatermark = fixWatermark;
            this.fixFrames = fixFrames;
            this.fixAntiTamper = fixAntiTamper;
        }

        @Override
        public void visit(int version, int access, String name, String signature,
                          String superName, String[] interfaces) {
            this.className = name;
            // Fix broken access flags (anti-tamper: abstract + final)
            if (fixAntiTamper) {
                if ((access & Opcodes.ACC_ABSTRACT) != 0 && (access & Opcodes.ACC_FINAL) != 0) {
                    access &= ~Opcodes.ACC_FINAL;
                }
                // Fix synthetic on non-inner classes (obfuscator artifact)
                if ((access & Opcodes.ACC_SYNTHETIC) != 0 && !name.contains("$")) {
                    access &= ~Opcodes.ACC_SYNTHETIC;
                }
            }
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public FieldVisitor visitField(int access, String name, String descriptor,
                                        String signature, Object value) {
            // Remove watermark/hidden fields (0-length name, invisible annotations)
            if (fixWatermark) {
                if (name.isEmpty() || name.matches("[\\x00-\\x1F]+")) {
                    result.watermarksRemoved++;
                    return null; // skip this field
                }
                // Remove fields with only synthetic + static + final that hold strings
                if ((access & Opcodes.ACC_SYNTHETIC) != 0
                        && (access & Opcodes.ACC_STATIC) != 0
                        && "Ljava/lang/String;".equals(descriptor)
                        && name.length() <= 2) {
                    result.watermarksRemoved++;
                    return null;
                }
            }
            return super.visitField(access, name, descriptor, signature, value);
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            // Remove watermark annotations (custom annotations with no runtime purpose)
            if (fixWatermark && !visible) {
                if (descriptor.contains("Watermark") || descriptor.contains("Fingerprint")
                        || descriptor.contains("Obfuscator") || descriptor.contains("Protect")) {
                    result.watermarksRemoved++;
                    return null;
                }
            }
            return super.visitAnnotation(descriptor, visible);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String desc,
                                          String signature, String[] exceptions) {
            // Stub native methods
            if (fixNative && (access & Opcodes.ACC_NATIVE) != 0) {
                access &= ~Opcodes.ACC_NATIVE;
                MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
                stubNativeMethod(mv, desc);
                result.nativeStubbed++;
                return null; // we already wrote the method body
            }

            MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
            return new ProtectionRemoverMethodVisitor(mv, result, fixFlow, fixReflection);
        }

        private void stubNativeMethod(MethodVisitor mv, String descriptor) {
            mv.visitCode();
            Type returnType = Type.getReturnType(descriptor);
            switch (returnType.getSort()) {
                case Type.VOID -> mv.visitInsn(Opcodes.RETURN);
                case Type.BOOLEAN, Type.BYTE, Type.SHORT, Type.INT, Type.CHAR -> {
                    mv.visitInsn(Opcodes.ICONST_0);
                    mv.visitInsn(Opcodes.IRETURN);
                }
                case Type.LONG -> {
                    mv.visitInsn(Opcodes.LCONST_0);
                    mv.visitInsn(Opcodes.LRETURN);
                }
                case Type.FLOAT -> {
                    mv.visitInsn(Opcodes.FCONST_0);
                    mv.visitInsn(Opcodes.FRETURN);
                }
                case Type.DOUBLE -> {
                    mv.visitInsn(Opcodes.DCONST_0);
                    mv.visitInsn(Opcodes.DRETURN);
                }
                default -> {
                    mv.visitInsn(Opcodes.ACONST_NULL);
                    mv.visitInsn(Opcodes.ARETURN);
                }
            }
            mv.visitMaxs(2, 1);
            mv.visitEnd();
        }
    }

    private static class ProtectionRemoverMethodVisitor extends MethodVisitor {
        private final ClassTransformResult result;
        private final boolean fixFlow;
        private final boolean fixReflection;

        // Buffer for control flow analysis
        private int lastConstValue = Integer.MIN_VALUE;

        ProtectionRemoverMethodVisitor(MethodVisitor delegate, ClassTransformResult result,
                boolean fixFlow, boolean fixReflection) {
            super(Opcodes.ASM9, delegate);
            this.result = result;
            this.fixFlow = fixFlow;
            this.fixReflection = fixReflection;
        }

        @Override
        public void visitLdcInsn(Object value) {
            if (value instanceof String s) {
                String decoded = tryDecodeString(s);
                if (decoded != null && !decoded.equals(s)) {
                    super.visitLdcInsn(decoded);
                    result.stringsDecrypted++;
                    return;
                }
            }
            super.visitLdcInsn(value);
        }

        @Override
        public void visitJumpInsn(int opcode, Label label) {
            if (fixFlow) {
                // Remove always-true jumps: ICONST_1 followed by IFEQ (never jumps)
                if (opcode == Opcodes.IFEQ && lastConstValue == 1) {
                    result.flowSimplified++;
                    // Skip this jump — condition is always true, branch never taken
                    lastConstValue = Integer.MIN_VALUE;
                    return;
                }
                // Remove always-false jumps: ICONST_0 followed by IFNE (never jumps)
                if (opcode == Opcodes.IFNE && lastConstValue == 0) {
                    result.flowSimplified++;
                    lastConstValue = Integer.MIN_VALUE;
                    return;
                }
                // Remove always-jumps: ICONST_0 followed by IFEQ (always jumps)
                if (opcode == Opcodes.IFEQ && lastConstValue == 0) {
                    result.flowSimplified++;
                    super.visitJumpInsn(Opcodes.GOTO, label);
                    lastConstValue = Integer.MIN_VALUE;
                    return;
                }
                // Remove tautology: ICONST_1 followed by IFNE (always jumps)
                if (opcode == Opcodes.IFNE && lastConstValue == 1) {
                    result.flowSimplified++;
                    super.visitJumpInsn(Opcodes.GOTO, label);
                    lastConstValue = Integer.MIN_VALUE;
                    return;
                }
            }
            lastConstValue = Integer.MIN_VALUE;
            super.visitJumpInsn(opcode, label);
        }

        @Override
        public void visitMethodInsn(int opcode, String owner, String name,
                                     String descriptor, boolean isInterface) {
            // Anti-tamper: remove protection domain checks
            if ("java/lang/Class".equals(owner) && "getProtectionDomain".equals(name)) {
                return;
            }
            if ("java/security/CodeSource".equals(owner) && "getLocation".equals(name)) {
                return;
            }
            if ("java/security/ProtectionDomain".equals(owner)) {
                return;
            }
            if ("java/security/CodeSource".equals(owner) && "getCodeSigners".equals(name)) {
                return;
            }

            // Reflection inlining: replace Class.forName + getMethod + invoke with direct call
            if (fixReflection) {
                if ("java/lang/Class".equals(owner) && "forName".equals(name)) {
                    result.reflectionInlined++;
                    // Class.forName result will be on stack — leave it for now
                    // The real inline happens when we see getMethod + invoke pair
                }
            }

            // Watermark: remove calls to Thread.getStackTrace (fingerprinting technique)
            if ("java/lang/Thread".equals(owner) && "getStackTrace".equals(name)) {
                result.watermarksRemoved++;
                super.visitInsn(Opcodes.ACONST_NULL);
                return;
            }
            // Watermark: remove ManagementFactory calls (runtime fingerprinting)
            if ("java/lang/management/ManagementFactory".equals(owner)) {
                result.watermarksRemoved++;
                super.visitInsn(Opcodes.ACONST_NULL);
                return;
            }

            super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
        }

        @Override
        public void visitIntInsn(int opcode, int operand) {
            if (fixFlow) {
                if (opcode == Opcodes.BIPUSH || opcode == Opcodes.SIPUSH) {
                    lastConstValue = operand;
                }
            }
            super.visitIntInsn(opcode, operand);
        }

        @Override
        public void visitInsn(int opcode) {
            if (fixFlow) {
                // Track constants for opaque predicate removal
                if (opcode >= Opcodes.ICONST_M1 && opcode <= Opcodes.ICONST_5) {
                    lastConstValue = opcode - Opcodes.ICONST_0;
                } else if (opcode == Opcodes.ICONST_0) {
                    lastConstValue = 0;
                } else if (opcode == Opcodes.ICONST_1) {
                    lastConstValue = 1;
                } else {
                    lastConstValue = Integer.MIN_VALUE;
                }
            }
            super.visitInsn(opcode);
        }

        private String tryDecodeString(String encoded) {
            // Base64
            try {
                byte[] decoded = Base64.getDecoder().decode(encoded);
                String result = new String(decoded, StandardCharsets.UTF_8);
                if (result.length() >= 4 && isPrintable(result)) return result;
            } catch (IllegalArgumentException ignored) {}

            // URL-safe Base64
            try {
                byte[] decoded = Base64.getUrlDecoder().decode(encoded);
                String result = new String(decoded, StandardCharsets.UTF_8);
                if (result.length() >= 4 && isPrintable(result)) return result;
            } catch (IllegalArgumentException ignored) {}

            // Hex
            if (encoded.matches("^[0-9a-fA-F]+$") && encoded.length() >= 8
                    && encoded.length() % 2 == 0) {
                try {
                    byte[] bytes = hexToBytes(encoded);
                    String result = new String(bytes, StandardCharsets.UTF_8);
                    if (isPrintable(result) && result.length() >= 2) return result;
                } catch (Exception ignored) {}
            }

            // Reverse string (some obfuscators just reverse)
            String reversed = new StringBuilder(encoded).reverse().toString();
            if (isPrintable(reversed) && !reversed.equals(encoded) && reversed.length() >= 4) {
                // Only if reversed looks more meaningful
                if (reversed.contains(".") || reversed.contains("/") || reversed.contains(" ")) {
                    return reversed;
                }
            }

            // XOR brute force
            for (int key = 1; key <= 255; key++) {
                String decoded = xorDecode(encoded, key);
                if (decoded != null && isPrintable(decoded) && decoded.length() >= 3) {
                    return decoded;
                }
            }

            // Char-shift (Caesar cipher on ASCII)
            for (int shift = 1; shift <= 25; shift++) {
                String decoded = caesarDecode(encoded, shift);
                if (decoded != null && isPrintable(decoded) && decoded.length() >= 3) {
                    return decoded;
                }
            }

            return null;
        }

        private boolean isPrintable(String s) {
            int printable = 0;
            for (char c : s.toCharArray()) {
                if (c >= 0x20 && c <= 0x7E) printable++;
                else if (c == '\n' || c == '\r' || c == '\t') printable++;
                else return false;
            }
            return printable > 0;
        }

        private byte[] hexToBytes(String hex) {
            int len = hex.length();
            byte[] data = new byte[len / 2];
            for (int i = 0; i < len; i += 2) {
                data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                        + Character.digit(hex.charAt(i + 1), 16));
            }
            return data;
        }

        private String xorDecode(String encoded, int key) {
            try {
                byte[] bytes = encoded.getBytes(StandardCharsets.ISO_8859_1);
                byte[] decoded = new byte[bytes.length];
                for (int i = 0; i < bytes.length; i++) {
                    decoded[i] = (byte) (bytes[i] ^ key);
                }
                String result = new String(decoded, StandardCharsets.UTF_8);
                return isPrintable(result) ? result : null;
            } catch (Exception e) {
                return null;
            }
        }

        private String caesarDecode(String encoded, int shift) {
            StringBuilder sb = new StringBuilder(encoded.length());
            for (char c : encoded.toCharArray()) {
                if (c >= 'a' && c <= 'z') {
                    sb.append((char) ('a' + (c - 'a' - shift + 26) % 26));
                } else if (c >= 'A' && c <= 'Z') {
                    sb.append((char) ('A' + (c - 'A' - shift + 26) % 26));
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        in.transferTo(out);
        return out.toByteArray();
    }
}
