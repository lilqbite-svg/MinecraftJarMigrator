package com.mcmigrator;

import java.util.Locale;

public enum ModType {
    FABRIC("Fabric"),
    FORGE("Forge"),
    NEOFORGE("NeoForge"),
    PAPER("Paper"),
    SPIGOT("Spigot"),
    QUILT("Quilt");

    private final String displayName;

    ModType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static ModType fromString(String value) {
        return valueOf(value.toUpperCase(Locale.ROOT));
    }

    @Override
    public String toString() {
        return displayName;
    }
}
