package com.mcmigrator.report;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Накопитель данных для итогового отчёта {@code {output}.report.txt}:
 * применённые автоматические трансформации, места, требующие ручной правки,
 * и некритичные предупреждения.
 *
 * <p>Списки синхронизированы — этапы пайплайна могут писать из разных потоков.</p>
 */
public final class MigrationReport {

    private final String title;
    private final List<String> transformations = Collections.synchronizedList(new ArrayList<>());
    private final List<String> manualFixes = Collections.synchronizedList(new ArrayList<>());
    private final List<String> warnings = Collections.synchronizedList(new ArrayList<>());

    /** @param title заголовок отчёта, например {@code "in.jar : 1.20.3 → 1.21.1 (paper)"} */
    public MigrationReport(String title) {
        this.title = title;
    }

    /** @param entry описание выполненной автоматической трансформации */
    public void addTransformation(String entry) {
        transformations.add(entry);
    }

    /** @param entry описание места, требующего ручной правки */
    public void addManualFix(String entry) {
        manualFixes.add(entry);
    }

    /** @param entry некритичное предупреждение (например, от компилятора) */
    public void addWarning(String entry) {
        warnings.add(entry);
    }

    /** @return число записанных автоматических трансформаций */
    public int transformationCount() {
        return transformations.size();
    }

    /** @return число мест, требующих ручной правки */
    public int manualFixCount() {
        return manualFixes.size();
    }

    /** @return {@code true}, если есть хотя бы одно место для ручной правки */
    public boolean hasManualFixes() {
        return !manualFixes.isEmpty();
    }

    /**
     * Формирует полный текст отчёта.
     *
     * @return многострочный текст отчёта
     */
    public String render() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Отчёт миграции: ").append(title).append(" ===\n");
        sb.append("Сгенерировано: ")
                .append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .append("\n\n");

        appendSection(sb, "Автоматические трансформации", transformations,
                "— автоматических трансформаций не было");
        appendSection(sb, "Требует ручной правки", manualFixes,
                "— ручная правка не требуется");
        appendSection(sb, "Предупреждения", warnings,
                "— предупреждений нет");
        return sb.toString();
    }

    private void appendSection(StringBuilder sb, String name, List<String> entries, String emptyNote) {
        synchronized (entries) {
            sb.append("## ").append(name).append(" (").append(entries.size()).append(")\n");
            if (entries.isEmpty()) {
                sb.append(emptyNote).append('\n');
            } else {
                for (String entry : entries) {
                    sb.append("  * ").append(entry).append('\n');
                }
            }
            sb.append('\n');
        }
    }

    /**
     * Записывает отчёт в файл (UTF-8, с перезаписью).
     *
     * @param path путь к файлу отчёта
     * @throws IOException при ошибке записи
     */
    public void writeTo(Path path) throws IOException {
        Files.writeString(path, render(), StandardCharsets.UTF_8);
    }
}
