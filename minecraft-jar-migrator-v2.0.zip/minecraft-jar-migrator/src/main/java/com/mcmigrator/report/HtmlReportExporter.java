package com.mcmigrator.report;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Экспорт отчёта миграции в HTML (тёмно-светлая авто-тема через
 * {@code prefers-color-scheme}) и Markdown.
 */
public final class HtmlReportExporter {

    private HtmlReportExporter() {
    }

    /**
     * Пишет HTML-версию отчёта рядом с текстовой.
     *
     * @param report     отчёт
     * @param textReport путь текстового отчёта (для имени файла)
     * @return путь к html-файлу
     * @throws IOException при ошибке записи
     */
    public static Path writeHtml(MigrationReport report, Path textReport) throws IOException {
        Path html = sibling(textReport, ".html");
        String body = escape(report.render())
                .replace("\n", "<br>\n")
                .replaceAll("=== (.*?) ===", "<h1>$1</h1>")
                .replaceAll("## (.*?)<br>", "<h2>$1</h2>");
        String page = """
                <!doctype html><html lang="ru"><head><meta charset="utf-8">
                <title>Отчёт миграции</title>
                <style>
                  :root { color-scheme: light dark; }
                  body { font-family: system-ui, sans-serif; max-width: 920px;
                         margin: 2rem auto; padding: 0 1rem; line-height: 1.5; }
                  h1 { font-size: 1.3rem; border-bottom: 2px solid #888; padding-bottom: .3rem; }
                  h2 { font-size: 1.05rem; margin-top: 1.4rem; }
                  @media (prefers-color-scheme: dark) { body { background:#1d1f21; color:#e8e8e8; } }
                </style></head><body>
                """ + body + "\n</body></html>\n";
        Files.writeString(html, page, StandardCharsets.UTF_8);
        return html;
    }

    /**
     * Пишет Markdown-версию отчёта рядом с текстовой.
     *
     * @param report     отчёт
     * @param textReport путь текстового отчёта (для имени файла)
     * @return путь к md-файлу
     * @throws IOException при ошибке записи
     */
    public static Path writeMarkdown(MigrationReport report, Path textReport) throws IOException {
        Path md = sibling(textReport, ".md");
        String text = report.render()
                .replaceAll("=== (.*?) ===", "# $1");
        Files.writeString(md, text, StandardCharsets.UTF_8);
        return md;
    }

    private static Path sibling(Path textReport, String ext) {
        String name = textReport.getFileName().toString();
        if (name.endsWith(".txt")) {
            name = name.substring(0, name.length() - 4);
        }
        return textReport.resolveSibling(name + ext);
    }

    private static String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
