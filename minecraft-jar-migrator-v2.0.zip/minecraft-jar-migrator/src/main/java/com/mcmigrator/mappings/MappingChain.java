package com.mcmigrator.mappings;

import com.mcmigrator.Constants;
import com.mcmigrator.exception.MappingsException;
import net.fabricmc.mappingio.tree.MappingTree;
import net.fabricmc.mappingio.tree.MemoryMappingTree;
import net.fabricmc.tinyremapper.IMappingProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Строит цепочку маппингов {@code named_old → obf → named_new}, соединяя
 * два дерева (каждое obf → named) по общим обфусцированным именам.
 *
 * <p>Ограничение метода: обфусцированные имена меняются между версиями,
 * поэтому соединение покрывает только классы/члены, чьи obf-имена совпали.
 * Несопоставленные имена остаются как есть.</p>
 */
public final class MappingChain {

    private static final Logger log = LoggerFactory.getLogger(MappingChain.class);

    private MappingChain() {
    }

    /**
     * Провайдер деобфускации одной версии: {@code obf → named}.
     * Используется для ремапа ванильного server.jar в Mojang-имена
     * (автоматический classpath).
     *
     * @param tree дерево маппингов версии (obf → named)
     * @return провайдер для Tiny Remapper
     * @throws MappingsException если в дереве нет неймспейса {@code named}
     */
    public static IMappingProvider deobf(MemoryMappingTree tree) throws MappingsException {
        return deobf(tree, Constants.NS_NAMED);
    }

    /**
     * Провайдер деобфускации {@code obf → dstNamespace} (например,
     * {@code "intermediary"} для Fabric production-модов).
     *
     * @param tree         дерево маппингов версии
     * @param dstNamespace целевой неймспейс
     * @return провайдер для Tiny Remapper
     * @throws MappingsException если неймспейса нет в дереве
     */
    public static IMappingProvider deobf(MemoryMappingTree tree, String dstNamespace)
            throws MappingsException {
        int named = tree.getNamespaceId(dstNamespace);
        if (named == MappingTree.NULL_NAMESPACE_ID) {
            throw new MappingsException("В маппингах нет неймспейса '" + dstNamespace + "'");
        }
        return acceptor -> {
            for (MappingTree.ClassMapping cls : tree.getClasses()) {
                String obf = cls.getSrcName();
                String namedName = cls.getName(named);
                if (namedName == null) {
                    continue;
                }
                acceptor.acceptClass(obf, namedName);
                for (MappingTree.MethodMapping m : cls.getMethods()) {
                    String mNamed = m.getName(named);
                    if (mNamed != null && m.getSrcDesc() != null) {
                        acceptor.acceptMethod(
                                new IMappingProvider.Member(obf, m.getSrcName(), m.getSrcDesc()),
                                mNamed);
                    }
                }
                for (MappingTree.FieldMapping f : cls.getFields()) {
                    String fNamed = f.getName(named);
                    if (fNamed != null && f.getSrcDesc() != null) {
                        acceptor.acceptField(
                                new IMappingProvider.Member(obf, f.getSrcName(), f.getSrcDesc()),
                                fNamed);
                    }
                }
            }
        };
    }

    /**
     * Создаёт {@link IMappingProvider}, который для каждого класса, метода
     * и поля из дерева исходной версии ищет соответствие в дереве целевой
     * версии по обфусцированному имени и отдаёт пару
     * {@code namedFrom → namedTo}.
     *
     * @param fromTree дерево маппингов исходной версии (obf → named)
     * @param toTree   дерево маппингов целевой версии (obf → named)
     * @return провайдер для Tiny Remapper
     * @throws MappingsException если в каком-то из деревьев нет неймспейса {@code named}
     */
    public static IMappingProvider create(MemoryMappingTree fromTree, MemoryMappingTree toTree)
            throws MappingsException {
        int fromNamed = namespaceId(fromTree, "исходной");
        int toNamed = namespaceId(toTree, "целевой");

        return acceptor -> {
            int[] classes = {0};
            int[] methods = {0};
            int[] fields = {0};

            for (MappingTree.ClassMapping oldCls : fromTree.getClasses()) {
                String obfName = oldCls.getSrcName();
                MappingTree.ClassMapping newCls = toTree.getClass(obfName);
                if (newCls == null) {
                    continue;
                }
                String oldNamed = oldCls.getName(fromNamed);
                String newNamed = newCls.getName(toNamed);
                if (oldNamed == null || newNamed == null) {
                    continue;
                }
                acceptor.acceptClass(oldNamed, newNamed);
                classes[0]++;

                for (MappingTree.MethodMapping oldMethod : oldCls.getMethods()) {
                    MappingTree.MethodMapping newMethod =
                            newCls.getMethod(oldMethod.getSrcName(), oldMethod.getSrcDesc());
                    if (newMethod == null) {
                        continue;
                    }
                    String oldMethodNamed = oldMethod.getName(fromNamed);
                    String newMethodNamed = newMethod.getName(toNamed);
                    String desc = oldMethod.getDesc(fromNamed);
                    if (oldMethodNamed == null || newMethodNamed == null || desc == null) {
                        continue;
                    }
                    acceptor.acceptMethod(
                            new IMappingProvider.Member(oldNamed, oldMethodNamed, desc),
                            newMethodNamed);
                    methods[0]++;
                }

                for (MappingTree.FieldMapping oldField : oldCls.getFields()) {
                    MappingTree.FieldMapping newField =
                            newCls.getField(oldField.getSrcName(), oldField.getSrcDesc());
                    if (newField == null) {
                        continue;
                    }
                    String oldFieldNamed = oldField.getName(fromNamed);
                    String newFieldNamed = newField.getName(toNamed);
                    String desc = oldField.getDesc(fromNamed);
                    if (oldFieldNamed == null || newFieldNamed == null || desc == null) {
                        continue;
                    }
                    acceptor.acceptField(
                            new IMappingProvider.Member(oldNamed, oldFieldNamed, desc),
                            newFieldNamed);
                    fields[0]++;
                }
            }
            log.debug("Цепочка маппингов: {} классов, {} методов, {} полей сопоставлено",
                    classes[0], methods[0], fields[0]);
        };
    }

    private static int namespaceId(MemoryMappingTree tree, String role) throws MappingsException {
        int id = tree.getNamespaceId(Constants.NS_NAMED);
        if (id == MappingTree.NULL_NAMESPACE_ID) {
            throw new MappingsException(
                    "В маппингах " + role + " версии нет неймспейса '" + Constants.NS_NAMED + "'");
        }
        return id;
    }
}
