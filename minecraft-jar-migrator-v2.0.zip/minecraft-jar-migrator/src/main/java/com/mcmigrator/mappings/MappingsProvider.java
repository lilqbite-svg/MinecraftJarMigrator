package com.mcmigrator.mappings;

import com.mcmigrator.exception.MappingsException;
import net.fabricmc.mappingio.MappingReader;
import net.fabricmc.mappingio.tree.MemoryMappingTree;
import net.fabricmc.tinyremapper.IMappingProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Поставщик маппингов: гарантирует наличие tiny-файлов через
 * {@link MappingsDownloader}, читает их в {@link MemoryMappingTree}
 * и кэширует деревья в памяти на время работы процесса.
 */
public final class MappingsProvider {

    private static final Logger log = LoggerFactory.getLogger(MappingsProvider.class);

    private final MappingsDownloader downloader;
    private final Map<String, MemoryMappingTree> cache = new HashMap<>();

    /** @param mappingsDir директория кэша tiny-файлов */
    public MappingsProvider(Path mappingsDir) {
        this.downloader = new MappingsDownloader(mappingsDir);
    }

    /**
     * Возвращает дерево маппингов (obf → named) для версии,
     * при необходимости скачивая и конвертируя его.
     *
     * @param version версия Minecraft
     * @return дерево маппингов в памяти
     * @throws MappingsException при ошибке скачивания или чтения
     */
    public MemoryMappingTree tree(String version) throws MappingsException {
        MemoryMappingTree cached = cache.get(version);
        if (cached != null) {
            return cached;
        }
        Path tiny = downloader.ensureTinyMappings(version);
        MemoryMappingTree tree = new MemoryMappingTree();
        try {
            MappingReader.read(tiny, tree);
        } catch (IOException e) {
            throw new MappingsException("Не удалось прочитать tiny-маппинги: " + tiny, e);
        }
        log.debug("Маппинги {} загружены: {} классов", version, tree.getClasses().size());
        cache.put(version, tree);
        return tree;
    }

    /**
     * Строит цепочку маппингов {@code named_from → obf → named_to}
     * в виде провайдера для Tiny Remapper.
     *
     * @param fromVersion исходная версия
     * @param toVersion   целевая версия
     * @return провайдер маппингов для ремаппера
     * @throws MappingsException при ошибке получения маппингов любой из версий
     */
    public IMappingProvider chainedProvider(String fromVersion, String toVersion) throws MappingsException {
        return MappingChain.create(tree(fromVersion), tree(toVersion));
    }
}
