package com.mcmigrator.mappings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mcmigrator.Constants;
import com.mcmigrator.exception.MappingsException;
import net.fabricmc.mappingio.adapter.MappingSourceNsSwitch;
import net.fabricmc.mappingio.format.proguard.ProGuardFileReader;
import net.fabricmc.mappingio.format.tiny.Tiny2FileWriter;
import net.fabricmc.mappingio.tree.MemoryMappingTree;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;

/**
 * Скачивает официальные MojMap-маппинги для заданной версии Minecraft
 * и конвертирует их из ProGuard-формата в tiny v2 в кэш-директорию.
 *
 * <p>Цепочка: version_manifest_v2.json → version.json →
 * downloads.server_mappings (ProGuard .txt) → {@code {version}-mojmap.tiny}.</p>
 */
public final class MappingsDownloader {

    private static final Logger log = LoggerFactory.getLogger(MappingsDownloader.class);
    private static final int MAX_RETRIES = 3;

    private final Path cacheDir;
    private final HttpClient http = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(30))
            .build();

    /** @param cacheDir директория кэша маппингов */
    public MappingsDownloader(Path cacheDir) {
        this.cacheDir = cacheDir;
    }

    /**
     * Гарантирует наличие tiny-маппингов для версии в кэше: при отсутствии
     * скачивает ProGuard-файл с серверов Mojang и конвертирует его.
     *
     * @param version версия Minecraft, например {@code "1.21.1"}
     * @return путь к tiny-файлу маппингов
     * @throws MappingsException если скачать или сконвертировать не удалось
     */
    public Path ensureTinyMappings(String version) throws MappingsException {
        try {
            Files.createDirectories(cacheDir);
        } catch (IOException e) {
            throw new MappingsException("Не удалось создать кэш маппингов: " + cacheDir, e);
        }

        Path tiny = cacheDir.resolve(version + Constants.MOJMAP_TINY_SUFFIX);
        if (Files.isRegularFile(tiny)) {
            log.info("[1/4] Downloading mappings for {}... done (cached)", version);
            return tiny;
        }

        try {
            Path[] proguard = downloadProguard(version);
            convertToTiny(proguard[0], proguard[1], tiny);
            log.info("[1/4] Downloading mappings for {}... done", version);
            return tiny;
        } catch (IOException e) {
            throw new MappingsException(
                    "Не удалось получить маппинги для " + version + " (" + describe(e)
                            + "). Проверьте доступ в интернет: нужны launchermeta.mojang.com"
                            + " и piston-data.mojang.com", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new MappingsException("Скачивание маппингов для " + version + " прервано", e);
        }
    }

    /** Собирает читаемое описание исключения с цепочкой причин. */
    private static String describe(Throwable t) {
        StringBuilder sb = new StringBuilder();
        for (Throwable cur = t; cur != null; cur = cur.getCause()) {
            if (sb.length() > 0) {
                sb.append(" <- ");
            }
            sb.append(cur.getClass().getSimpleName());
            if (cur.getMessage() != null) {
                sb.append(": ").append(cur.getMessage());
            }
            if (cur.getCause() == cur) {
                break;
            }
        }
        return sb.toString();
    }

    /** @return [серверные, клиентские|null] ProGuard-файлы маппингов */
    private Path[] downloadProguard(String version) throws IOException, InterruptedException, MappingsException {
        log.debug("Запрашиваю манифест версий: {}", Constants.VERSION_MANIFEST_URL);
        JsonObject manifest = getJson(Constants.VERSION_MANIFEST_URL);

        String versionUrl = null;
        for (JsonElement el : manifest.getAsJsonArray("versions")) {
            JsonObject v = el.getAsJsonObject();
            if (version.equals(v.get("id").getAsString())) {
                versionUrl = v.get("url").getAsString();
                break;
            }
        }
        if (versionUrl == null) {
            throw new MappingsException("Версия Minecraft не найдена в манифесте Mojang: " + version);
        }

        log.debug("Запрашиваю version.json: {}", versionUrl);
        JsonObject versionJson = getJson(versionUrl);
        JsonObject downloads = versionJson.getAsJsonObject("downloads");
        if (downloads == null || !downloads.has(Constants.SERVER_MAPPINGS_KEY)) {
            throw new MappingsException(
                    "Для версии " + version + " нет официальных серверных маппингов "
                            + "(MojMap доступны начиная с 1.14.4)");
        }
        String serverUrl = downloads.getAsJsonObject(Constants.SERVER_MAPPINGS_KEY)
                .get("url").getAsString();
        Path server = cacheDir.resolve(version + "-server" + Constants.MOJMAP_PROGUARD_SUFFIX);
        log.debug("Скачиваю серверные ProGuard-маппинги: {}", serverUrl);
        download(serverUrl, server);

        Path client = null;
        if (downloads.has(Constants.CLIENT_MAPPINGS_KEY)) {
            String clientUrl = downloads.getAsJsonObject(Constants.CLIENT_MAPPINGS_KEY)
                    .get("url").getAsString();
            client = cacheDir.resolve(version + "-client" + Constants.MOJMAP_PROGUARD_SUFFIX);
            log.debug("Скачиваю клиентские ProGuard-маппинги: {}", clientUrl);
            download(clientUrl, client);
        }
        return new Path[]{server, client};
    }

    private JsonObject getJson(String url) throws IOException, InterruptedException, MappingsException {
        IOException last = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .header("User-Agent", "Minecraft Jar Migrator")
                        .GET().build();
                HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() != 200) {
                    throw new MappingsException("HTTP " + response.statusCode() + " при запросе " + url);
                }
                return JsonParser.parseString(response.body()).getAsJsonObject();
            } catch (IOException e) {
                last = e;
                if (attempt == MAX_RETRIES) {
                    throw e;
                }
                sleepBackoff(attempt);
            }
        }
        throw last == null ? new IOException("Unknown network failure") : last;
    }

    private void download(String url, Path target) throws IOException, InterruptedException, MappingsException {
        IOException last = null;
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .header("User-Agent", "Minecraft Jar Migrator")
                        .GET().build();
                HttpResponse<Path> response = http.send(request, HttpResponse.BodyHandlers.ofFile(target));
                if (response.statusCode() != 200) {
                    Files.deleteIfExists(target);
                    throw new MappingsException("HTTP " + response.statusCode() + " при скачивании " + url);
                }
                return;
            } catch (IOException e) {
                last = e;
                Files.deleteIfExists(target);
                if (attempt == MAX_RETRIES) {
                    throw e;
                }
                sleepBackoff(attempt);
            }
        }
        if (last != null) {
            throw last;
        }
    }

    private void sleepBackoff(int attempt) throws InterruptedException {
        Thread.sleep(250L * attempt);
    }

    /**
     * Конвертирует ProGuard-маппинги (named → obf) в tiny v2 с неймспейсами
     * {@code official} (src) и {@code named} (dst). Клиентские маппинги
     * подмешиваются к серверным: вместе они покрывают и сервер, и рендер/GUI.
     */
    private void convertToTiny(Path serverProguard, Path clientProguard, Path tiny)
            throws IOException {
        log.debug("Конвертирую {} (+client) → {}", serverProguard.getFileName(), tiny.getFileName());
        MemoryMappingTree tree = new MemoryMappingTree();
        readProguard(serverProguard, tree);
        if (clientProguard != null) {
            try {
                readProguard(clientProguard, tree);
            } catch (IOException | RuntimeException e) {
                log.warn("Клиентские маппинги не подмешаны ({}); используются только серверные",
                        e.getMessage());
            }
        }
        try (Writer writer = Files.newBufferedWriter(tiny, StandardCharsets.UTF_8)) {
            tree.accept(new Tiny2FileWriter(writer, false));
        }
    }

    private void readProguard(Path proguard, MemoryMappingTree tree) throws IOException {
        try (Reader reader = Files.newBufferedReader(proguard, StandardCharsets.UTF_8)) {
            // В ProGuard-файле слева читаемые имена, справа обфусцированные;
            // переключаем источник на "official", чтобы дерево было obf → named.
            ProGuardFileReader.read(reader, Constants.NS_NAMED, Constants.NS_OFFICIAL,
                    new MappingSourceNsSwitch(tree, Constants.NS_OFFICIAL));
        }
    }
}
