package com.mcmigrator.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import com.mcmigrator.ModType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * История миграций в {@code ~/.mcmigrator/history.json}: последние запуски
 * с параметрами и результатом, с возможностью повторить прогон из GUI.
 */
public final class MigrationHistory {

    private static final Logger log = LoggerFactory.getLogger(MigrationHistory.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_ENTRIES = 50;

    private final Path file;

    /** Одна запись истории. */
    public record Entry(
            String timestamp,
            String inputJar,
            String outputJar,
            String fromVersion,
            String toVersion,
            String modType,
            boolean cascade,
            boolean success) {

        /** @return строка для списка в GUI */
        public String display() {
            return (success ? "\u2713 " : "\u2717 ") + timestamp + "  "
                    + Path.of(inputJar).getFileName() + "  " + fromVersion
                    + " \u2192 " + toVersion + (cascade ? " (каскад)" : "");
        }

        /** @return тип мода как enum (best effort) */
        public ModType type() {
            try {
                return ModType.valueOf(modType);
            } catch (IllegalArgumentException e) {
                return ModType.PAPER;
            }
        }
    }

    /** @param baseDir обычно {@code ~/.mcmigrator} */
    public MigrationHistory(Path baseDir) {
        this.file = baseDir.resolve("history.json");
    }

    /** @return записи, новые первыми */
    public List<Entry> load() {
        if (!Files.isRegularFile(file)) {
            return List.of();
        }
        try {
            String json = Files.readString(file, StandardCharsets.UTF_8);
            List<Entry> entries = GSON.fromJson(json, new TypeToken<List<Entry>>() { }.getType());
            return entries == null ? List.of() : entries;
        } catch (IOException | JsonParseException e) {
            log.warn("История не читается: {}", e.getMessage());
            return List.of();
        }
    }

    /**
     * Добавляет запись (новые в начало, хвост обрезается).
     *
     * @param entry запись о прогоне
     */
    public void add(Entry entry) {
        List<Entry> entries = new ArrayList<>(load());
        entries.add(0, entry);
        if (entries.size() > MAX_ENTRIES) {
            entries = entries.subList(0, MAX_ENTRIES);
        }
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(entries), StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.warn("История не записана: {}", e.getMessage());
        }
    }

    /**
     * Фабрика записи «сейчас».
     *
     * @param input    входной jar
     * @param output   выходной jar
     * @param from     исходная версия
     * @param to       целевая версия
     * @param type     тип мода
     * @param cascade  каскадный ли прогон
     * @param success  успешен ли
     * @return запись истории
     */
    public static Entry now(Path input, Path output, String from, String to,
                            ModType type, boolean cascade, boolean success) {
        return new Entry(
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                input.toString(), output.toString(), from, to,
                type.name(), cascade, success);
    }
}
