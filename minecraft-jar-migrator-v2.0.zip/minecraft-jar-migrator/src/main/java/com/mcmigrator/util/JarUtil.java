package com.mcmigrator.util;

import com.mcmigrator.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.stream.Stream;

/**
 * Утилиты для работы с jar-архивами: подсчёт классов и сборка выходного
 * jar из скомпилированных классов плюс ресурсов исходного архива.
 */
public final class JarUtil {

    private static final Logger log = LoggerFactory.getLogger(JarUtil.class);

    private static final String MANIFEST_ENTRY = "META-INF/MANIFEST.MF";

    private JarUtil() {
    }

    /**
     * Считает количество {@code .class}-записей в jar.
     *
     * @param jar путь к архиву
     * @return число class-файлов
     * @throws IOException при ошибке чтения архива
     */
    public static int countClasses(Path jar) throws IOException {
        try (JarFile jarFile = new JarFile(jar.toFile())) {
            return (int) jarFile.stream()
                    .filter(e -> e.getName().endsWith(Constants.CLASS_EXT))
                    .count();
        }
    }

    /**
     * Собирает выходной jar: сначала все файлы из {@code classesDir},
     * затем ресурсы (не-{@code .class}) из {@code originalJar}.
     * Манифест берётся из оригинального jar; файлы подписей отбрасываются,
     * поскольку после модификации байткода подписи всё равно невалидны.
     *
     * @param classesDir  директория со скомпилированными классами
     * @param originalJar исходный jar (источник ресурсов и манифеста)
     * @param outputJar   путь к создаваемому архиву
     * @throws IOException при ошибке чтения/записи
     */
    public static void packJar(Path classesDir, Path originalJar, Path outputJar) throws IOException {
        packJar(classesDir, originalJar, outputJar, false);
    }

    /**
     * Та же сборка, но с возможностью забрать из {@code baseJar} и классы:
     * скомпилированные файлы из {@code classesDir} имеют приоритет, остальное
     * (классы + ресурсы) докладывается из базового jar.
     *
     * @param classesDir         директория со свежескомпилированными классами
     * @param baseJar            базовый jar (например, ремапнутый)
     * @param outputJar          путь к создаваемому архиву
     * @param includeBaseClasses включать ли {@code .class} из базового jar
     * @throws IOException при ошибке чтения/записи
     */
    public static void packJar(Path classesDir, Path baseJar, Path outputJar,
                               boolean includeBaseClasses) throws IOException {
        Manifest manifest = readManifest(baseJar);
        Set<String> written = new HashSet<>();
        written.add(MANIFEST_ENTRY);

        try (OutputStream fileOut = Files.newOutputStream(outputJar);
             JarOutputStream out = new JarOutputStream(fileOut, manifest)) {

            // 1. Скомпилированные классы (и всё, что лежит в classesDir).
            try (Stream<Path> walk = Files.walk(classesDir)) {
                List<Path> files = walk.filter(Files::isRegularFile).sorted().toList();
                for (Path file : files) {
                    String entryName = classesDir.relativize(file).toString().replace('\\', '/');
                    putEntry(out, written, entryName, () -> Files.newInputStream(file));
                }
            }

            // 2. Содержимое базового jar (без манифеста и подписей; классы —
            //    по флагу includeBaseClasses, дубликаты пропускаются).
            try (JarFile original = new JarFile(baseJar.toFile())) {
                Enumeration<JarEntry> entries = original.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (entry.isDirectory()
                            || (!includeBaseClasses && name.endsWith(Constants.CLASS_EXT))
                            || MANIFEST_ENTRY.equals(name)
                            || isSignatureFile(name)) {
                        continue;
                    }
                    putEntry(out, written, name, () -> original.getInputStream(entry));
                }
            }
        }
        log.debug("Выходной jar собран: {}", outputJar);
    }

    private static Manifest readManifest(Path baseJar) throws IOException {
        Manifest manifest = new Manifest();
        try (JarFile original = new JarFile(baseJar.toFile())) {
            Manifest existing = original.getManifest();
            if (existing != null) {
                manifest = new Manifest(existing);
            }
        }
        manifest.getMainAttributes()
                .putIfAbsent(Attributes.Name.MANIFEST_VERSION, "1.0");
        return manifest;
    }

    private static boolean isSignatureFile(String name) {
        String upper = name.toUpperCase(Locale.ROOT);
        return upper.startsWith("META-INF/")
                && (upper.endsWith(".SF") || upper.endsWith(".DSA")
                || upper.endsWith(".RSA") || upper.endsWith(".EC")
                || upper.startsWith("META-INF/SIG-"));
    }

    private static void putEntry(JarOutputStream out, Set<String> written,
                                 String name, StreamSupplier supplier) throws IOException {
        if (!written.add(name)) {
            log.debug("Дубликат записи пропущен: {}", name);
            return;
        }
        out.putNextEntry(new JarEntry(name));
        try (InputStream in = supplier.open()) {
            in.transferTo(out);
        }
        out.closeEntry();
    }

    /** Поставщик потока, которому разрешено бросать {@link IOException}. */
    @FunctionalInterface
    private interface StreamSupplier {
        InputStream open() throws IOException;
    }
}
