package com.mcmigrator.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Профили настроек GUI в {@code ~/.mcmigrator/profiles.json}: именованные
 * наборы (версии, тип, classpath, флажки), которые можно сохранять
 * и применять одним кликом.
 */
public final class SettingsProfiles {

    private static final Logger log = LoggerFactory.getLogger(SettingsProfiles.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path file;

    /** Снимок настроек формы. */
    public record Profile(
            String fromVersion,
            String toVersion,
            String modType,
            String ecosystem,
            String classpath,
            boolean keepSources,
            boolean dryRun,
            boolean autoClasspath,
            boolean cascade,
            String decompiler,
            boolean decompileCache) {

        public Profile {
            if (decompiler == null) decompiler = "VINEFLOWER";
        }
    }

    /** @param baseDir обычно {@code ~/.mcmigrator} */
    public SettingsProfiles(Path baseDir) {
        this.file = baseDir.resolve("profiles.json");
    }

    /** @return профили по имени (порядок сохранения) */
    public Map<String, Profile> load() {
        if (!Files.isRegularFile(file)) {
            return new LinkedHashMap<>();
        }
        try {
            String json = Files.readString(file, StandardCharsets.UTF_8);
            Map<String, Profile> map = GSON.fromJson(json,
                    new TypeToken<LinkedHashMap<String, Profile>>() { }.getType());
            return map == null ? new LinkedHashMap<>() : map;
        } catch (IOException | JsonParseException e) {
            log.warn("Профили не читаются: {}", e.getMessage());
            return new LinkedHashMap<>();
        }
    }

    /**
     * Сохраняет/перезаписывает профиль.
     *
     * @param name    имя профиля
     * @param profile содержимое
     */
    public void save(String name, Profile profile) {
        Map<String, Profile> map = load();
        map.put(name, profile);
        write(map);
    }

    /**
     * Удаляет профиль.
     *
     * @param name имя профиля
     */
    public void delete(String name) {
        Map<String, Profile> map = load();
        map.remove(name);
        write(map);
    }

    private void write(Map<String, Profile> map) {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(map), StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.warn("Профили не записаны: {}", e.getMessage());
        }
    }
}
