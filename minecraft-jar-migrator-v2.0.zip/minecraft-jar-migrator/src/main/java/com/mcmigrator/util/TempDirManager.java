package com.mcmigrator.util;

import com.mcmigrator.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Stream;

/**
 * Создаёт временную директорию пайплайна и гарантированно удаляет её
 * при закрытии (использовать через try-with-resources).
 */
public final class TempDirManager implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(TempDirManager.class);

    private final Path root;

    private TempDirManager(Path root) {
        this.root = root;
    }

    /**
     * Создаёт новую временную директорию с префиксом {@link Constants#TEMP_PREFIX}.
     *
     * @return менеджер созданной директории
     * @throws IOException если директорию создать не удалось
     */
    public static TempDirManager create() throws IOException {
        Path root = Files.createTempDirectory(Constants.TEMP_PREFIX);
        log.debug("Временная директория: {}", root);
        return new TempDirManager(root);
    }

    /** @return корень временной директории */
    public Path root() {
        return root;
    }

    /**
     * @param other относительный путь внутри временной директории
     * @return абсолютный путь {@code root/other}
     */
    public Path resolve(String other) {
        return root.resolve(other);
    }

    /** Рекурсивно удаляет временную директорию; ошибки удаления — только в WARN. */
    @Override
    public void close() {
        if (!Files.exists(root)) {
            return;
        }
        try (Stream<Path> walk = Files.walk(root)) {
            walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException e) {
                    log.warn("Не удалось удалить временный файл {}: {}", path, e.getMessage());
                }
            });
            log.debug("Временная директория удалена: {}", root);
        } catch (IOException e) {
            log.warn("Не удалось очистить временную директорию {}: {}", root, e.getMessage());
        }
    }
}
