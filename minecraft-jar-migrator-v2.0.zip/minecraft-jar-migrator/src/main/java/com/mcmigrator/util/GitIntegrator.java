package com.mcmigrator.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class GitIntegrator {

    private static final Logger log = LoggerFactory.getLogger(GitIntegrator.class);

    public record GitStatus(boolean available, boolean isRepo, String branch, boolean clean) {}

    private GitIntegrator() {
    }

    public static GitStatus checkStatus(Path directory) {
        if (!isGitAvailable()) {
            return new GitStatus(false, false, null, false);
        }
        Path gitDir = findGitDir(directory);
        if (gitDir == null) {
            return new GitStatus(true, false, null, false);
        }
        String branch = runGit(directory, "branch", "--show-current");
        boolean clean = runGit(directory, "status", "--porcelain").isEmpty();
        return new GitStatus(true, true, branch, clean);
    }

    public static boolean createBranch(Path directory, String branchName) {
        return runGit(directory, "checkout", "-b", branchName) != null;
    }

    public static boolean commit(Path directory, String message) {
        if (runGit(directory, "add", "-A") == null) return false;
        return runGit(directory, "commit", "-m", message) != null;
    }

    public static boolean autoCommit(Path directory, String fromVersion, String toVersion) {
        GitStatus status = checkStatus(directory);
        if (!status.isRepo()) {
            log.debug("Not a git repository — skipping auto-commit");
            return false;
        }
        String branchName = "migrate-" + fromVersion + "-to-" + toVersion;
        if (!createBranch(directory, branchName)) {
            log.warn("Could not create git branch {}", branchName);
            return false;
        }
        String msg = "Auto-migration: " + fromVersion + " -> " + toVersion;
        if (commit(directory, msg)) {
            log.info("Git: committed on branch '{}'", branchName);
            return true;
        }
        return false;
    }

    public static String getDiff(Path directory) {
        return runGit(directory, "diff", "--stat");
    }

    public static String getDiff(Path directory, Path file) {
        return runGit(directory, "diff", file.toString());
    }

    public static boolean reset(Path directory) {
        return runGit(directory, "checkout", "--", ".") != null
                && runGit(directory, "clean", "-fd") != null;
    }

    private static boolean isGitAvailable() {
        try {
            Process p = new ProcessBuilder("git", "--version")
                    .redirectErrorStream(true).start();
            p.waitFor();
            return p.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private static Path findGitDir(Path start) {
        Path current = start.toAbsolutePath();
        while (current != null) {
            if (Files.isDirectory(current.resolve(".git"))) {
                return current;
            }
            current = current.getParent();
        }
        return null;
    }

    private static String runGit(Path directory, String... args) {
        try {
            List<String> cmd = new ArrayList<>();
            cmd.add("git");
            for (String arg : args) cmd.add(arg);
            ProcessBuilder pb = new ProcessBuilder(cmd)
                    .directory(directory.toFile())
                    .redirectErrorStream(true);
            Process p = pb.start();
            String output = new String(p.getInputStream().readAllBytes()).trim();
            p.waitFor();
            return p.exitValue() == 0 ? output : null;
        } catch (IOException | InterruptedException e) {
            log.debug("Git command failed: {}", e.getMessage());
            return null;
        }
    }
}
