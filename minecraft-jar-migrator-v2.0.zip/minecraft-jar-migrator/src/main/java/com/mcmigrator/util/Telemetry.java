package com.mcmigrator.util;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;

public final class Telemetry {

    private static final Logger log = LoggerFactory.getLogger(Telemetry.class);
    private static final String ENDPOINT = "https://mcmigrator-telemetry.example.com/v1/event";

    private final Path configFile;
    private boolean enabled;

    public Telemetry(Path baseDir) {
        this.configFile = baseDir.resolve("telemetry.json");
        this.enabled = loadEnabled();
    }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        saveEnabled();
    }

    public void reportMigration(String from, String to, String type, boolean success, long durationMs) {
        if (!enabled) return;
        try {
            JsonObject event = new JsonObject();
            event.addProperty("event", "migration");
            event.addProperty("from", from);
            event.addProperty("to", to);
            event.addProperty("type", type);
            event.addProperty("success", success);
            event.addProperty("duration_ms", durationMs);
            event.addProperty("version", com.mcmigrator.Constants.TOOL_VERSION);
            sendAsync(event);
        } catch (Exception e) {
            log.debug("Telemetry failed: {}", e.getMessage());
        }
    }

    private void sendAsync(JsonObject event) {
        Thread t = new Thread(() -> {
            try {
                HttpClient http = HttpClient.newBuilder()
                        .connectTimeout(Duration.ofSeconds(5))
                        .build();
                HttpRequest request = HttpRequest.newBuilder(URI.create(ENDPOINT))
                        .header("Content-Type", "application/json")
                        .header("User-Agent", "MinecraftJarMigrator")
                        .POST(HttpRequest.BodyPublishers.ofString(
                                new Gson().toJson(event), StandardCharsets.UTF_8))
                        .build();
                http.send(request, HttpResponse.BodyHandlers.discarding());
            } catch (Exception ignored) {}
        }, "telemetry");
        t.setDaemon(true);
        t.start();
    }

    private boolean loadEnabled() {
        try {
            if (Files.isRegularFile(configFile)) {
                String json = Files.readString(configFile, StandardCharsets.UTF_8);
                return json.contains("\"enabled\":true");
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void saveEnabled() {
        try {
            Files.createDirectories(configFile.getParent());
            JsonObject obj = new JsonObject();
            obj.addProperty("enabled", enabled);
            Files.writeString(configFile, new Gson().toJson(obj), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }
}
