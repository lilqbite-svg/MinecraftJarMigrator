package com.mcmigrator.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.Set;
import java.util.HashSet;

public final class JarDiffUtil {

    public record JarDiff(
            List<String> added,
            List<String> removed,
            List<String> modified,
            List<String> unchanged) {}

    public static JarDiff diff(Path oldJar, Path newJar) throws IOException {
        Set<String> oldEntries = new HashSet<>();
        Set<String> newEntries = new HashSet<>();

        try (JarFile jf = new JarFile(oldJar.toFile())) {
            Enumeration<JarEntry> e = jf.entries();
            while (e.hasMoreElements()) oldEntries.add(e.nextElement().getName());
        }
        try (JarFile jf = new JarFile(newJar.toFile())) {
            Enumeration<JarEntry> e = jf.entries();
            while (e.hasMoreElements()) newEntries.add(e.nextElement().getName());
        }

        List<String> added = new ArrayList<>();
        List<String> removed = new ArrayList<>();
        List<String> modified = new ArrayList<>();
        List<String> unchanged = new ArrayList<>();

        for (String entry : newEntries) {
            if (!oldEntries.contains(entry)) {
                added.add(entry);
            } else if (entry.endsWith(".class")) {
                byte[] oldBytes = readEntry(oldJar, entry);
                byte[] newBytes = readEntry(newJar, entry);
                if (oldBytes != null && newBytes != null
                        && !java.util.Arrays.equals(oldBytes, newBytes)) {
                    modified.add(entry);
                } else {
                    unchanged.add(entry);
                }
            } else {
                unchanged.add(entry);
            }
        }
        for (String entry : oldEntries) {
            if (!newEntries.contains(entry)) {
                removed.add(entry);
            }
        }

        return new JarDiff(added, removed, modified, unchanged);
    }

    public static String renderDiff(JarDiff diff) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== JAR Diff ===\n");
        sb.append("Added: ").append(diff.added().size()).append("\n");
        sb.append("Removed: ").append(diff.removed().size()).append("\n");
        sb.append("Modified: ").append(diff.modified().size()).append("\n");
        sb.append("Unchanged: ").append(diff.unchanged().size()).append("\n\n");

        if (!diff.added().isEmpty()) {
            sb.append("--- Added ---\n");
            diff.added().forEach(e -> sb.append("  + ").append(e).append("\n"));
        }
        if (!diff.removed().isEmpty()) {
            sb.append("--- Removed ---\n");
            diff.removed().forEach(e -> sb.append("  - ").append(e).append("\n"));
        }
        if (!diff.modified().isEmpty()) {
            sb.append("--- Modified ---\n");
            diff.modified().forEach(e -> sb.append("  ~ ").append(e).append("\n"));
        }
        return sb.toString();
    }

    public static Path exportPatch(Path oldJar, Path newJar, Path outputDir) throws IOException {
        JarDiff diff = diff(oldJar, newJar);
        Files.createDirectories(outputDir);

        StringBuilder patch = new StringBuilder();
        patch.append("# Migration patch: ").append(oldJar.getFileName())
                .append(" -> ").append(newJar.getFileName()).append("\n");
        patch.append(renderDiff(diff));

        Path patchFile = outputDir.resolve("migration.patch");
        Files.writeString(patchFile, patch.toString(), StandardCharsets.UTF_8);
        return patchFile;
    }

    private static byte[] readEntry(Path jar, String entryName) {
        try (JarFile jf = new JarFile(jar.toFile())) {
            JarEntry entry = jf.getJarEntry(entryName);
            if (entry == null) return null;
            try (var is = jf.getInputStream(entry)) {
                return is.readAllBytes();
            }
        } catch (IOException e) {
            return null;
        }
    }
}
