package com.mcmigrator.util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Обновляет декларации версии Minecraft в {@code fabric.mod.json}
 * выходного jar (и рекурсивно во вложенных Jar-in-Jar), чтобы Fabric Loader
 * не отклонял мигрированный мод из-за старого ограничения
 * {@code "minecraft": "1.21.x"}.
 */
public final class FabricMetadataPatcher {

    private static final Logger log = LoggerFactory.getLogger(FabricMetadataPatcher.class);
    private static final Gson GSON = new Gson();
    private static final int MAX_DEPTH = 3;

    private FabricMetadataPatcher() {
    }

    /**
     * Патчит jar на месте: во всех найденных {@code fabric.mod.json}
     * (корень + вложенные jar до глубины {@value MAX_DEPTH}) ограничение
     * {@code depends.minecraft} заменяется на {@code ">=" + toVersion}.
     *
     * @param jar       путь к jar
     * @param toVersion целевая версия Minecraft
     * @return число пропатченных fabric.mod.json
     * @throws IOException при ошибке чтения/записи
     */
    public static int patch(Path jar, String toVersion) throws IOException {
        byte[] original = Files.readAllBytes(jar);
        int[] patched = {0};
        byte[] result = patchBytes(original, toVersion, MAX_DEPTH, patched);
        if (patched[0] > 0) {
            Path tmp = jar.resolveSibling(jar.getFileName() + ".tmp");
            Files.write(tmp, result);
            Files.move(tmp, jar, StandardCopyOption.REPLACE_EXISTING);
        }
        return patched[0];
    }

    private static byte[] patchBytes(byte[] jarBytes, String toVersion, int depth, int[] patched)
            throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(jarBytes.length);
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(jarBytes));
             ZipOutputStream out = new ZipOutputStream(buffer)) {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                byte[] data = readAll(in);
                String name = entry.getName();
                if ("fabric.mod.json".equals(name)) {
                    byte[] updated = patchModJson(data, toVersion);
                    if (updated != null) {
                        data = updated;
                        patched[0]++;
                    }
                } else if (depth > 0 && name.startsWith("META-INF/jars/")
                        && name.endsWith(".jar")) {
                    data = patchBytes(data, toVersion, depth - 1, patched);
                }
                out.putNextEntry(new ZipEntry(name));
                out.write(data);
                out.closeEntry();
            }
        }
        return buffer.toByteArray();
    }

    /** @return обновлённый JSON или {@code null}, если менять нечего */
    private static byte[] patchModJson(byte[] data, String toVersion) {
        try {
            JsonObject json = JsonParser
                    .parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            if (!json.has("depends")) {
                return null;
            }
            JsonObject depends = json.getAsJsonObject("depends");
            if (!depends.has("minecraft")) {
                return null;
            }
            JsonElement old = depends.get("minecraft");
            String constraint = ">=" + toVersion;
            depends.add("minecraft", new JsonPrimitive(constraint));
            log.debug("fabric.mod.json ({}): minecraft {} -> {}",
                    json.has("id") ? json.get("id").getAsString() : "?", old, constraint);
            return GSON.toJson(json).getBytes(StandardCharsets.UTF_8);
        } catch (RuntimeException e) {
            log.warn("fabric.mod.json не распарсился — пропущен ({})", e.getMessage());
            return null;
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        in.transferTo(out);
        return out.toByteArray();
    }
}
