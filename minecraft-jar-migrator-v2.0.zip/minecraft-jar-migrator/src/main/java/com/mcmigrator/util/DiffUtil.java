package com.mcmigrator.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Минимальный построчный diff (LCS) для показа «было → стало» изменённых
 * трансформациями файлов. Для очень больших файлов выдаёт усечённый
 * результат, чтобы не жечь память.
 */
public final class DiffUtil {

    private static final int MAX_LINES = 4000;

    private DiffUtil() {
    }

    /**
     * Строит unified-подобный diff.
     *
     * @param oldText исходный текст
     * @param newText изменённый текст
     * @return текст diff: контекст без префикса, удалённое с {@code -}, добавленное с {@code +}
     */
    public static String unified(String oldText, String newText) {
        String[] a = oldText.split("\n", -1);
        String[] b = newText.split("\n", -1);
        if (a.length > MAX_LINES || b.length > MAX_LINES) {
            return "(файл слишком большой для diff: " + a.length + " → " + b.length + " строк)";
        }

        int[][] lcs = new int[a.length + 1][b.length + 1];
        for (int i = a.length - 1; i >= 0; i--) {
            for (int j = b.length - 1; j >= 0; j--) {
                lcs[i][j] = a[i].equals(b[j])
                        ? lcs[i + 1][j + 1] + 1
                        : Math.max(lcs[i + 1][j], lcs[i][j + 1]);
            }
        }

        List<String> out = new ArrayList<>();
        int i = 0;
        int j = 0;
        while (i < a.length && j < b.length) {
            if (a[i].equals(b[j])) {
                out.add("  " + a[i]);
                i++;
                j++;
            } else if (lcs[i + 1][j] >= lcs[i][j + 1]) {
                out.add("- " + a[i++]);
            } else {
                out.add("+ " + b[j++]);
            }
        }
        while (i < a.length) {
            out.add("- " + a[i++]);
        }
        while (j < b.length) {
            out.add("+ " + b[j++]);
        }
        return compactContext(out);
    }

    /** Сжимает длинные неизменённые блоки до «… N строк без изменений …». */
    private static String compactContext(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        int contextRun = 0;
        List<String> buffer = new ArrayList<>();
        for (String line : lines) {
            if (line.startsWith("  ")) {
                buffer.add(line);
                contextRun++;
            } else {
                flushContext(sb, buffer, contextRun);
                buffer.clear();
                contextRun = 0;
                sb.append(line).append('\n');
            }
        }
        flushContext(sb, buffer, contextRun);
        return sb.toString();
    }

    private static void flushContext(StringBuilder sb, List<String> buffer, int run) {
        if (run <= 6) {
            buffer.forEach(l -> sb.append(l).append('\n'));
            return;
        }
        for (int k = 0; k < 3; k++) {
            sb.append(buffer.get(k)).append('\n');
        }
        sb.append("  … ").append(run - 6).append(" строк без изменений …\n");
        for (int k = run - 3; k < run; k++) {
            sb.append(buffer.get(k)).append('\n');
        }
    }
}
