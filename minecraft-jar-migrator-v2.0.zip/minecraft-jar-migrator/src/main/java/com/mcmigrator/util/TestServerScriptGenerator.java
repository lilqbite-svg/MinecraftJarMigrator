package com.mcmigrator.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class TestServerScriptGenerator {

    private TestServerScriptGenerator() {
    }

    public static Path generate(Path outputJar, String toVersion) throws IOException {
        Path script = outputJar.resolveSibling("test-server-" + toVersion + ".bat");
        String jarName = outputJar.getFileName().toString();
        int javaReq = requiredJava(toVersion);

        String content = "@echo off\r\n"
                + "chcp 65001 >nul\r\n"
                + "rem ============================================================\r\n"
                + "rem  Smoke-test for migrated mod on Fabric server %MC%\r\n"
                + "rem  Downloads server (once), puts mod in mods/ and starts\r\n"
                + "rem  with exit flag after loading. Check output: if mod is\r\n"
                + "rem  listed and no \"Mixin apply failed\" - loading succeeded.\r\n"
                + "rem  Requires Java " + javaReq + "+ installed in PATH.\r\n"
                + "rem ============================================================\r\n"
                + "setlocal\r\n"
                + "set MC=" + toVersion + "\r\n"
                + "set DIR=%~dp0test-server-%MC%\r\n"
                + "if not exist \"%DIR%\" mkdir \"%DIR%\"\r\n"
                + "cd /d \"%DIR%\"\r\n"
                + "\r\n"
                + "if not exist fabric-server.jar (\r\n"
                + "  echo Downloading Fabric server %MC%...\r\n"
                + "  powershell -NoProfile -Command \"Invoke-WebRequest 'https://meta.fabricmc.net/v2/versions/loader/%MC%/stable/stable/server/jar' -OutFile 'fabric-server.jar'\" || goto :err\r\n"
                + ")\r\n"
                + "if not exist mods mkdir mods\r\n"
                + "copy /y \"%~dp0" + jarName + "\" mods\\ >nul || goto :err\r\n"
                + "echo eula=true> eula.txt\r\n"
                + "\r\n"
                + "echo Starting server (smoke-test)...\r\n"
                + "java -Xmx2G -jar fabric-server.jar nogui --initSettings\r\n"
                + "java -Xmx2G -Dfabric.loader.exitAfterLoad=true -jar fabric-server.jar nogui\r\n"
                + "echo.\r\n"
                + "echo Test complete. Look for mod name above and Mixin errors.\r\n"
                + "pause\r\n"
                + "goto :eof\r\n"
                + ":err\r\n"
                + "echo ERROR - see messages above.\r\n"
                + "pause\r\n";

        Files.writeString(script, content, StandardCharsets.UTF_8);
        return script;
    }

    private static int requiredJava(String mcVersion) {
        try {
            String[] parts = mcVersion.split("\\.");
            int major = Integer.parseInt(parts[0]);
            if (major >= 26) return 26;
            int minor = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            int patch = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            if (minor > 20 || (minor == 20 && patch >= 5)) return 21;
            return 17;
        } catch (NumberFormatException e) {
            return 21;
        }
    }
}
