package com.mcmigrator.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public final class SmokeTestRunner {

    private static final Logger log = LoggerFactory.getLogger(SmokeTestRunner.class);
    private static final int TIMEOUT_SECONDS = 60;

    public record SmokeTestResult(
            boolean success,
            int exitCode,
            List<String> errors,
            List<String> warnings,
            String log) {}

    public static SmokeTestResult run(Path migratedJar, String mcVersion, Path serverJar) {
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        StringBuilder fullLog = new StringBuilder();

        try {
            Path testDir = Files.createTempDirectory("smoke-test-");
            Path modsDir = testDir.resolve("mods");
            Files.createDirectories(modsDir);
            Files.copy(migratedJar, modsDir.resolve(migratedJar.getFileName()));

            List<String> cmd = new ArrayList<>();
            cmd.add("java");
            cmd.add("-jar");
            cmd.add(serverJar.toAbsolutePath().toString());
            cmd.add("--nogui");
            cmd.add("--noconsole");

            ProcessBuilder pb = new ProcessBuilder(cmd)
                    .directory(testDir.toFile())
                    .redirectErrorStream(true);

            log.info("[Smoke-test] Starting server for MC {}...", mcVersion);
            Process process = pb.start();

            try (InputStream is = process.getInputStream()) {
                byte[] buf = new byte[4096];
                int read;
                boolean eulaAccepted = false;
                while ((read = is.read(buf)) != -1) {
                    String chunk = new String(buf, 0, read, StandardCharsets.UTF_8);
                    fullLog.append(chunk);

                    for (String line : chunk.split("\n")) {
                        if (line.contains("You need to agree to the EULA")) {
                            Path eula = testDir.resolve("eula.txt");
                            Files.writeString(eula, "eula=true", StandardCharsets.UTF_8);
                            eulaAccepted = true;
                        }
                        if (line.contains("ClassNotFoundException")
                                || line.contains("NoSuchMethodError")
                                || line.contains("NoSuchFieldError")) {
                            errors.add(line.trim());
                        }
                        if (line.contains("ERROR") || line.contains("Exception")) {
                            warnings.add(line.trim());
                        }
                        if (line.contains("Done") && line.contains("For help")) {
                            log.info("[Smoke-test] Server started successfully");
                            process.destroy();
                            return new SmokeTestResult(true, 0, errors, warnings,
                                    fullLog.toString());
                        }
                    }
                }
            }

            boolean finished = process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                warnings.add("Server did not start within " + TIMEOUT_SECONDS + "s timeout");
            }

            int exit = process.exitValue();
            return new SmokeTestResult(exit == 0 && errors.isEmpty(), exit, errors, warnings,
                    fullLog.toString());

        } catch (IOException | InterruptedException e) {
            errors.add("Smoke test failed: " + e.getMessage());
            return new SmokeTestResult(false, -1, errors, warnings, fullLog.toString());
        }
    }
}
