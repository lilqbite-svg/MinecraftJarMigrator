package com.mcmigrator.util;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Минимальная локализация GUI: бандлы {@code i18n/messages_{ru,en}.properties}.
 * Язык берётся из системной локали; принудительно — системным свойством
 * {@code -Dmcmigrator.lang=en}.
 */
public final class I18n {

    private static final ResourceBundle BUNDLE = loadBundle();

    private I18n() {
    }

    /**
     * @param key ключ строки
     * @return локализованная строка либо сам ключ, если перевода нет
     */
    public static String t(String key) {
        try {
            return BUNDLE.getString(key);
        } catch (MissingResourceException e) {
            return key;
        }
    }

    private static ResourceBundle loadBundle() {
        String forced = System.getProperty("mcmigrator.lang");
        Locale locale = forced != null ? Locale.forLanguageTag(forced) : Locale.getDefault();
        try {
            return ResourceBundle.getBundle("i18n.messages", locale);
        } catch (MissingResourceException e) {
            return ResourceBundle.getBundle("i18n.messages", Locale.forLanguageTag("ru"));
        }
    }
}
