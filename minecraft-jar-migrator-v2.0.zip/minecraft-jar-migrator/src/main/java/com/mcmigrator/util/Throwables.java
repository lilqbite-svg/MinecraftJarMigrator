package com.mcmigrator.util;

/** Утилиты для читаемого описания исключений. */
public final class Throwables {

    private Throwables() {
    }

    /**
     * @param t исключение
     * @return описание с цепочкой причин: {@code "FooException: msg <- BarException"}
     */
    public static String describe(Throwable t) {
        StringBuilder sb = new StringBuilder();
        for (Throwable cur = t; cur != null; cur = cur.getCause()) {
            if (sb.length() > 0) {
                sb.append(" <- ");
            }
            sb.append(cur.getClass().getSimpleName());
            if (cur.getMessage() != null) {
                sb.append(": ").append(cur.getMessage());
            }
            if (cur.getCause() == cur) {
                break;
            }
        }
        return sb.toString();
    }
}
