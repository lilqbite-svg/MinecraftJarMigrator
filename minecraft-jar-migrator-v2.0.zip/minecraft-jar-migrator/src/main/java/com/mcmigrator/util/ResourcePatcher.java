package com.mcmigrator.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class ResourcePatcher {

    private static final Logger log = LoggerFactory.getLogger(ResourcePatcher.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ResourcePatcher() {
    }

    public static int patchAll(Path jar, String toVersion) throws IOException {
        byte[] original = Files.readAllBytes(jar);
        int[] patched = {0};
        byte[] result = patchBytes(original, toVersion, patched);
        if (patched[0] > 0) {
            Path tmp = jar.resolveSibling(jar.getFileName() + ".tmp");
            Files.write(tmp, result);
            Files.move(tmp, jar, StandardCopyOption.REPLACE_EXISTING);
        }
        return patched[0];
    }

    private static byte[] patchBytes(byte[] jarBytes, String toVersion, int[] patched)
            throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(jarBytes.length);
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(jarBytes));
             ZipOutputStream out = new ZipOutputStream(buffer)) {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    out.putNextEntry(entry);
                    out.closeEntry();
                    continue;
                }
                byte[] data = readAll(in);
                String name = entry.getName();

                if ("fabric.mod.json".equals(name)) {
                    byte[] updated = patchFabricModJson(data, toVersion);
                    if (updated != null) { data = updated; patched[0]++; }
                } else if ("META-INF/mods.toml".equals(name) || "META-INF/neoforge.mods.toml".equals(name)) {
                    byte[] updated = patchModsToml(data, toVersion);
                    if (updated != null) { data = updated; patched[0]++; }
                } else if ("plugin.yml".equals(name) || "paper-plugin.yml".equals(name)) {
                    byte[] updated = patchPluginYml(data, toVersion);
                    if (updated != null) { data = updated; patched[0]++; }
                } else if ("pack.mcmeta".equals(name)) {
                    byte[] updated = packMcmeta(data, toVersion);
                    if (updated != null) { data = updated; patched[0]++; }
                } else if (name.startsWith("META-INF/jars/") && name.endsWith(".jar")) {
                    data = patchBytes(data, toVersion, patched);
                }

                out.putNextEntry(new ZipEntry(name));
                out.write(data);
                out.closeEntry();
            }
        }
        return buffer.toByteArray();
    }

    private static byte[] patchFabricModJson(byte[] data, String toVersion) {
        try {
            JsonObject json = JsonParser
                    .parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;
            if (json.has("depends")) {
                JsonObject depends = json.getAsJsonObject("depends");
                if (depends.has("minecraft")) {
                    depends.add("minecraft", new JsonPrimitive(">=" + toVersion));
                    changed = true;
                }
            }
            if (json.has("depends") && json.getAsJsonObject("depends").has("fabricloader")) {
                // keep as-is unless version is too old
            }
            return changed ? GSON.toJson(json).getBytes(StandardCharsets.UTF_8) : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static byte[] patchModsToml(byte[] data, String toVersion) {
        try {
            String content = new String(data, StandardCharsets.UTF_8);
            String[] verParts = toVersion.split("\\.");
            String toMajor = verParts.length >= 2
                    ? verParts[0] + "." + verParts[1] : toVersion;

            boolean changed = false;
            // Update loaderVersion if it references old MC
            if (content.contains("loaderVersion")) {
                // Forge/NeoForge TOML format — leave as-is (complex to parse without TOML lib)
            }
            // Update minecraft version range
            if (content.contains("[[dependencies.")) {
                // Add a warning comment
                if (!content.contains("mcmigrator-auto-patched")) {
                    content = "# mcmigrator-auto-patched: target MC " + toVersion + "\n" + content;
                    changed = true;
                }
            }
            return changed ? content.getBytes(StandardCharsets.UTF_8) : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static byte[] patchPluginYml(byte[] data, String toVersion) {
        try {
            String content = new String(data, StandardCharsets.UTF_8);
            String[] verParts = toVersion.split("\\.");
            String toMajor = verParts.length >= 2
                    ? verParts[0] + "." + verParts[1] : toVersion;
            boolean changed = false;

            // Update api-version
            if (content.contains("api-version:")) {
                String[] lines = content.split("\n");
                StringBuilder sb = new StringBuilder();
                for (String line : lines) {
                    if (line.trim().startsWith("api-version:")) {
                        String indent = line.substring(0, line.indexOf("api-version"));
                        sb.append(indent).append("api-version: '").append(toMajor).append("'\n");
                        changed = true;
                    } else {
                        sb.append(line).append("\n");
                    }
                }
                return changed ? sb.toString().getBytes(StandardCharsets.UTF_8) : null;
            }
            return null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static byte[] packMcmeta(byte[] data, String toVersion) {
        try {
            JsonObject json = JsonParser
                    .parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            if (!json.has("pack")) return null;
            JsonObject pack = json.getAsJsonObject("pack");
            int packFormat = getPackFormat(toVersion);
            if (packFormat <= 0) return null;
            if (pack.has("pack_format") && pack.get("pack_format").getAsInt() == packFormat) {
                return null;
            }
            pack.addProperty("pack_format", packFormat);
            return GSON.toJson(json).getBytes(StandardCharsets.UTF_8);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static int getPackFormat(String version) {
        try {
            String[] parts = version.split("\\.");
            int major = Integer.parseInt(parts[0]);
            int minor = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            int patch = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            if (major >= 26) return 61;
            if (minor == 21 && patch >= 5) return 46;
            if (minor == 21 && patch >= 2) return 34;
            if (minor == 21) return 32;
            if (minor == 20 && patch >= 5) return 32;
            if (minor == 20 && patch >= 3) return 26;
            if (minor == 20) return 18;
            if (minor == 19 && patch >= 4) return 18;
            if (minor == 19 && patch >= 3) return 12;
            if (minor == 19) return 9;
            if (minor == 18) return 9;
            if (minor == 17) return 7;
            if (minor >= 15) return 6;
            return 4;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        in.transferTo(out);
        return out.toByteArray();
    }
}
