package com.mcmigrator;

import ch.qos.logback.classic.Level;
import com.mcmigrator.decompiler.DecompilerType;
import com.mcmigrator.exception.MigrationException;
import com.mcmigrator.pipeline.MigrationConfig;
import com.mcmigrator.pipeline.MigrationPipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;

/**
 * Точка входа CLI: разбирает аргументы через Picocli и запускает
 * {@link MigrationPipeline}.
 */
@Command(
        name = "mcmigrator",
        mixinStandardHelpOptions = true,
        version = Constants.TOOL_NAME + " v" + Constants.TOOL_VERSION,
        description = "Мигрирует jar мода/плагина Minecraft между версиями: "
                + "remap → decompile → transform → compile.")
public final class Main implements Callable<Integer> {

    private static final Logger log = LoggerFactory.getLogger(Main.class);

    @Option(names = {"-i", "--input"}, required = true,
            description = "Путь к входному .jar")
    private Path input;

    @Option(names = {"-o", "--output"}, required = true,
            description = "Путь к выходному .jar")
    private Path output;

    @Option(names = "--from", required = true,
            description = "Версия Minecraft источника, например 1.20.3")
    private String fromVersion;

    @Option(names = "--to", required = true,
            description = "Целевая версия Minecraft, например 1.21.1")
    private String toVersion;

    @Option(names = "--type", defaultValue = "paper",
            description = "Тип мода: ${COMPLETION-CANDIDATES} (default: ${DEFAULT-VALUE})")
    private ModType type;

    @Option(names = "--keep-sources",
            description = "Сохранить декомпилированные исходники рядом с выходным jar")
    private boolean keepSources;

    @Option(names = "--mappings-dir",
            description = "Папка кэша .tiny маппингов (default: ~/" + Constants.DEFAULT_MAPPINGS_DIR + ")")
    private Path mappingsDir;

    @Option(names = "--classpath", split = ",",
            description = "Доп. classpath для рекомпиляции (server jar, API), через запятую")
    private List<Path> classpath = new ArrayList<>();

    @Option(names = "--auto-classpath", negatable = true, defaultValue = "true",
            fallbackValue = "true",
            description = "Автоматически скачать classpath (server jar, API) для целевой версии "
                    + "(default: ${DEFAULT-VALUE}); отключить: --no-auto-classpath")
    private boolean autoClasspath;

    @Option(names = "--dry-run",
            description = "Показать изменения, не записывая файлы вне temp-директории")
    private boolean dryRun;

    @Option(names = "--cascade",
            description = "Идти каскадом через все промежуточные версии")
    private boolean cascade;

    @Option(names = "--batch",
            description = "Пакетный режим: --input и --output трактуются как ПАПКИ с jar")
    private boolean batch;

    @Option(names = "--disable-rule", paramLabel = "DESCRIPTION",
            description = "Disable a rule by its description (can be repeated)")
    private List<String> disabledRules = new ArrayList<>();

    @Option(names = "--decompiler", defaultValue = "VINEFLOWER",
            description = "Decompiler backend: ${COMPLETION-CANDIDATES} (default: ${DEFAULT-VALUE})")
    private DecompilerType decompilerType;

    @Option(names = "--no-decompile-cache",
            description = "Disable decompilation result caching")
    private boolean noDecompileCache;

    @Option(names = "--parallel",
            description = "Parallel decompilation across CPU cores (Vineflower only)")
    private boolean parallelDecompile;

    @Option(names = "--interactive",
            description = "Interactive rule selection before migration")
    private boolean interactive;

    @Option(names = {"-v", "--verbose"},
            description = "Verbose output (DEBUG level)")
    private boolean verbose;

    /**
     * Запускает приложение: без аргументов — графический интерфейс,
     * с аргументами — прежний CLI-режим.
     *
     * @param args аргументы командной строки
     */
    public static void main(String[] args) {
        if (args.length == 0 && !java.awt.GraphicsEnvironment.isHeadless()) {
            com.mcmigrator.gui.MigratorGui.launch(null);
            return;
        }
        // «Открыть с помощью»: единственный аргумент-джарник → GUI с предзагрузкой.
        if (args.length == 1 && args[0].toLowerCase(Locale.ROOT).endsWith(".jar")
                && Files.isRegularFile(Path.of(args[0]))
                && !java.awt.GraphicsEnvironment.isHeadless()) {
            com.mcmigrator.gui.MigratorGui.launch(Path.of(args[0]));
            return;
        }
        int exitCode = new CommandLine(new Main())
                .setCaseInsensitiveEnumValuesAllowed(true)
                .execute(args);
        System.exit(exitCode);
    }

    /**
     * Выполняет миграцию по разобранным аргументам.
     *
     * @return код возврата процесса: 0 — успех, 1 — ошибка миграции, 2 — ошибка аргументов
     */
    @Override
    public Integer call() {
        if (verbose) {
            ((ch.qos.logback.classic.Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME))
                    .setLevel(Level.DEBUG);
        }

        log.info("{} v{}", Constants.TOOL_NAME, Constants.TOOL_VERSION);

        if (batch ? !Files.isDirectory(input) : !Files.isRegularFile(input)) {
            log.error("Вход не найден ({}): {}", batch ? "папка" : "файл", input);
            return 2;
        }

        try {
            log.info("Input:  {}{}", input.getFileName(),
                    batch ? " (папка)" : " (" + Files.size(input) / 1024 + " KB)");
        } catch (IOException e) {
            log.info("Input:  {}", input.getFileName());
        }
        log.info("Migration: {} → {} ({})", fromVersion, toVersion,
                type.name().toLowerCase(Locale.ROOT));

        Path mappings = mappingsDir != null
                ? mappingsDir
                : Path.of(System.getProperty("user.home")).resolve(Constants.DEFAULT_MAPPINGS_DIR);

        MigrationConfig config = new MigrationConfig(
                input, output, fromVersion, toVersion, type,
                keepSources, dryRun, mappings, classpath, autoClasspath,
                disabledRules, decompilerType, !noDecompileCache, parallelDecompile);

        if (interactive) {
            try {
                com.mcmigrator.rules.VersionRuleSet ruleSet =
                        com.mcmigrator.rules.VersionRuleSet.load(fromVersion, toVersion);
                var rules = new java.util.ArrayList<>(ruleSet.toRules());
                List<String> interactiveDisabled =
                        com.mcmigrator.rules.InteractiveRuleSelector.selectDisabledRules(rules);
                if (!interactiveDisabled.isEmpty()) {
                    var allDisabled = new java.util.ArrayList<>(disabledRules);
                    allDisabled.addAll(interactiveDisabled);
                    config = new MigrationConfig(
                            input, output, fromVersion, toVersion, type,
                            keepSources, dryRun, mappings, classpath, autoClasspath,
                            allDisabled, decompilerType, !noDecompileCache, parallelDecompile);
                    log.info("Interactive mode: {} total rules disabled", allDisabled.size());
                }
            } catch (Exception e) {
                log.warn("Interactive rule selection failed: {}", e.getMessage());
            }
        }

        try {
            if (batch) {
                com.mcmigrator.pipeline.BatchMigration.run(
                        input, output, config, cascade, null);
            } else if (cascade) {
                com.mcmigrator.pipeline.CascadeMigration.run(config, null);
            } else {
                new MigrationPipeline().run(config);
            }
            return 0;
        } catch (MigrationException e) {
            log.error("{}", e.getMessage());
            log.debug("Подробности ошибки", e);
            return 1;
        }
    }
}
