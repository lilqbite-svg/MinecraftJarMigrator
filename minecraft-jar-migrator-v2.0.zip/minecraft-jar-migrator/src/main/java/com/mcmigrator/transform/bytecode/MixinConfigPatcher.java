package com.mcmigrator.transform.bytecode;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;

public final class MixinConfigPatcher implements BytecodeTransformRule {

    private final String targetMcVersion;

    public MixinConfigPatcher(String targetMcVersion) {
        this.targetMcVersion = targetMcVersion;
    }

    @Override
    public String description() {
        return "Mixin config compatibility level update";
    }

    @Override
    public byte[] apply(String entryName, byte[] data) {
        if (!entryName.endsWith(".mixins.json")) {
            return data;
        }
        try {
            JsonObject json = JsonParser
                    .parseString(new String(data, StandardCharsets.UTF_8))
                    .getAsJsonObject();
            String level = requiredLevel();
            if (level == null) {
                return data;
            }
            String current = json.has("compatibilityLevel")
                    ? json.get("compatibilityLevel").getAsString() : "";
            if (level.equals(current)) {
                return data;
            }
            json.addProperty("compatibilityLevel", level);
            return new GsonBuilder().setPrettyPrinting().create()
                    .toJson(json).getBytes(StandardCharsets.UTF_8);
        } catch (RuntimeException e) {
            return data;
        }
    }

    private String requiredLevel() {
        try {
            String[] parts = targetMcVersion.split("\\.");
            int major = Integer.parseInt(parts[0]);
            int minor = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            int patch = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            if (major >= 26) {
                return "JAVA_26";
            }
            if (major >= 26 || minor > 20 || (minor == 20 && patch >= 5)) {
                return "JAVA_21";
            }
            if (minor >= 17) {
                return "JAVA_17";
            }
            return null;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
