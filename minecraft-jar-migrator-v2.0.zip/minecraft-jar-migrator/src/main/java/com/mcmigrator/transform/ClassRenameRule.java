package com.mcmigrator.transform;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.type.ClassOrInterfaceType;

/**
 * Переименовывает класс {@code oldName → newName}: правит импорты,
 * ссылки на тип (включая полностью квалифицированные) и, эвристически,
 * простые имена в выражениях (статические обращения вида {@code OldName.FOO}).
 */
public final class ClassRenameRule implements TransformRule {

    private final String oldFqn;
    private final String newFqn;
    private final String oldSimple;
    private final String newSimple;
    private final String oldPackage;

    /**
     * @param oldName старое полное имя класса
     * @param newName новое полное имя класса
     */
    public ClassRenameRule(String oldName, String newName) {
        this.oldFqn = oldName;
        this.newFqn = newName;
        this.oldSimple = simpleName(oldName);
        this.newSimple = simpleName(newName);
        this.oldPackage = packageName(oldName);
    }

    @Override
    public void apply(CompilationUnit unit, TransformContext ctx) {
        boolean importedOld = isImported(unit);

        // 1. Импорты.
        for (ImportDeclaration imp : unit.getImports()) {
            if (!imp.isAsterisk() && !imp.isStatic() && imp.getNameAsString().equals(oldFqn)) {
                imp.setName(StaticJavaParser.parseName(newFqn));
                ctx.markModified();
                ctx.recordTransformation(this,
                        ctx.fileName() + " — import " + oldFqn + " → " + newFqn);
            }
        }

        // 2. Ссылки на тип.
        for (ClassOrInterfaceType type : unit.findAll(ClassOrInterfaceType.class)) {
            String withScope = type.getNameWithScope();
            if (withScope.equals(oldFqn)) {
                ClassOrInterfaceType replacement = StaticJavaParser.parseClassOrInterfaceType(newFqn);
                type.getTypeArguments().ifPresent(replacement::setTypeArguments);
                type.replace(replacement);
                ctx.markModified();
                ctx.recordTransformation(this, ctx.location(type) + " — " + oldFqn + " → " + newFqn);
            } else if (importedOld && type.getScope().isEmpty()
                    && type.getNameAsString().equals(oldSimple)) {
                type.setName(newSimple);
                ctx.markModified();
                ctx.recordTransformation(this,
                        ctx.location(type) + " — " + oldSimple + " → " + newSimple);
            }
        }

        // 3. Эвристика для статических обращений (OldName.CONSTANT / OldName.method()).
        if (importedOld) {
            for (NameExpr name : unit.findAll(NameExpr.class)) {
                if (name.getNameAsString().equals(oldSimple)) {
                    name.setName(newSimple);
                    ctx.markModified();
                    ctx.recordTransformation(this,
                            ctx.location(name) + " — " + oldSimple + " → " + newSimple);
                }
            }
        }
    }

    private boolean isImported(CompilationUnit unit) {
        return unit.getImports().stream().anyMatch(imp -> {
            if (imp.isStatic()) {
                return false;
            }
            if (imp.isAsterisk()) {
                return imp.getNameAsString().equals(oldPackage);
            }
            return imp.getNameAsString().equals(oldFqn);
        });
    }

    @Override
    public String description() {
        return "ClassRenameRule: '" + oldFqn + "' → '" + newFqn + "'";
    }

    private static String simpleName(String fqn) {
        int dot = fqn.lastIndexOf('.');
        return dot < 0 ? fqn : fqn.substring(dot + 1);
    }

    private static String packageName(String fqn) {
        int dot = fqn.lastIndexOf('.');
        return dot < 0 ? "" : fqn.substring(0, dot);
    }
}
