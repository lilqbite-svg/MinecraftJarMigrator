package com.mcmigrator.transform.resources;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public final class DataPackTransformer {

    private static final Logger log = LoggerFactory.getLogger(DataPackTransformer.class);

    public static byte[] transformRecipe(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;

            int fromMinor = parseMinor(fromVersion);
            int toMinor = parseMinor(toVersion);

            // 1.20.5: "nbt" field in ingredients removed, replaced by "components"
            if (fromMinor < 20 && toMinor >= 20) {
                if (json.has("type") && json.get("type").getAsString().contains("crafting")) {
                    if (json.has("ingredient") && json.toString().contains("\"nbt\"")) {
                        log.debug("Recipe has NBT ingredient — may need manual update for data components");
                    }
                }
            }

            // 1.21: smithing recipes changed structure
            if (fromMinor < 21 && toMinor >= 21) {
                if (json.has("type") && json.get("type").getAsString().contains("smithing")) {
                    log.debug("Smithing recipe format changed in 1.21 — verify structure");
                }
            }

            return changed ? json.toString().getBytes(StandardCharsets.UTF_8) : data;
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] transformTag(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;

            // Tags format hasn't fundamentally changed, but paths may need updating
            // for renamed items/blocks
            return changed ? json.toString().getBytes(StandardCharsets.UTF_8) : data;
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] transformLootTable(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;

            // 1.20.5: loot functions using NBT need updating to data components
            int toMinor = parseMinor(toVersion);
            if (toMinor >= 20) {
                String str = json.toString();
                if (str.contains("set_nbt") || str.contains("SetNbt")) {
                    log.debug("Loot table uses set_nbt — needs update to set_components for 1.20.5+");
                }
            }

            return changed ? json.toString().getBytes(StandardCharsets.UTF_8) : data;
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] transformModel(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;

            // 1.21.4: model format changes
            int toMinor = parseMinor(toVersion);
            if (toMinor >= 21) {
                // Models mostly unchanged, but check for deprecated fields
            }

            return changed ? json.toString().getBytes(StandardCharsets.UTF_8) : data;
        } catch (Exception e) {
            return data;
        }
    }

    private static int parseMinor(String v) {
        try { return Integer.parseInt(v.split("\\.")[1]); }
        catch (Exception e) { return 0; }
    }
}
