package com.mcmigrator.transform.bytecode;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public final class AccessWidenerPatcher implements BytecodeTransformRule {

    private final Map<String, String> classMappings;
    private final Map<String, String> methodMappings;
    private final Map<String, String> fieldMappings;

    public AccessWidenerPatcher(Map<String, String> classMappings,
                                Map<String, String> methodMappings,
                                Map<String, String> fieldMappings) {
        this.classMappings = classMappings;
        this.methodMappings = methodMappings;
        this.fieldMappings = fieldMappings;
    }

    @Override
    public String description() {
        return "Access Widener name remapping";
    }

    @Override
    public byte[] apply(String entryName, byte[] data) {
        if (!entryName.endsWith(".accesswidener")) {
            return data;
        }
        String content = new String(data, StandardCharsets.UTF_8);
        boolean changed = false;
        for (Map.Entry<String, String> e : classMappings.entrySet()) {
            String from = e.getKey().replace('/', '.');
            if (content.contains(from)) {
                content = content.replace(from, e.getValue().replace('/', '.'));
                changed = true;
            }
        }
        for (Map.Entry<String, String> e : methodMappings.entrySet()) {
            if (content.contains(e.getKey())) {
                content = content.replace(e.getKey(), e.getValue());
                changed = true;
            }
        }
        for (Map.Entry<String, String> e : fieldMappings.entrySet()) {
            if (content.contains(e.getKey())) {
                content = content.replace(e.getKey(), e.getValue());
                changed = true;
            }
        }
        return changed ? content.getBytes(StandardCharsets.UTF_8) : data;
    }
}
