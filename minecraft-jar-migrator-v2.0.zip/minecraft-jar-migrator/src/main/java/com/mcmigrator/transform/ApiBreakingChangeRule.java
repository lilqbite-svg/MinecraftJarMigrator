package com.mcmigrator.transform;

import com.github.javaparser.ast.CompilationUnit;

import java.util.regex.Pattern;

/**
 * Детектор сломанных API: ищет совпадения регулярного выражения в исходном
 * тексте файла и заносит их в раздел «Требует ручной правки» отчёта.
 * Код при этом <b>не модифицируется</b>.
 */
public final class ApiBreakingChangeRule implements TransformRule {

    private final String changeDescription;
    private final Pattern pattern;
    private final String suggestedFix;

    /**
     * @param description  описание изменения API
     * @param matchPattern регулярное выражение для поиска проблемных мест
     * @param suggestedFix рекомендация по исправлению
     */
    public ApiBreakingChangeRule(String description, String matchPattern, String suggestedFix) {
        this.changeDescription = description;
        this.pattern = Pattern.compile(matchPattern);
        this.suggestedFix = suggestedFix;
    }

    @Override
    public void apply(CompilationUnit unit, TransformContext ctx) {
        String[] lines = ctx.originalSource().split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            if (pattern.matcher(lines[i]).find()) {
                ctx.recordManualFix(this, ctx.fileName() + ":" + (i + 1)
                        + " — " + changeDescription + ". Fix: " + suggestedFix);
            }
        }
    }

    @Override
    public String description() {
        return "ApiBreakingChangeRule: " + changeDescription;
    }

    public String suggestedFix() {
        return suggestedFix;
    }

    @Override
    public String summarize(int hits) {
        return "ApiBreakingChangeRule: " + hits + " usage(s) matched '" + pattern.pattern()
                + "' — требует ручной правки (см. отчёт)";
    }
}
