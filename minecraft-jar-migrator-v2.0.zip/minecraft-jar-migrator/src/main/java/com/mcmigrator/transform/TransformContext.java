package com.mcmigrator.transform;

import com.github.javaparser.ast.Node;
import com.mcmigrator.report.MigrationReport;

import java.nio.file.Path;
import java.util.Map;

/**
 * Контекст трансформации одного {@code .java} файла: исходный текст,
 * накопители отчёта и общий счётчик срабатываний правил.
 */
public final class TransformContext {

    private final Path file;
    private final String originalSource;
    private final MigrationReport report;
    private final Map<String, Integer> hits;
    private boolean modified;

    /**
     * @param file           путь к обрабатываемому файлу
     * @param originalSource исходный текст файла до трансформаций
     * @param report         накопитель отчёта миграции
     * @param hits           общий (на весь этап) счётчик срабатываний по описаниям правил
     */
    public TransformContext(Path file, String originalSource,
                            MigrationReport report, Map<String, Integer> hits) {
        this.file = file;
        this.originalSource = originalSource;
        this.report = report;
        this.hits = hits;
    }

    /** @return имя обрабатываемого файла */
    public String fileName() {
        return file.getFileName().toString();
    }

    /** @return исходный текст файла до трансформаций */
    public String originalSource() {
        return originalSource;
    }

    /** @return накопитель отчёта миграции */
    public MigrationReport report() {
        return report;
    }

    /** @return {@code true}, если файл был изменён хотя бы одним правилом */
    public boolean modified() {
        return modified;
    }

    /** Помечает файл как изменённый. */
    public void markModified() {
        modified = true;
    }

    /**
     * Фиксирует срабатывание автоматической трансформации:
     * инкрементирует счётчик правила и добавляет запись в отчёт.
     *
     * @param rule   сработавшее правило
     * @param detail деталь для отчёта (файл, строка, что заменено)
     */
    public void recordTransformation(TransformRule rule, String detail) {
        hits.merge(rule.description(), 1, Integer::sum);
        report.addTransformation(detail);
    }

    /**
     * Фиксирует место, требующее ручной правки: инкрементирует счётчик
     * правила и добавляет запись в раздел ручных правок отчёта.
     *
     * @param rule   сработавшее правило
     * @param detail деталь для отчёта (файл, строка, рекомендация)
     */
    public void recordManualFix(TransformRule rule, String detail) {
        hits.merge(rule.description(), 1, Integer::sum);
        report.addManualFix(detail);
    }

    /**
     * @param node узел AST
     * @return позиция вида {@code "File.java:42"} (или {@code "File.java:?"})
     */
    public String location(Node node) {
        return fileName() + ":" + node.getRange().map(r -> String.valueOf(r.begin.line)).orElse("?");
    }
}
