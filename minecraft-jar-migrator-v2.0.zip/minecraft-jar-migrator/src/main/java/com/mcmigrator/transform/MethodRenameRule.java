package com.mcmigrator.transform;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.MethodCallExpr;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Переименовывает вызовы метода {@code oldMethod → newMethod}.
 *
 * <p>Где возможно, через symbol solver проверяется, что метод объявлен именно
 * в {@code className}. Если тип разрешить не удалось (декомпилированный код,
 * неполный classpath) — правило применяется с пометкой в отчёте, а вызовы
 * с подтверждённо другим типом пропускаются.</p>
 */
public final class MethodRenameRule implements TransformRule {

    private static final Logger log = LoggerFactory.getLogger(MethodRenameRule.class);

    private final String className;
    private final String oldMethod;
    private final String newMethod;
    private final String comment;

    /**
     * @param className FQN класса, в котором объявлен метод
     * @param oldMethod старое имя метода
     * @param newMethod новое имя метода
     * @param comment   пояснение из набора правил (может быть {@code null})
     */
    public MethodRenameRule(String className, String oldMethod, String newMethod, String comment) {
        this.className = className;
        this.oldMethod = oldMethod;
        this.newMethod = newMethod;
        this.comment = comment;
    }

    @Override
    public void apply(CompilationUnit unit, TransformContext ctx) {
        for (MethodCallExpr call : unit.findAll(MethodCallExpr.class)) {
            if (!call.getNameAsString().equals(oldMethod)) {
                continue;
            }
            TypeCheck check = verifyDeclaringType(call);
            if (check == TypeCheck.MISMATCH) {
                log.debug("Пропуск {}: '{}' объявлен в другом типе", ctx.location(call), oldMethod);
                continue;
            }
            String where = ctx.location(call);
            call.setName(newMethod);
            ctx.markModified();
            String note = check == TypeCheck.UNVERIFIED ? " [тип не подтверждён]" : "";
            ctx.recordTransformation(this, where + " — " + oldMethod + "() → " + newMethod + "()"
                    + note + (comment != null ? " (" + comment + ")" : ""));
        }
    }

    private TypeCheck verifyDeclaringType(MethodCallExpr call) {
        try {
            String declaring = call.resolve().declaringType().getQualifiedName();
            return declaring.equals(className) ? TypeCheck.MATCH : TypeCheck.MISMATCH;
        } catch (RuntimeException e) {
            // Symbol solver не справился — работаем по имени метода (best effort).
            return TypeCheck.UNVERIFIED;
        }
    }

    @Override
    public String description() {
        return "MethodRenameRule: '" + oldMethod + "' → '" + newMethod + "'";
    }

    private enum TypeCheck { MATCH, MISMATCH, UNVERIFIED }
}
