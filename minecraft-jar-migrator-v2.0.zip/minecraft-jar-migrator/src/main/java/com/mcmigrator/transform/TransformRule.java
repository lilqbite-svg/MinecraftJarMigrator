package com.mcmigrator.transform;

import com.github.javaparser.ast.CompilationUnit;

/** Одно правило трансформации исходного кода для пары версий. */
public interface TransformRule {

    /**
     * Применяет правило к единице компиляции. Изменения вносятся в само
     * AST-дерево; факт изменения и детали фиксируются через {@code ctx}.
     *
     * @param unit разобранный исходный файл
     * @param ctx  контекст трансформации текущего файла
     */
    void apply(CompilationUnit unit, TransformContext ctx);

    /** @return краткое описание правила для логов и отчёта */
    String description();

    /**
     * @param hits число срабатываний правила
     * @return строка-сводка для лога, например {@code "... applied 7 time(s)"}
     */
    default String summarize(int hits) {
        return description() + " applied " + hits + " time(s)";
    }
}
