package com.mcmigrator.transform;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.MemberValuePair;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public final class ArchitecturyRule implements TransformRule {

    private static final Logger log = LoggerFactory.getLogger(ArchitecturyRule.class);

    private final String fromVersion;
    private final String toVersion;

    public ArchitecturyRule(String fromVersion, String toVersion) {
        this.fromVersion = fromVersion;
        this.toVersion = toVersion;
    }

    @Override
    public void apply(CompilationUnit unit, TransformContext ctx) {
        unit.findAll(AnnotationExpr.class).forEach(ann -> {
            String name = ann.getNameAsString();

            if (name.equals("ExpectPlatform")) {
                ctx.recordManualFix(this, ctx.fileName()
                        + ": @ExpectPlatform — verify platform implementations exist for "
                        + toVersion);
            }

            if (name.equals("PlatformOnly")) {
                ann.findAll(StringLiteralExpr.class).forEach(literal -> {
                    String value = literal.getValue();
                    if (value.contains("fabric") || value.contains("forge")) {
                        ctx.recordManualFix(this, ctx.fileName()
                                + ": @PlatformOnly(\"" + value
                                + "\") — verify loader compatibility for " + toVersion);
                    }
                });
            }
        });

        unit.findAll(MemberValuePair.class).forEach(pair -> {
            if (pair.getNameAsString().equals("modId")) {
                // Mod ID references are fine — no action needed
            }
        });
    }

    @Override
    public String description() {
        return "Architectury cross-platform compatibility check";
    }

    @Override
    public String summarize(int hits) {
        return "Architectury: " + hits + " platform-specific reference(s) checked";
    }
}
