package com.mcmigrator.transform.bytecode;

public interface BytecodeTransformRule {
    String description();
    byte[] apply(String entryName, byte[] data) throws Exception;
}
