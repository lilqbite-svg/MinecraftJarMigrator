package com.mcmigrator.transform.bytecode;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public final class RefmapPatcher implements BytecodeTransformRule {

    private final Map<String, String> classMappings;
    private final Map<String, String> methodMappings;
    private final Map<String, String> fieldMappings;

    public RefmapPatcher(Map<String, String> classMappings,
                         Map<String, String> methodMappings,
                         Map<String, String> fieldMappings) {
        this.classMappings = classMappings;
        this.methodMappings = methodMappings;
        this.fieldMappings = fieldMappings;
    }

    @Override
    public String description() {
        return "Refmap intermediary->MojMap remapping";
    }

    @Override
    public byte[] apply(String entryName, byte[] data) {
        if (!entryName.endsWith("-refmap.json") && !entryName.endsWith("refmap.json")) {
            return data;
        }
        String json = new String(data, StandardCharsets.UTF_8);
        boolean changed = false;
        for (Map.Entry<String, String> e : classMappings.entrySet()) {
            if (json.contains(e.getKey())) {
                json = json.replace(e.getKey(), e.getValue());
                changed = true;
            }
        }
        for (Map.Entry<String, String> e : methodMappings.entrySet()) {
            if (json.contains(e.getKey())) {
                json = json.replace(e.getKey(), e.getValue());
                changed = true;
            }
        }
        for (Map.Entry<String, String> e : fieldMappings.entrySet()) {
            if (json.contains(e.getKey())) {
                json = json.replace(e.getKey(), e.getValue());
                changed = true;
            }
        }
        return changed ? json.getBytes(StandardCharsets.UTF_8) : data;
    }
}
