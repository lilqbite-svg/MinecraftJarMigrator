package com.mcmigrator.transform;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;

/**
 * Обновляет импорты при переносе пакета: любой импорт, начинающийся
 * с {@code oldPackage}, получает префикс {@code newPackage}.
 */
public final class PackageChangeRule implements TransformRule {

    private final String oldPackage;
    private final String newPackage;

    /**
     * @param oldPackage старый пакет (или полное имя класса — тогда заменяется точечно)
     * @param newPackage новый пакет (или полное имя класса)
     */
    public PackageChangeRule(String oldPackage, String newPackage) {
        this.oldPackage = oldPackage;
        this.newPackage = newPackage;
    }

    @Override
    public void apply(CompilationUnit unit, TransformContext ctx) {
        for (ImportDeclaration imp : unit.getImports()) {
            String name = imp.getNameAsString();
            String updated = null;
            if (name.equals(oldPackage)) {
                updated = newPackage;
            } else if (name.startsWith(oldPackage + ".")) {
                updated = newPackage + name.substring(oldPackage.length());
            }
            if (updated != null) {
                imp.setName(StaticJavaParser.parseName(updated));
                ctx.markModified();
                ctx.recordTransformation(this,
                        ctx.fileName() + " — import " + name + " → " + updated);
            }
        }
    }

    @Override
    public String description() {
        return "PackageChangeRule: '" + oldPackage + "' → '" + newPackage + "'";
    }
}
