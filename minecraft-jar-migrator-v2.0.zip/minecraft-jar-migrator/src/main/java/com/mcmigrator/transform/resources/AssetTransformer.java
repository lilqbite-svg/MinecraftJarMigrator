package com.mcmigrator.transform.resources;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;

public final class AssetTransformer {

    private static final Logger log = LoggerFactory.getLogger(AssetTransformer.class);

    public static byte[] transformSoundsJson(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;
            int toMinor = parseMinor(toVersion);

            // 1.20.3+: sounds.json format changes
            if (toMinor >= 20) {
                for (String key : json.keySet()) {
                    JsonObject sound = json.getAsJsonObject(key);
                    if (sound != null && sound.has("sounds")) {
                        // sound entries format is stable, but verify
                    }
                }
            }
            return changed ? json.toString().getBytes(StandardCharsets.UTF_8) : data;
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] transformBlockModel(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean changed = false;
            int toMinor = parseMinor(toVersion);

            // 1.21.4: model format changes for some blocks
            if (toMinor >= 21) {
                if (json.has("elements") && json.toString().contains("\"shade\":false")) {
                    // Model shade handling changed slightly
                }
            }
            return changed ? json.toString().getBytes(StandardCharsets.UTF_8) : data;
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] transformAtlas(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            // Atlas format is relatively stable
            return data;
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] transformFont(byte[] data, String fromVersion, String toVersion) {
        try {
            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            // Font provider format is stable
            return data;
        } catch (Exception e) {
            return data;
        }
    }

    private static int parseMinor(String v) {
        try { return Integer.parseInt(v.split("\\.")[1]); }
        catch (Exception e) { return 0; }
    }
}
