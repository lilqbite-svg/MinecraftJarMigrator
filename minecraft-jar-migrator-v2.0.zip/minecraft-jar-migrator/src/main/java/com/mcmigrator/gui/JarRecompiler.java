package com.mcmigrator.gui;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Перекомпиляция отредактированных в просмотрщике {@code .java} обратно в jar
 * (для встроенного редактора кода). Компилирует исходники из папки в классы
 * во временный каталог, затем заменяет соответствующие {@code .class}-записи
 * в целевом jar. Всё на системном {@link JavaCompiler} — без внешних утилит.
 *
 * <p>Это намеренно отдельный от пайплайна путь: пользователь правит уже
 * собранный результат миграции «вручную» и пересобирает только его.</p>
 */
public final class JarRecompiler {

    private static final Logger log = LoggerFactory.getLogger(JarRecompiler.class);

    /** Результат перекомпиляции: успех/ошибки + текст диагностики для показа. */
    public record Result(boolean success, int compiledClasses, String diagnostics) {
    }

    private JarRecompiler() {
    }

    /**
     * Компилирует исходники и обновляет ими jar на месте.
     *
     * @param sourcesDir папка с {@code .java} (всё дерево исходников)
     * @param targetJar  jar, в котором заменяются {@code .class} (правится на месте)
     * @param classpath  classpath для компиляции (Minecraft + библиотеки)
     * @param release    целевой {@code --release} (например, "21")
     * @return результат с диагностикой
     */
    public static Result recompile(Path sourcesDir, Path targetJar,
                                   List<Path> classpath, String release) {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            return new Result(false, 0,
                    "Системный компилятор недоступен — запустите инструмент на JDK, не на JRE.");
        }

        List<Path> javaFiles;
        try (Stream<Path> walk = Files.walk(sourcesDir)) {
            javaFiles = walk.filter(p -> p.toString().endsWith(".java"))
                    .filter(Files::isRegularFile).toList();
        } catch (IOException e) {
            return new Result(false, 0, "Не удалось обойти исходники: " + e.getMessage());
        }
        if (javaFiles.isEmpty()) {
            return new Result(false, 0, "В папке исходников нет .java файлов.");
        }

        Path classesOut;
        try {
            classesOut = Files.createTempDirectory("mcmig-recompile-");
        } catch (IOException e) {
            return new Result(false, 0, "Не создан временный каталог: " + e.getMessage());
        }

        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        boolean ok;
        try (StandardJavaFileManager fm =
                     compiler.getStandardFileManager(diagnostics, null, StandardCharsets.UTF_8)) {
            List<java.io.File> cp = new ArrayList<>();
            cp.add(targetJar.toFile()); // сам jar — чтобы классы видели соседей
            classpath.forEach(p -> cp.add(p.toFile()));
            fm.setLocation(StandardLocation.CLASS_PATH, cp);
            fm.setLocation(StandardLocation.CLASS_OUTPUT, List.of(classesOut.toFile()));

            Iterable<? extends JavaFileObject> units =
                    fm.getJavaFileObjectsFromPaths(javaFiles);
            List<String> options = List.of("--release", release, "-proc:none", "-nowarn");
            ok = compiler.getTask(null, fm, diagnostics, options, null, units).call();
        } catch (IOException e) {
            cleanup(classesOut);
            return new Result(false, 0, "Ошибка компилятора: " + e.getMessage());
        }

        String diagText = formatDiagnostics(diagnostics);
        if (!ok) {
            cleanup(classesOut);
            return new Result(false, 0, diagText.isEmpty()
                    ? "Компиляция не удалась (без подробностей)." : diagText);
        }

        int injected;
        try {
            injected = injectClasses(classesOut, targetJar);
        } catch (IOException e) {
            cleanup(classesOut);
            return new Result(false, 0, "Классы скомпилированы, но не записаны в jar: "
                    + e.getMessage());
        }
        cleanup(classesOut);
        log.info("Перекомпиляция: {} классов обновлено в {}", injected, targetJar.getFileName());
        return new Result(true, injected,
                diagText.isEmpty() ? "Успешно: " + injected + " классов." : diagText);
    }

    /** Заменяет/добавляет в jar все {@code .class} из каталога классов. */
    private static int injectClasses(Path classesDir, Path jar) throws IOException {
        List<Path> classFiles;
        try (Stream<Path> walk = Files.walk(classesDir)) {
            classFiles = walk.filter(p -> p.toString().endsWith(".class"))
                    .filter(Files::isRegularFile).toList();
        }
        java.util.Map<String, Path> byEntry = new java.util.HashMap<>();
        for (Path c : classFiles) {
            byEntry.put(classesDir.relativize(c).toString().replace('\\', '/'), c);
        }

        Path tmpJar = jar.resolveSibling(jar.getFileName() + ".recompile.tmp");
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(jar));
             ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(tmpJar))) {
            ZipEntry entry;
            java.util.Set<String> seen = new java.util.HashSet<>();
            while ((entry = in.getNextEntry()) != null) {
                String name = entry.getName();
                if (entry.isDirectory()) {
                    continue;
                }
                out.putNextEntry(new ZipEntry(name));
                if (byEntry.containsKey(name)) {
                    out.write(Files.readAllBytes(byEntry.get(name))); // заменяем
                } else {
                    out.write(in.readAllBytes()); // сохраняем как было
                }
                out.closeEntry();
                seen.add(name);
            }
            // Новые классы, которых не было в jar (например, новый вложенный класс).
            for (var e : byEntry.entrySet()) {
                if (!seen.contains(e.getKey())) {
                    out.putNextEntry(new ZipEntry(e.getKey()));
                    out.write(Files.readAllBytes(e.getValue()));
                    out.closeEntry();
                }
            }
        }
        Files.move(tmpJar, jar, StandardCopyOption.REPLACE_EXISTING);
        return byEntry.size();
    }

    private static String formatDiagnostics(DiagnosticCollector<JavaFileObject> collector) {
        StringBuilder sb = new StringBuilder();
        for (Diagnostic<? extends JavaFileObject> d : collector.getDiagnostics()) {
            if (d.getKind() == Diagnostic.Kind.ERROR) {
                String src = d.getSource() != null
                        ? Path.of(d.getSource().getName()).getFileName().toString() : "?";
                sb.append(src).append(':').append(d.getLineNumber())
                        .append(": ").append(d.getMessage(Locale.getDefault()))
                        .append('\n');
            }
        }
        return sb.toString().trim();
    }

    private static void cleanup(Path dir) {
        if (dir == null || !Files.exists(dir)) {
            return;
        }
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // best effort
                }
            });
        } catch (IOException ignored) {
            // best effort
        }
    }
}
