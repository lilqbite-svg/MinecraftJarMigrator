package com.mcmigrator.gui;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.AppenderBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

/**
 * Logback-аппендер, перенаправляющий логи пайплайна в GUI
 * (строки в формате {@code [LEVEL] message}).
 */
public final class SwingLogAppender extends AppenderBase<ILoggingEvent> {

    private final Consumer<String> sink;

    private SwingLogAppender(Consumer<String> sink) {
        this.sink = sink;
    }

    /**
     * Создаёт аппендер, подключает его к root-логгеру и запускает.
     *
     * @param sink приёмник готовых строк лога (вызывается из логирующего потока!)
     * @return созданный аппендер (для последующего detach при необходимости)
     */
    public static SwingLogAppender attach(Consumer<String> sink) {
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        SwingLogAppender appender = new SwingLogAppender(sink);
        appender.setContext(context);
        appender.setName("gui");
        appender.start();
        context.getLogger(Logger.ROOT_LOGGER_NAME).addAppender(appender);
        return appender;
    }

    @Override
    protected void append(ILoggingEvent event) {
        StringBuilder line = new StringBuilder("[").append(event.getLevel()).append("] ")
                .append(event.getFormattedMessage());
        IThrowableProxy t = event.getThrowableProxy();
        if (t != null) {
            line.append(System.lineSeparator()).append(ThrowableProxyUtil.asString(t));
        }
        sink.accept(line.toString());
    }
}
