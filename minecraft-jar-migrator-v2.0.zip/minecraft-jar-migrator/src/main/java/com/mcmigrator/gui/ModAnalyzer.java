package com.mcmigrator.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mcmigrator.ModType;
import com.mcmigrator.analysis.LibraryCatalog;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Быстрый анализатор jar мода/плагина: определяет загрузчик, версию
 * Minecraft и метаданные (имя, id, версия, авторы, лицензия, описание)
 * по дескрипторам fabric.mod.json / mods.toml / plugin.yml.
 *
 * <p>Читаются только нужные записи архива — анализ больших jar
 * остаётся быстрым и экономным по памяти.</p>
 */
public final class ModAnalyzer {

    /**
     * Ищет версию Minecraft только по явному маркеру {@code mc} / {@code minecraft}
     * в имени файла. Беспрефиксные токены вроде {@code 1.72.1} игнорируются, чтобы
     * не путать версию мода с версией игры.
     */
    private static final Pattern MC_IN_NAME =
            Pattern.compile("(?i)(?:^|[^a-z0-9])(mc|minecraft)[-_ ]?(1\\.\\d{1,2}(?:\\.\\d{1,2})?|2\\d\\.\\d(?:\\.\\d{1,2})?)");
    private static final Pattern VERSION_TOKEN =
            Pattern.compile("(1\\.\\d{1,2}(?:\\.\\d{1,2})?|2\\d\\.\\d(?:\\.\\d{1,2})?)");
    private static final Pattern TOML_KEY =
            Pattern.compile("^\\s*([A-Za-z]+)\\s*=\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
    private static final int INTERMEDIARY_SCAN_LIMIT = 300;

    private ModAnalyzer() {
    }

    /**
     * Результат анализа jar.
     *
     * @param name         отображаемое имя мода
     * @param id           идентификатор мода
     * @param version      версия мода
     * @param mcVersion    версия Minecraft (нормализованная, может быть {@code null})
     * @param loader       тип загрузчика для конфигурации миграции
     * @param loaderName   человекочитаемое имя загрузчика
     * @param authors      авторы (через запятую)
     * @param license      лицензия
     * @param description  описание
     * @param intermediary собран ли мод в intermediary-именах (production Fabric)
     */
    public record ModInfo(
            String name,
            String id,
            String version,
            String mcVersion,
            ModType loader,
            String loaderName,
            String authors,
            String license,
            String description,
            boolean intermediary,
            List<LibraryCatalog.LibraryMatch> libraries) {
    }

    /**
     * Анализирует jar мода.
     *
     * @param jarPath путь к jar
     * @return извлечённые метаданные (поля могут быть {@code null})
     * @throws IOException если архив не читается
     */
    public static ModInfo analyze(Path jarPath) throws IOException {
        try (JarFile jar = new JarFile(jarPath.toFile())) {
            ModInfo info = tryFabric(jar);
            if (info == null) {
                info = tryQuilt(jar);
            }
            if (info == null) {
                info = tryForge(jar);
            }
            if (info == null) {
                info = tryPlugin(jar);
            }
            if (info == null) {
                info = new ModInfo(null, null, null, null, null,
                        "не определён", null, null, null, false, List.of());
            }
            // Версия MC: добиваем из имени файла, если дескриптор не дал точной.
            String mc = info.mcVersion();
            if (mc == null || !looksLikeExactVersion(mc)) {
                String fromName = mcFromFileName(jarPath.getFileName().toString());
                if (fromName != null) {
                    mc = fromName;
                }
            }
            boolean intermediary =
                    info.loader() == ModType.FABRIC && scanIntermediary(jar);
            List<LibraryCatalog.LibraryMatch> libraries = detectLibraries(jar);
            return new ModInfo(info.name(), info.id(), info.version(), mc,
                    info.loader(), info.loaderName(), info.authors(), info.license(),
                    info.description(), intermediary, libraries);
        }
    }

    /* ------------------------------ Fabric ------------------------------ */

    private static ModInfo tryFabric(JarFile jar) throws IOException {
        String text = readEntry(jar, "fabric.mod.json");
        if (text == null) {
            return null;
        }
        return fromFabricLikeJson(text, ModType.FABRIC, "Fabric");
    }

    private static ModInfo tryQuilt(JarFile jar) throws IOException {
        String text = readEntry(jar, "quilt.mod.json");
        if (text == null) {
            return null;
        }
        try {
            JsonObject root = JsonParser.parseString(text).getAsJsonObject();
            JsonObject ql = root.getAsJsonObject("quilt_loader");
            if (ql == null) {
                return null;
            }
            JsonObject meta = ql.has("metadata") ? ql.getAsJsonObject("metadata") : new JsonObject();
            return new ModInfo(
                    str(meta, "name"),
                    str(ql, "id"),
                    str(ql, "version"),
                    null,
                    ModType.QUILT,
                    "Quilt",
                    jsonToFlat(meta.get("contributors")),
                    jsonToFlat(meta.get("license")),
                    str(meta, "description"),
                    false, List.of());
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static ModInfo fromFabricLikeJson(String text, ModType type, String loaderName) {
        try {
            JsonObject json = JsonParser.parseString(text).getAsJsonObject();
            String mc = null;
            if (json.has("depends")) {
                JsonElement dep = json.getAsJsonObject("depends").get("minecraft");
                mc = normalizeConstraint(jsonToFlat(dep));
            }
            return new ModInfo(
                    str(json, "name"),
                    str(json, "id"),
                    str(json, "version"),
                    mc,
                    type,
                    loaderName,
                    jsonToFlat(json.get("authors")),
                    jsonToFlat(json.get("license")),
                    str(json, "description"),
                    false, List.of());
        } catch (RuntimeException e) {
            return null;
        }
    }

    /* ---------------------------- Forge/NeoForge ---------------------------- */

    private static ModInfo tryForge(JarFile jar) throws IOException {
        String toml = readEntry(jar, "META-INF/neoforge.mods.toml");
        String loaderName = "NeoForge";
        ModType modType = ModType.NEOFORGE;
        if (toml == null) {
            toml = readEntry(jar, "META-INF/mods.toml");
            loaderName = "Forge";
            modType = ModType.FORGE;
        }
        if (toml == null) {
            return null;
        }
        String name = null;
        String id = null;
        String version = null;
        String authors = null;
        String license = null;
        String description = null;
        String mc = null;
        boolean inMinecraftDep = false;
        for (String raw : toml.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("#")) {
                continue;
            }
            if (line.startsWith("[[dependencies")) {
                inMinecraftDep = false;
            }
            Matcher m = TOML_KEY.matcher(line);
            if (!m.find()) {
                // многострочное описание (''' ... ''') пропускаем целиком
                continue;
            }
            String key = m.group(1);
            String value = m.group(2).replace("\\\"", "\"");
            switch (key) {
                case "modId" -> {
                    if (id == null) {
                        id = value;
                    } else if (inMinecraftDep || "minecraft".equals(value)) {
                        inMinecraftDep = "minecraft".equals(value);
                    }
                    inMinecraftDep = inMinecraftDep || "minecraft".equals(value);
                }
                case "displayName" -> name = name == null ? value : name;
                case "version" -> {
                    if (version == null && !value.contains("${")) {
                        version = value;
                    }
                }
                case "authors" -> authors = authors == null ? value : authors;
                case "license" -> license = license == null ? value : license;
                case "description" -> description = description == null ? value : description;
                case "versionRange" -> {
                    if (inMinecraftDep && mc == null) {
                        Matcher vm = VERSION_TOKEN.matcher(value);
                        if (vm.find()) {
                            mc = vm.group(1);
                        }
                    }
                }
                default -> { /* остальные ключи не нужны */ }
            }
        }
        if (version == null) {
            version = manifestValue(jar, "Implementation-Version");
        }
        return new ModInfo(name, id, version, mc, modType, loaderName,
                authors, license, description, false, List.of());
    }

    /* ---------------------------- Paper/Spigot ---------------------------- */

    private static ModInfo tryPlugin(JarFile jar) throws IOException {
        String yml = readEntry(jar, "paper-plugin.yml");
        String loaderName = "Paper";
        ModType type = ModType.PAPER;
        if (yml == null) {
            yml = readEntry(jar, "plugin.yml");
            loaderName = "Paper/Spigot";
        }
        if (yml == null) {
            return null;
        }
        String name = yamlValue(yml, "name");
        String version = yamlValue(yml, "version");
        String api = yamlValue(yml, "api-version");
        String author = yamlValue(yml, "author");
        if (author == null) {
            author = yamlValue(yml, "authors");
        }
        String description = yamlValue(yml, "description");
        return new ModInfo(name, name != null ? name.toLowerCase() : null, version,
                normalizeConstraint(api), type, loaderName, author, null, description, false, List.of());
    }


    /** Выявляет известные библиотеки/фреймворки по метаданным jar. */
    private static List<LibraryCatalog.LibraryMatch> detectLibraries(JarFile jar) {
        try {
            return LibraryCatalog.detect(jar);
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    /* ------------------------------ Утилиты ------------------------------ */

    private static String readEntry(JarFile jar, String entryName) throws IOException {
        JarEntry entry = jar.getJarEntry(entryName);
        if (entry == null) {
            return null;
        }
        try (InputStream in = jar.getInputStream(entry)) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static String manifestValue(JarFile jar, String key) throws IOException {
        var manifest = jar.getManifest();
        return manifest == null ? null : manifest.getMainAttributes().getValue(key);
    }

    private static String str(JsonObject obj, String key) {
        JsonElement el = obj.get(key);
        return el != null && el.isJsonPrimitive() ? el.getAsString() : null;
    }

    /** Массив/объект/строку JSON → плоская строка через запятую. */
    private static String jsonToFlat(JsonElement el) {
        if (el == null) {
            return null;
        }
        if (el.isJsonPrimitive()) {
            return el.getAsString();
        }
        if (el.isJsonArray()) {
            List<String> parts = new ArrayList<>();
            for (JsonElement item : (JsonArray) el) {
                String flat = jsonToFlat(item);
                if (flat != null) {
                    parts.add(flat);
                }
            }
            return parts.isEmpty() ? null : String.join(", ", parts);
        }
        if (el.isJsonObject()) {
            JsonObject obj = el.getAsJsonObject();
            if (obj.has("name")) {
                return str(obj, "name");
            }
            // quilt contributors: {"Имя": "роль"}
            List<String> keys = new ArrayList<>(obj.keySet());
            return keys.isEmpty() ? null : String.join(", ", keys);
        }
        return null;
    }

    /** Убирает операторы из ограничения версии: {@code ">=1.21.1"} → {@code "1.21.1"}. */
    private static String normalizeConstraint(String constraint) {
        if (constraint == null) {
            return null;
        }
        Matcher m = VERSION_TOKEN.matcher(constraint);
        String last = null;
        while (m.find()) {
            last = m.group(1);
        }
        return last != null ? last : constraint.trim();
    }

    private static boolean looksLikeExactVersion(String v) {
        return v != null && v.matches("\\d+\\.\\d+\\.\\d+");
    }

    private static String mcFromFileName(String fileName) {
        Matcher m = MC_IN_NAME.matcher(fileName);
        String best = null;
        while (m.find()) {
            String candidate = m.group(2);
            if (candidate != null && (best == null || candidate.length() > best.length())) {
                best = candidate;
            }
        }
        return best;
    }

    /** Лёгкий YAML-парсер: значение ключа верхнего уровня. */
    private static String yamlValue(String yml, String key) {
        for (String raw : yml.split("\n")) {
            if (raw.startsWith(key + ":")) {
                String value = raw.substring(key.length() + 1).trim();
                if (value.startsWith("\"") && value.endsWith("\"") && value.length() > 1) {
                    value = value.substring(1, value.length() - 1);
                } else if (value.startsWith("'") && value.endsWith("'") && value.length() > 1) {
                    value = value.substring(1, value.length() - 1);
                }
                return value.isEmpty() ? null : value;
            }
        }
        return null;
    }

    /** Ограниченный скан байткода на intermediary-имена (быстро даже на больших jar). */
    private static boolean scanIntermediary(JarFile jar) {
        byte[] needle = "net/minecraft/class_".getBytes(StandardCharsets.US_ASCII);
        int scanned = 0;
        Enumeration<JarEntry> entries = jar.entries();
        while (entries.hasMoreElements() && scanned < INTERMEDIARY_SCAN_LIMIT) {
            JarEntry e = entries.nextElement();
            if (!e.getName().endsWith(".class")) {
                continue;
            }
            scanned++;
            try (InputStream in = jar.getInputStream(e)) {
                if (contains(in.readAllBytes(), needle)) {
                    return true;
                }
            } catch (IOException ex) {
                return false;
            }
        }
        return false;
    }

    private static boolean contains(byte[] haystack, byte[] needle) {
        outer:
        for (int i = 0; i <= haystack.length - needle.length; i++) {
            for (int j = 0; j < needle.length; j++) {
                if (haystack[i + j] != needle[j]) {
                    continue outer;
                }
            }
            return true;
        }
        return false;
    }
}
