package com.mcmigrator.gui;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SwingWorker;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Отдельное окно «Просмотр кода» (встроенный аналог JD-GUI, без внешних
 * зависимостей). Слева — дерево декомпилированных классов текущей миграции,
 * справа — редактор с подсветкой ({@link SourceEditorPanel}). Поддерживает
 * поиск по дереву, правку {@code .java} и перекомпиляцию обратно в jar
 * через {@link JarRecompiler}.
 */
public final class CodeBrowserWindow extends JFrame {

    private static final Logger log = LoggerFactory.getLogger(CodeBrowserWindow.class);

    private final Path sourcesDir;
    private final Path targetJar;
    private final List<Path> classpath;
    private final String release;

    private final JTree tree;
    private final SourceEditorPanel editor = new SourceEditorPanel();
    private final JTextField filterField = new JTextField();
    private final JLabel statusLabel = new JLabel(" ");
    private List<Path> allFiles = new ArrayList<>();

    /**
     * @param sourcesDir папка декомпилированных исходников
     * @param targetJar  собранный jar, который будет правиться при перекомпиляции
     * @param classpath  classpath для перекомпиляции
     * @param release    целевой {@code --release}
     */
    public CodeBrowserWindow(Path sourcesDir, Path targetJar,
                             List<Path> classpath, String release) {
        super("Просмотр кода — " + (targetJar != null ? targetJar.getFileName() : sourcesDir));
        this.sourcesDir = sourcesDir;
        this.targetJar = targetJar;
        this.classpath = classpath;
        this.release = release;

        this.tree = new JTree(new DefaultMutableTreeNode("classes"));
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.addTreeSelectionListener(e -> openSelected());

        setLayout(new BorderLayout());
        add(buildLeft(), BorderLayout.WEST);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        setSize(1100, 720);
        setLocationRelativeTo(null);
        reloadTree();
    }

    private JPanel buildLeft() {
        JPanel left = new JPanel(new BorderLayout(0, 4));
        JPanel top = new JPanel(new BorderLayout(4, 0));
        top.add(new JLabel("Фильтр:"), BorderLayout.WEST);
        filterField.setToolTipText("Поиск класса по имени");
        filterField.getDocument().addDocumentListener(new SimpleDocListener(this::applyFilter));
        top.add(filterField, BorderLayout.CENTER);
        left.add(top, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(tree);
        scroll.setPreferredSize(new Dimension(330, 0));
        left.add(scroll, BorderLayout.CENTER);
        return left;
    }

    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout());
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));

        JButton recompileBtn = new JButton("\uD83D\uDD28 Перекомпилировать в jar");
        recompileBtn.setToolTipText("Скомпилировать отредактированные исходники и записать "
                + "классы обратно в собранный jar");
        recompileBtn.addActionListener(e -> recompile());
        toolbar.add(recompileBtn);

        JButton findBtn = new JButton("\uD83D\uDD0D Найти в коде\u2026");
        findBtn.setToolTipText("Поиск текста во всех декомпилированных классах");
        findBtn.addActionListener(e -> findInCode());
        toolbar.add(findBtn);

        center.add(toolbar, BorderLayout.NORTH);
        center.add(editor, BorderLayout.CENTER);
        return center;
    }

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.add(statusLabel, BorderLayout.WEST);
        return bar;
    }

    /* ------------------------------ Дерево ------------------------------ */

    private void reloadTree() {
        try (Stream<Path> walk = Files.walk(sourcesDir)) {
            allFiles = walk.filter(p -> p.toString().endsWith(".java"))
                    .filter(Files::isRegularFile)
                    .sorted()
                    .toList();
        } catch (IOException e) {
            allFiles = List.of();
            statusLabel.setText("Не удалось прочитать исходники: " + e.getMessage());
        }
        applyFilter();
        statusLabel.setText(allFiles.size() + " классов декомпилировано");
    }

    private void applyFilter() {
        String filter = filterField.getText().trim().toLowerCase();
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("classes");
        java.util.Map<String, DefaultMutableTreeNode> packages = new java.util.HashMap<>();

        for (Path file : allFiles) {
            String rel = sourcesDir.relativize(file).toString().replace('\\', '/');
            if (!filter.isEmpty() && !rel.toLowerCase().contains(filter)) {
                continue;
            }
            int slash = rel.lastIndexOf('/');
            String pkg = slash < 0 ? "(default)" : rel.substring(0, slash);
            String cls = slash < 0 ? rel : rel.substring(slash + 1);
            DefaultMutableTreeNode pkgNode = packages.computeIfAbsent(pkg, p -> {
                DefaultMutableTreeNode n = new DefaultMutableTreeNode(p);
                root.add(n);
                return n;
            });
            pkgNode.add(new DefaultMutableTreeNode(new FileLeaf(cls, file)));
        }
        DefaultTreeModel model = new DefaultTreeModel(root);
        tree.setModel(model);
        // При активном фильтре раскрываем всё для удобства.
        if (!filter.isEmpty()) {
            for (int i = 0; i < tree.getRowCount(); i++) {
                tree.expandRow(i);
            }
        }
    }

    private void openSelected() {
        var node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
        if (node == null || !(node.getUserObject() instanceof FileLeaf leaf)) {
            return;
        }
        // Не теряем несохранённые правки при переключении.
        if (editor.isModified() && editor.getCurrentFile() != null
                && !editor.getCurrentFile().equals(leaf.path())) {
            int answer = JOptionPane.showConfirmDialog(this,
                    "В файле " + editor.getCurrentFile().getFileName()
                            + " есть несохранённые изменения. Сохранить?",
                    "Несохранённые изменения",
                    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
            if (answer == JOptionPane.CANCEL_OPTION) {
                return;
            }
            if (answer == JOptionPane.YES_OPTION) {
                editor.saveQuietly();
            }
        }
        editor.loadFile(leaf.path());
        statusLabel.setText(sourcesDir.relativize(leaf.path()).toString());
    }

    /* --------------------------- Перекомпиляция --------------------------- */

    private void recompile() {
        if (targetJar == null) {
            JOptionPane.showMessageDialog(this,
                    "Нет целевого jar для перекомпиляции (откройте окно после миграции).",
                    "Перекомпиляция", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Сохраняем текущие правки, чтобы не перекомпилировать устаревший файл.
        if (editor.isModified()) {
            editor.saveQuietly();
        }
        statusLabel.setText("Компиляция и упаковка в jar\u2026");
        setEnabledRecursively(false);
        new SwingWorker<JarRecompiler.Result, Void>() {
            @Override
            protected JarRecompiler.Result doInBackground() {
                return JarRecompiler.recompile(sourcesDir, targetJar, classpath, release);
            }

            @Override
            protected void done() {
                setEnabledRecursively(true);
                JarRecompiler.Result result;
                try {
                    result = get();
                } catch (Exception ex) {
                    statusLabel.setText("Перекомпиляция не выполнена");
                    return;
                }
                if (result.success()) {
                    statusLabel.setText("Готово: " + result.compiledClasses()
                            + " классов записано в " + targetJar.getFileName());
                    JOptionPane.showMessageDialog(CodeBrowserWindow.this,
                            "Перекомпиляция успешна.\n" + result.compiledClasses()
                                    + " классов обновлено в:\n" + targetJar,
                            "Готово", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    statusLabel.setText("Ошибки компиляции — см. диалог");
                    showErrors(result.diagnostics());
                }
            }
        }.execute();
    }

    private void showErrors(String diagnostics) {
        javax.swing.JTextArea area = new javax.swing.JTextArea(diagnostics, 20, 80);
        area.setEditable(false);
        area.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 12));
        JOptionPane.showMessageDialog(this, new JScrollPane(area),
                "Ошибки компиляции", JOptionPane.ERROR_MESSAGE);
    }

    /* ----------------------------- Поиск по коду ----------------------------- */

    private void findInCode() {
        String query = JOptionPane.showInputDialog(this,
                "Текст для поиска во всех классах:", "Поиск в коде",
                JOptionPane.QUESTION_MESSAGE);
        if (query == null || query.isBlank()) {
            return;
        }
        String needle = query.toLowerCase();
        List<Path> hits = new ArrayList<>();
        for (Path file : allFiles) {
            try {
                if (Files.readString(file).toLowerCase().contains(needle)) {
                    hits.add(file);
                }
            } catch (IOException ignored) {
                // пропускаем нечитаемый файл
            }
        }
        if (hits.isEmpty()) {
            statusLabel.setText("Не найдено: " + query);
            JOptionPane.showMessageDialog(this, "Совпадений не найдено: " + query,
                    "Поиск в коде", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        // Список совпавших классов; выбор открывает файл в редакторе.
        javax.swing.DefaultListModel<String> model = new javax.swing.DefaultListModel<>();
        for (Path hit : hits) {
            model.addElement(sourcesDir.relativize(hit).toString().replace('\\', '/'));
        }
        javax.swing.JList<String> list = new javax.swing.JList<>(model);
        list.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(0);
        JScrollPane scroll = new JScrollPane(list);
        scroll.setPreferredSize(new Dimension(560, 320));
        int answer = JOptionPane.showConfirmDialog(this, scroll,
                "Найдено в " + hits.size() + " классах — открыть выбранный",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (answer == JOptionPane.OK_OPTION && list.getSelectedIndex() >= 0) {
            editor.loadFile(hits.get(list.getSelectedIndex()));
            statusLabel.setText(model.get(list.getSelectedIndex()));
        }
    }

    /* ------------------------------ Утилиты ------------------------------ */

    private void setEnabledRecursively(boolean enabled) {
        tree.setEnabled(enabled);
        filterField.setEnabled(enabled);
    }

    /** Лист дерева: отображает имя класса, хранит путь. */
    private record FileLeaf(String name, Path path) {
        @Override
        public String toString() {
            return name;
        }
    }

    /** Простой слушатель изменений текстового поля. */
    private static final class SimpleDocListener
            implements javax.swing.event.DocumentListener {
        private final Runnable onChange;

        SimpleDocListener(Runnable onChange) {
            this.onChange = onChange;
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }
    }
}
