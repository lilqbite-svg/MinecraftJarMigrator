package com.mcmigrator.classpath;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mcmigrator.Constants;
import com.mcmigrator.ModType;
import com.mcmigrator.exception.MappingsException;
import com.mcmigrator.mappings.MappingChain;
import com.mcmigrator.mappings.MappingsProvider;
import com.mcmigrator.report.MigrationReport;
import com.mcmigrator.util.Throwables;
import net.fabricmc.mappingio.MappingReader;
import net.fabricmc.mappingio.tree.MemoryMappingTree;
import net.fabricmc.tinyremapper.NonClassCopyMode;
import net.fabricmc.tinyremapper.OutputConsumerPath;
import net.fabricmc.tinyremapper.TinyRemapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Stream;

/**
 * Автоматический classpath для рекомпиляции: скачивает ванильный server.jar
 * целевой версии, деобфусцирует его MojMap-маппингами в Mojang-имена,
 * извлекает библиотеки, а для Paper/Fabric дополнительно скачивает их API.
 * Всё кэшируется в {@code ~/.mcmigrator/classpath/{version}/}.
 */
public final class ClasspathProvider {

    private static final Logger log = LoggerFactory.getLogger(ClasspathProvider.class);

    private static final Pattern SNAPSHOT_JAR = Pattern.compile(
            "<snapshotVersion>\\s*<extension>jar</extension>\\s*<value>([^<]+)</value>",
            Pattern.DOTALL);
    private static final Pattern MAVEN_RELEASE = Pattern.compile("<release>([^<]+)</release>");

    private final MappingsProvider mappings;
    private final Path cacheRoot;
    private final HttpClient http = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(30))
            .build();

    /**
     * @param mappings  поставщик маппингов (для деобфускации server.jar)
     * @param cacheRoot корень кэша classpath
     */
    public ClasspathProvider(MappingsProvider mappings, Path cacheRoot) {
        this.mappings = mappings;
        this.cacheRoot = cacheRoot;
    }

    /**
     * Собирает автоматический classpath для целевой версии и типа мода.
     * Ошибки отдельных компонентов не фатальны: что не скачалось —
     * попадает предупреждением в отчёт.
     *
     * @param version целевая версия Minecraft
     * @param type    тип мода/плагина
     * @param report  отчёт миграции (для предупреждений)
     * @return список jar для classpath (может быть пустым)
     */
    public List<Path> autoClasspath(String version, ModType type, MigrationReport report,
                                    Path inputJar) {
        List<Path> result = new ArrayList<>();
        Path dir = cacheRoot.resolve(version);

        boolean client = type == ModType.FABRIC || type == ModType.FORGE || type == ModType.QUILT;
        boolean intermediary = (type == ModType.FABRIC || type == ModType.QUILT) && isIntermediaryMod(inputJar);
        List<Path> minecraftJars = new ArrayList<>();
        try {
            if (intermediary) {
                log.info("  Auto-classpath: мод в intermediary-именах Fabric — "
                        + "готовлю intermediary client.jar");
                report.addWarning("Мод собран в intermediary-именах (production Fabric): "
                        + "classpath подготовлен в intermediary; Mixin-классы после "
                        + "декомпиляции могут требовать ручной правки");
                minecraftJars.addAll(ensureIntermediaryClient(version, dir));
            } else {
                minecraftJars.addAll(ensureMojangMappedMinecraft(version, dir, client));
            }
        } catch (Exception e) {
            String msg = "Auto-classpath: не удалось подготовить "
                    + (client ? "client" : "server") + ".jar " + version
                    + " (" + Throwables.describe(e) + ")";
            log.warn("  {}", msg, e);
            report.addWarning(msg);
        }

        // Access Widener мода: вскрываем приватные классы Minecraft, как это
        // делает fabric-loader в рантайме — иначе компиляция падает
        // с "has private access".
        if (!minecraftJars.isEmpty()) {
            try {
                applyAccessWidener(inputJar, minecraftJars, dir,
                        intermediary ? "intermediary" : "named", report);
            } catch (Exception e) {
                String msg = "Auto-classpath: access widener не применён ("
                        + Throwables.describe(e) + ")";
                log.warn("  {}", msg, e);
                report.addWarning(msg);
            }
        }
        result.addAll(minecraftJars);

        switch (type) {
            case PAPER, SPIGOT -> {
                try {
                    result.add(ensurePaperApi(version, dir));
                } catch (Exception e) {
                    String msg = "Auto-classpath: paper-api " + version + " не скачан ("
                            + Throwables.describe(e) + ")";
                    log.warn("  {}", msg, e);
                    report.addWarning(msg);
                }
            }
            case FABRIC -> {
                try {
                    result.addAll(extractNestedJars(inputJar,
                            dir.resolve("mod-deps").resolve(stem(inputJar))));
                } catch (Exception e) {
                    log.warn("  Auto-classpath: вложенные jar мода не извлечены ({})",
                            Throwables.describe(e));
                }
                try {
                    result.addAll(resolveModDependencies(inputJar, version,
                            dir.resolve("mod-deps"), report));
                } catch (Exception e) {
                    log.warn("  Auto-classpath: зависимости мода не разрешены ({})",
                            Throwables.describe(e));
                }
                try {
                    result.addAll(ensureAsm(dir));
                } catch (Exception e) {
                    log.warn("  Auto-classpath: ASM не скачан ({})", Throwables.describe(e));
                }
                try {
                    result.add(ensureSpongeMixin(dir));
                } catch (Exception e) {
                    log.warn("  Auto-classpath: sponge-mixin не скачан ({})",
                            Throwables.describe(e));
                }
                try {
                    result.add(ensureFabricLoader(dir));
                } catch (Exception e) {
                    log.warn("  Auto-classpath: fabric-loader не скачан ({})",
                            Throwables.describe(e));
                }
                try {
                    result.addAll(ensureFabricApi(version, dir));
                } catch (Exception e) {
                    String msg = "Auto-classpath: Fabric API для " + version + " не скачан ("
                            + Throwables.describe(e) + ")";
                    log.warn("  {}", msg, e);
                    report.addWarning(msg);
                }
            }
            case FORGE -> {
                try {
                    result.addAll(ensureForgeArtifacts(version, dir, report));
                } catch (Exception e) {
                    log.warn("  Auto-classpath: артефакты Forge/NeoForge не скачаны ({})",
                            Throwables.describe(e));
                }
                report.addWarning(
                        "Auto-classpath (Forge): скачаны universal-артефакты загрузчика; "
                                + "пропатченные классы Minecraft из них не извлекаются — "
                                + "при ошибках компиляции добавьте jar из MDK через --classpath");
            }
        }

        try {
            result.add(ensureJetbrainsAnnotations(dir));
        } catch (Exception e) {
            log.warn("  Auto-classpath: jetbrains-annotations не скачаны ({})",
                    Throwables.describe(e));
        }
        return result;
    }

    /**
     * Скачивает client.jar (моды) или server.jar (плагины) версии,
     * деобфусцирует его и подготавливает библиотеки.
     */
    private List<Path> ensureMojangMappedMinecraft(String version, Path dir, boolean client)
            throws IOException, InterruptedException, MappingsException {
        String side = client ? "client" : "server";
        Path mojmapJar = dir.resolve(side + "-" + version + "-mojmap.jar");
        Path libsDir = dir.resolve("libs");

        if (!Files.isRegularFile(mojmapJar)) {
            Files.createDirectories(dir);
            log.info("  Auto-classpath: скачиваю {}.jar {}...", side, version);
            Path vanilla = dir.resolve(side + "-" + version + "-obf.jar");
            JsonObject versionJson = downloadVanilla(version, vanilla, side);

            Path classesJar = vanilla;
            if (!client) {
                // 1.18+: server в bundler-формате — классы во вложенном jar.
                classesJar = extractBundler(vanilla, dir, libsDir);
            } else {
                downloadLibraries(versionJson, libsDir);
            }

            log.info("  Auto-classpath: деобфусцирую {}.jar в Mojang-имена "
                    + "(первый раз — несколько минут)...", side);
            remapToMojang(version, classesJar, mojmapJar);
            Files.deleteIfExists(vanilla);
            if (!classesJar.equals(vanilla)) {
                Files.deleteIfExists(classesJar);
            }
        } else {
            log.info("  Auto-classpath: {}.jar {} взят из кэша", side, version);
        }

        List<Path> jars = new ArrayList<>();
        jars.add(mojmapJar);
        if (Files.isDirectory(libsDir)) {
            try (Stream<Path> walk = Files.walk(libsDir)) {
                walk.filter(p -> p.toString().endsWith(".jar")).sorted().forEach(jars::add);
            }
        }
        return jars;
    }

    private JsonObject downloadVanilla(String version, Path target, String side)
            throws IOException, InterruptedException, MappingsException {
        JsonObject manifest = getJson(Constants.VERSION_MANIFEST_URL);
        String versionUrl = null;
        for (var el : manifest.getAsJsonArray("versions")) {
            JsonObject v = el.getAsJsonObject();
            if (version.equals(v.get("id").getAsString())) {
                versionUrl = v.get("url").getAsString();
                break;
            }
        }
        if (versionUrl == null) {
            throw new MappingsException("версия не найдена в манифесте Mojang");
        }
        JsonObject versionJson = getJson(versionUrl);
        JsonObject downloads = versionJson.getAsJsonObject("downloads");
        if (downloads == null || !downloads.has(side)) {
            throw new MappingsException("у версии нет jar стороны " + side);
        }
        download(downloads.getAsJsonObject(side).get("url").getAsString(), target);
        return versionJson;
    }

    /** Скачивает библиотеки из version.json (Brigadier, DataFixerUpper и т.д.). */
    private void downloadLibraries(JsonObject versionJson, Path libsDir)
            throws IOException, InterruptedException {
        JsonArray libraries = versionJson.getAsJsonArray("libraries");
        if (libraries == null) {
            return;
        }
        Files.createDirectories(libsDir);
        int downloaded = 0;
        for (var el : libraries) {
            JsonObject lib = el.getAsJsonObject();
            if (lib.has("rules")) {
                continue; // платформозависимые natives не нужны для компиляции
            }
            JsonObject dl = lib.getAsJsonObject("downloads");
            if (dl == null || !dl.has("artifact")) {
                continue;
            }
            JsonObject artifact = dl.getAsJsonObject("artifact");
            String url = artifact.get("url").getAsString();
            Path out = libsDir.resolve(url.substring(url.lastIndexOf('/') + 1));
            if (Files.isRegularFile(out)) {
                continue;
            }
            try {
                download(url, out);
                downloaded++;
            } catch (MappingsException e) {
                log.debug("Библиотека пропущена: {} ({})", url, e.getMessage());
            }
        }
        if (downloaded > 0) {
            log.info("  Auto-classpath: скачано библиотек: {}", downloaded);
        }
    }

    /**
     * Если jar в bundler-формате (1.18+), извлекает вложенный server-jar
     * и библиотеки; иначе возвращает исходный jar.
     */
    private Path extractBundler(Path vanilla, Path dir, Path libsDir) throws IOException {
        try (JarFile jar = new JarFile(vanilla.toFile())) {
            JarEntry inner = null;
            List<JarEntry> libs = new ArrayList<>();
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry e = entries.nextElement();
                String name = e.getName();
                if (name.startsWith("META-INF/versions/") && name.endsWith(".jar")) {
                    inner = e;
                } else if (name.startsWith("META-INF/libraries/") && name.endsWith(".jar")) {
                    libs.add(e);
                }
            }
            if (inner == null) {
                return vanilla; // старый формат: классы прямо в jar
            }
            Files.createDirectories(libsDir);
            for (JarEntry lib : libs) {
                Path out = libsDir.resolve(Path.of(lib.getName()).getFileName().toString());
                try (InputStream in = jar.getInputStream(lib)) {
                    Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
                }
            }
            Path serverClasses = dir.resolve("server-inner.jar");
            try (InputStream in = jar.getInputStream(inner)) {
                Files.copy(in, serverClasses, StandardCopyOption.REPLACE_EXISTING);
            }
            log.debug("Bundler распакован: {} библиотек", libs.size());
            return serverClasses;
        }
    }

    private void remapToMojang(String version, Path obfJar, Path output)
            throws IOException, MappingsException {
        TinyRemapper remapper = TinyRemapper.newRemapper()
                .withMappings(MappingChain.deobf(mappings.tree(version)))
                .ignoreConflicts(true)
                .build();
        try (OutputConsumerPath out = new OutputConsumerPath.Builder(output).build()) {
            out.addNonClassFiles(obfJar, NonClassCopyMode.FIX_META_INF, remapper);
            remapper.readInputs(obfJar);
            remapper.apply(out);
        } finally {
            remapper.finish();
        }
    }

    /** Применяет .accesswidener мода к подготовленному jar Minecraft (первому в списке). */
    private void applyAccessWidener(Path inputJar, List<Path> minecraftJars, Path dir,
                                    String expectedNs, MigrationReport report)
            throws IOException {
        String awText = readAccessWidener(inputJar);
        if (awText == null) {
            return;
        }
        String ns = AccessWidenerApplier.namespace(awText);
        if (ns != null && !ns.equals(expectedNs)) {
            report.addWarning("Access widener мода в неймспейсе '" + ns
                    + "', а classpath — '" + expectedNs + "': widener пропущен, возможны "
                    + "ошибки 'has private access'");
            return;
        }
        Path base = minecraftJars.get(0);
        String hash = sha1Hex(awText).substring(0, 8);
        Path widened = base.resolveSibling(
                stem(base) + "-aw-" + hash + ".jar");
        if (!Files.isRegularFile(widened)) {
            AccessWidenerApplier aw = AccessWidenerApplier.parse(awText);
            log.info("  Auto-classpath: применяю access widener мода ({} классов)...",
                    aw.targetCount());
            aw.apply(base, widened);
        } else {
            log.info("  Auto-classpath: access widener взят из кэша");
        }
        minecraftJars.set(0, widened);
    }

    /** @return текст .accesswidener мода или {@code null}, если его нет */
    private String readAccessWidener(Path inputJar) throws IOException {
        try (JarFile jar = new JarFile(inputJar.toFile())) {
            JarEntry modJson = jar.getJarEntry("fabric.mod.json");
            if (modJson == null) {
                return null;
            }
            JsonObject json;
            try (InputStream in = jar.getInputStream(modJson)) {
                json = JsonParser.parseString(
                        new String(in.readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
            }
            if (!json.has("accessWidener")) {
                return null;
            }
            JarEntry aw = jar.getJarEntry(json.get("accessWidener").getAsString());
            if (aw == null) {
                return null;
            }
            try (InputStream in = jar.getInputStream(aw)) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        }
    }

    /** Извлекает вложенные jar (Jar-in-Jar) из jar мода. */
    private List<Path> extractNestedJars(Path modJar, Path outDir) throws IOException {
        List<Path> extracted = new ArrayList<>();
        try (JarFile jar = new JarFile(modJar.toFile())) {
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry e = entries.nextElement();
                if (e.getName().startsWith("META-INF/jars/") && e.getName().endsWith(".jar")) {
                    Files.createDirectories(outDir);
                    Path out = outDir.resolve(Path.of(e.getName()).getFileName().toString());
                    if (!Files.isRegularFile(out)) {
                        try (InputStream in = jar.getInputStream(e)) {
                            Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
                        }
                    }
                    extracted.add(out);
                }
            }
        }
        if (!extracted.isEmpty()) {
            log.info("  Auto-classpath: извлечено вложенных jar мода: {}", extracted.size());
        }
        return extracted;
    }

    /** Скачивает с Modrinth моды-зависимости, объявленные в fabric.mod.json. */
    private List<Path> resolveModDependencies(Path inputJar, String version, Path depsDir,
                                              MigrationReport report) throws IOException {
        Set<String> skip = Set.of("minecraft", "java", "fabricloader");
        List<Path> jars = new ArrayList<>();
        JsonObject json;
        try (JarFile jar = new JarFile(inputJar.toFile())) {
            JarEntry modJson = jar.getJarEntry("fabric.mod.json");
            if (modJson == null) {
                return jars;
            }
            try (InputStream in = jar.getInputStream(modJson)) {
                json = JsonParser.parseString(
                        new String(in.readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
            }
        }
        if (!json.has("depends")) {
            return jars;
        }
        for (String depId : json.getAsJsonObject("depends").keySet()) {
            if (skip.contains(depId) || depId.startsWith("fabric")) {
                continue;
            }
            Path jar = depsDir.resolve(depId + "-" + version + ".jar");
            if (Files.isRegularFile(jar)) {
                log.info("  Auto-classpath: зависимость {} взята из кэша", depId);
                jars.add(jar);
                continue;
            }
            try {
                String url = "https://api.modrinth.com/v2/project/" + depId
                        + "/version?game_versions="
                        + URLEncoder.encode("[\"" + version + "\"]", StandardCharsets.UTF_8)
                        + "&loaders=" + URLEncoder.encode("[\"fabric\"]", StandardCharsets.UTF_8);
                JsonArray versions = JsonParser.parseString(getText(url)).getAsJsonArray();
                if (versions.isEmpty()) {
                    throw new MappingsException("нет сборки под " + version);
                }
                Files.createDirectories(depsDir);
                String fileUrl = versions.get(0).getAsJsonObject()
                        .getAsJsonArray("files").get(0).getAsJsonObject()
                        .get("url").getAsString();
                log.info("  Auto-classpath: скачиваю зависимость {} для {}...", depId, version);
                download(fileUrl, jar);
                jars.add(jar);
                jars.addAll(extractNestedJars(jar, depsDir.resolve(stem(jar))));
            } catch (Exception e) {
                String msg = "Auto-classpath: зависимость '" + depId + "' не скачана ("
                        + Throwables.describe(e) + ") — добавьте её jar в classpath вручную";
                log.warn("  {}", msg);
                report.addWarning(msg);
            }
        }
        return jars;
    }

    /** Скачивает библиотеки ASM (нужны MixinPlugin-классам модов). */
    private List<Path> ensureAsm(Path dir)
            throws IOException, InterruptedException, MappingsException {
        Matcher m = MAVEN_RELEASE.matcher(
                getText("https://repo1.maven.org/maven2/org/ow2/asm/asm/maven-metadata.xml"));
        if (!m.find()) {
            throw new MappingsException("версия ASM не определена");
        }
        String v = m.group(1);
        List<Path> jars = new ArrayList<>();
        for (String artifact : List.of("asm", "asm-tree", "asm-commons", "asm-analysis", "asm-util")) {
            Path jar = dir.resolve(artifact + "-" + v + ".jar");
            if (!Files.isRegularFile(jar)) {
                Files.createDirectories(dir);
                download("https://repo1.maven.org/maven2/org/ow2/asm/" + artifact + "/" + v
                        + "/" + artifact + "-" + v + ".jar", jar);
            }
            jars.add(jar);
        }
        log.info("  Auto-classpath: ASM {} готов", v);
        return jars;
    }

    private static String stem(Path jar) {
        String name = jar.getFileName().toString();
        return name.endsWith(".jar") ? name.substring(0, name.length() - 4) : name;
    }

    private static String sha1Hex(String text) {
        try {
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-1").digest(text.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            return Integer.toHexString(text.hashCode());
        }
    }

    /** Эвристика: ссылается ли байткод мода на intermediary-имена (net/minecraft/class_NNN). */
    private boolean isIntermediaryMod(Path inputJar) {
        byte[] needle = "net/minecraft/class_".getBytes(StandardCharsets.US_ASCII);
        try (JarFile jar = new JarFile(inputJar.toFile())) {
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry e = entries.nextElement();
                if (!e.getName().endsWith(".class")) {
                    continue;
                }
                try (InputStream in = jar.getInputStream(e)) {
                    if (contains(in.readAllBytes(), needle)) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            log.debug("Детект intermediary не удался: {}", e.getMessage());
        }
        return false;
    }

    private static boolean contains(byte[] haystack, byte[] needle) {
        outer:
        for (int i = 0; i <= haystack.length - needle.length; i++) {
            for (int j = 0; j < needle.length; j++) {
                if (haystack[i + j] != needle[j]) {
                    continue outer;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Готовит client.jar целевой версии в intermediary-именах Fabric:
     * intermediary стабильны между версиями, поэтому production-мод
     * компилируется против такого jar напрямую.
     */
    private List<Path> ensureIntermediaryClient(String version, Path dir)
            throws IOException, InterruptedException, MappingsException {
        Path interJar = dir.resolve("client-" + version + "-intermediary.jar");
        Path libsDir = dir.resolve("libs");

        if (!Files.isRegularFile(interJar)) {
            Files.createDirectories(dir);
            MemoryMappingTree tree = loadIntermediaryTree(version, dir);

            log.info("  Auto-classpath: скачиваю client.jar {}...", version);
            Path vanilla = dir.resolve("client-" + version + "-obf.jar");
            JsonObject versionJson = downloadVanilla(version, vanilla, "client");
            downloadLibraries(versionJson, libsDir);

            log.info("  Auto-classpath: ремаплю client.jar в intermediary "
                    + "(первый раз — несколько минут)...");
            TinyRemapper remapper = TinyRemapper.newRemapper()
                    .withMappings(MappingChain.deobf(tree, "intermediary"))
                    .ignoreConflicts(true)
                    .build();
            try (OutputConsumerPath out = new OutputConsumerPath.Builder(interJar).build()) {
                out.addNonClassFiles(vanilla, NonClassCopyMode.FIX_META_INF, remapper);
                remapper.readInputs(vanilla);
                remapper.apply(out);
            } finally {
                remapper.finish();
            }
            Files.deleteIfExists(vanilla);
        } else {
            log.info("  Auto-classpath: intermediary client.jar {} взят из кэша", version);
        }

        List<Path> jars = new ArrayList<>();
        jars.add(interJar);
        if (Files.isDirectory(libsDir)) {
            try (Stream<Path> walk = Files.walk(libsDir)) {
                walk.filter(p -> p.toString().endsWith(".jar")).sorted().forEach(jars::add);
            }
        }
        return jars;
    }

    /** Скачивает intermediary-маппинги Fabric и читает их в дерево. */
    private MemoryMappingTree loadIntermediaryTree(String version, Path dir)
            throws IOException, InterruptedException, MappingsException {
        Path tiny = dir.resolve("intermediary-" + version + ".tiny");
        if (!Files.isRegularFile(tiny)) {
            String url = "https://maven.fabricmc.net/net/fabricmc/intermediary/" + version
                    + "/intermediary-" + version + "-v2.jar";
            Path tmp = dir.resolve("intermediary-" + version + ".jar");
            log.info("  Auto-classpath: скачиваю intermediary-маппинги {}...", version);
            download(url, tmp);
            try (JarFile jar = new JarFile(tmp.toFile())) {
                JarEntry entry = jar.getJarEntry("mappings/mappings.tiny");
                if (entry == null) {
                    throw new MappingsException("в intermediary-jar нет mappings/mappings.tiny");
                }
                try (InputStream in = jar.getInputStream(entry)) {
                    Files.copy(in, tiny, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(tmp);
            }
        }
        MemoryMappingTree tree = new MemoryMappingTree();
        MappingReader.read(tiny, tree);
        return tree;
    }

    /** Скачивает sponge-mixin (нужен для компиляции Mixin-классов Fabric-модов). */
    private Path ensureSpongeMixin(Path dir)
            throws IOException, InterruptedException, MappingsException {
        String metaUrl = "https://maven.fabricmc.net/net/fabricmc/sponge-mixin/maven-metadata.xml";
        Matcher m = MAVEN_RELEASE.matcher(getText(metaUrl));
        if (!m.find()) {
            throw new MappingsException("версия sponge-mixin не определена");
        }
        String v = m.group(1);
        Path jar = dir.resolve("sponge-mixin-" + v + ".jar");
        if (!Files.isRegularFile(jar)) {
            Files.createDirectories(dir);
            log.info("  Auto-classpath: скачиваю sponge-mixin {}...", v);
            download("https://maven.fabricmc.net/net/fabricmc/sponge-mixin/" + v
                    + "/sponge-mixin-" + v + ".jar", jar);
        }
        return jar;
    }

    /** Скачивает paper-api целевой версии из официального maven-репозитория Paper. */
    private Path ensurePaperApi(String version, Path dir)
            throws IOException, InterruptedException, MappingsException {
        Path jar = dir.resolve("paper-api-" + version + ".jar");
        if (Files.isRegularFile(jar)) {
            log.info("  Auto-classpath: paper-api {} взят из кэша", version);
            return jar;
        }
        Files.createDirectories(dir);
        String base = "https://repo.papermc.io/repository/maven-public/io/papermc/paper/paper-api/"
                + version + "-R0.1-SNAPSHOT/";
        String metadata = getText(base + "maven-metadata.xml");
        Matcher m = SNAPSHOT_JAR.matcher(metadata);
        if (!m.find()) {
            throw new MappingsException("снапшот paper-api не найден");
        }
        log.info("  Auto-classpath: скачиваю paper-api {}...", version);
        download(base + "paper-api-" + m.group(1) + ".jar", jar);
        return jar;
    }

    /** Скачивает последнюю стабильную версию fabric-loader. */
    private Path ensureFabricLoader(Path dir)
            throws IOException, InterruptedException, MappingsException {
        String metaUrl = "https://maven.fabricmc.net/net/fabricmc/fabric-loader/maven-metadata.xml";
        Matcher m = MAVEN_RELEASE.matcher(getText(metaUrl));
        if (!m.find()) {
            throw new MappingsException("версия fabric-loader не определена");
        }
        String v = m.group(1);
        Path jar = dir.resolve("fabric-loader-" + v + ".jar");
        if (!Files.isRegularFile(jar)) {
            Files.createDirectories(dir);
            log.info("  Auto-classpath: скачиваю fabric-loader {}...", v);
            download("https://maven.fabricmc.net/net/fabricmc/fabric-loader/" + v
                    + "/fabric-loader-" + v + ".jar", jar);
        }
        return jar;
    }

    /**
     * Скачивает Fabric API под версию игры через Modrinth и распаковывает
     * вложенные модули (Jar-in-Jar из META-INF/jars/) — реальные классы
     * API лежат именно в них.
     */
    private List<Path> ensureFabricApi(String version, Path dir)
            throws IOException, InterruptedException, MappingsException {
        Path jar = dir.resolve("fabric-api-" + version + ".jar");
        Path modulesDir = dir.resolve("fabric-api-modules");

        if (!Files.isRegularFile(jar)) {
            Files.createDirectories(dir);
            String url = "https://api.modrinth.com/v2/project/fabric-api/version?game_versions="
                    + URLEncoder.encode("[\"" + version + "\"]", StandardCharsets.UTF_8)
                    + "&loaders=" + URLEncoder.encode("[\"fabric\"]", StandardCharsets.UTF_8);
            JsonArray versions = JsonParser.parseString(getText(url)).getAsJsonArray();
            if (versions.isEmpty()) {
                throw new MappingsException("на Modrinth нет Fabric API для " + version);
            }
            JsonArray files = versions.get(0).getAsJsonObject().getAsJsonArray("files");
            String fileUrl = files.get(0).getAsJsonObject().get("url").getAsString();
            log.info("  Auto-classpath: скачиваю Fabric API для {}...", version);
            download(fileUrl, jar);
        } else {
            log.info("  Auto-classpath: Fabric API {} взят из кэша", version);
        }

        if (!Files.isDirectory(modulesDir)) {
            Files.createDirectories(modulesDir);
            int extracted = 0;
            try (JarFile outer = new JarFile(jar.toFile())) {
                Enumeration<JarEntry> entries = outer.entries();
                while (entries.hasMoreElements()) {
                    JarEntry e = entries.nextElement();
                    if (e.getName().startsWith("META-INF/jars/") && e.getName().endsWith(".jar")) {
                        Path out = modulesDir.resolve(
                                Path.of(e.getName()).getFileName().toString());
                        try (InputStream in = outer.getInputStream(e)) {
                            Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
                        }
                        extracted++;
                    }
                }
            }
            log.info("  Auto-classpath: распаковано модулей Fabric API: {}", extracted);
        }

        List<Path> jars = new ArrayList<>();
        jars.add(jar);
        try (Stream<Path> walk = Files.walk(modulesDir)) {
            walk.filter(pth -> pth.toString().endsWith(".jar")).sorted().forEach(jars::add);
        }
        return jars;
    }

    /**
     * Скачивает universal-jar Forge или NeoForge под версию игры с их maven'ов
     * (best effort: точный артефакт зависит от схемы версионирования лоадера).
     */
    private List<Path> ensureForgeArtifacts(String version, Path dir, MigrationReport report)
            throws IOException, InterruptedException {
        List<Path> jars = new ArrayList<>();
        // NeoForge: maven-metadata со списком версий вида 21.11.x
        try {
            String meta = getText(
                    "https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml");
            String prefix = neoForgePrefix(version);
            String best = null;
            Matcher m = Pattern.compile("<version>([^<]+)</version>").matcher(meta);
            while (m.find()) {
                String v = m.group(1);
                if (prefix != null && v.startsWith(prefix)) {
                    best = v; // metadata отсортирована по возрастанию — берём последнюю
                }
            }
            if (best != null) {
                Path jar = dir.resolve("neoforge-" + best + "-universal.jar");
                if (!Files.isRegularFile(jar)) {
                    Files.createDirectories(dir);
                    log.info("  Auto-classpath: скачиваю NeoForge {} (universal)...", best);
                    download("https://maven.neoforged.net/releases/net/neoforged/neoforge/"
                            + best + "/neoforge-" + best + "-universal.jar", jar);
                }
                jars.add(jar);
            }
        } catch (Exception e) {
            log.debug("NeoForge universal недоступен: {}", Throwables.describe(e));
        }
        // Forge: версии вида {mc}-{forge}
        try {
            String meta = getText(
                    "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml");
            String best = null;
            Matcher m = Pattern.compile("<version>(" + Pattern.quote(version)
                    + "-[^<]+)</version>").matcher(meta);
            while (m.find()) {
                best = m.group(1);
            }
            if (best != null) {
                Path jar = dir.resolve("forge-" + best + "-universal.jar");
                if (!Files.isRegularFile(jar)) {
                    Files.createDirectories(dir);
                    log.info("  Auto-classpath: скачиваю Forge {} (universal)...", best);
                    download("https://maven.minecraftforge.net/net/minecraftforge/forge/"
                            + best + "/forge-" + best + "-universal.jar", jar);
                }
                jars.add(jar);
            }
        } catch (Exception e) {
            log.debug("Forge universal недоступен: {}", Throwables.describe(e));
        }
        // Библиотеки загрузчиков: EventBus и SPI — без них не компилируются
        // @SubscribeEvent-обработчики, самая частая часть Forge-модов.
        for (String[] lib : new String[][]{
                {"https://maven.neoforged.net/releases", "net/neoforged", "bus"},
                {"https://maven.minecraftforge.net", "net/minecraftforge", "eventbus"},
                {"https://maven.minecraftforge.net", "net/minecraftforge", "forgespi"}}) {
            try {
                jars.add(ensureMavenRelease(lib[0], lib[1], lib[2], dir));
            } catch (Exception e) {
                log.debug("Библиотека {} недоступна: {}", lib[2], Throwables.describe(e));
            }
        }
        if (jars.isEmpty()) {
            report.addWarning("Auto-classpath: для " + version
                    + " не найдено ни NeoForge, ни Forge universal-артефактов");
        }
        return jars;
    }

    /** Скачивает последний релиз артефакта с произвольного maven-репозитория. */
    private Path ensureMavenRelease(String repo, String group, String artifact, Path dir)
            throws IOException, InterruptedException, MappingsException {
        String metaUrl = repo + "/" + group + "/" + artifact + "/maven-metadata.xml";
        Matcher m = MAVEN_RELEASE.matcher(getText(metaUrl));
        if (!m.find()) {
            throw new MappingsException("release-версия " + artifact + " не определена");
        }
        String v = m.group(1);
        Path jar = dir.resolve(artifact + "-" + v + ".jar");
        if (!Files.isRegularFile(jar)) {
            Files.createDirectories(dir);
            log.info("  Auto-classpath: скачиваю {} {}...", artifact, v);
            download(repo + "/" + group + "/" + artifact + "/" + v + "/"
                    + artifact + "-" + v + ".jar", jar);
        }
        return jar;
    }

    /** {@code "1.21.11"} → NeoForge-префикс {@code "21.11."}; {@code "26.1"} → {@code "26.1."} */
    private static String neoForgePrefix(String mcVersion) {
        String[] parts = mcVersion.split("\\.");
        if (parts.length >= 2 && "1".equals(parts[0])) {
            return parts[1] + "." + (parts.length > 2 ? parts[2] : "0") + ".";
        }
        if (parts.length >= 2) {
            return parts[0] + "." + parts[1] + ".";
        }
        return null;
    }

    /** Скачивает аннотации JetBrains (@Nullable/@NotNull) с Maven Central. */
    private Path ensureJetbrainsAnnotations(Path dir)
            throws IOException, InterruptedException, MappingsException {
        String metaUrl =
                "https://repo1.maven.org/maven2/org/jetbrains/annotations/maven-metadata.xml";
        Matcher m = MAVEN_RELEASE.matcher(getText(metaUrl));
        if (!m.find()) {
            throw new MappingsException("версия org.jetbrains:annotations не определена");
        }
        String v = m.group(1);
        Path jar = dir.resolve("annotations-" + v + ".jar");
        if (!Files.isRegularFile(jar)) {
            Files.createDirectories(dir);
            log.info("  Auto-classpath: скачиваю jetbrains-annotations {}...", v);
            download("https://repo1.maven.org/maven2/org/jetbrains/annotations/" + v
                    + "/annotations-" + v + ".jar", jar);
        }
        return jar;
    }

    private JsonObject getJson(String url)
            throws IOException, InterruptedException, MappingsException {
        return JsonParser.parseString(getText(url)).getAsJsonObject();
    }

    private String getText(String url)
            throws IOException, InterruptedException, MappingsException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new MappingsException("HTTP " + response.statusCode() + " при запросе " + url);
        }
        return response.body();
    }

    private void download(String url, Path target)
            throws IOException, InterruptedException, MappingsException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
        HttpResponse<Path> response = http.send(request, HttpResponse.BodyHandlers.ofFile(target));
        if (response.statusCode() != 200) {
            Files.deleteIfExists(target);
            throw new MappingsException("HTTP " + response.statusCode() + " при скачивании " + url);
        }
    }
}
