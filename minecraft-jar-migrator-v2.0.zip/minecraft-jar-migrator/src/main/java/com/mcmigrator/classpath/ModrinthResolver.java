package com.mcmigrator.classpath;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public final class ModrinthResolver {

    private static final Logger log = LoggerFactory.getLogger(ModrinthResolver.class);
    private static final String API = "https://api.modrinth.com/v2";
    private final HttpClient http;
    private final Path cacheDir;

    public ModrinthResolver(Path cacheDir) {
        this.cacheDir = cacheDir;
        this.http = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(15))
                .build();
    }

    public record ResolvedDep(String name, String version, Path jar) {}

    public List<ResolvedDep> resolveFabricApi(String mcVersion) throws IOException, InterruptedException {
        return resolveDependency("P7dR8mSH", mcVersion, "fabric");
    }

    public List<ResolvedDep> resolveDependency(String projectId, String mcVersion, String loader)
            throws IOException, InterruptedException {
        String url = API + "/project/" + projectId + "/version?"
                + "game_versions=%5B%22" + mcVersion + "%22%5D"
                + "&loaders=%5B%22" + loader + "%22%5D";

        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "MinecraftJarMigrator/1.0")
                .GET().build();

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            log.debug("Modrinth API returned {} for project {}", response.statusCode(), projectId);
            return List.of();
        }

        List<ResolvedDep> result = new ArrayList<>();
        JsonArray versions = JsonParser.parseString(response.body()).getAsJsonArray();
        if (versions.isEmpty()) return result;

        JsonObject latest = versions.get(0).getAsJsonObject();
        String versionNumber = latest.get("version_number").getAsString();
        JsonArray files = latest.getAsJsonArray("files");

        Files.createDirectories(cacheDir);
        for (JsonElement fileEl : files) {
            JsonObject file = fileEl.getAsJsonObject();
            String fileName = file.get("filename").getAsString();
            String downloadUrl = file.get("url").getAsString();
            Path target = cacheDir.resolve(fileName);

            if (!Files.exists(target)) {
                download(downloadUrl, target);
            }
            result.add(new ResolvedDep(projectId, versionNumber, target));
        }
        return result;
    }

    private void download(String url, Path target) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", "MinecraftJarMigrator/1.0")
                .GET().build();
        HttpResponse<Path> response = http.send(request,
                HttpResponse.BodyHandlers.ofFile(target));
        if (response.statusCode() != 200) {
            Files.deleteIfExists(target);
            throw new IOException("Download failed: HTTP " + response.statusCode());
        }
        log.info("Downloaded: {}", target.getFileName());
    }
}
