package com.mcmigrator.classpath;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;

/**
 * Применяет Fabric Access Widener к jar Minecraft: расширяет доступ
 * перечисленных классов/методов/полей до public (и снимает final
 * для extendable/mutable), чтобы декомпилированный мод компилировался
 * против такого jar без ошибок "has private access".
 *
 * <p>Упрощение относительно спецификации AW: accessible и extendable
 * одинаково дают public (надмножество, безопасное для компиляции).</p>
 */
public final class AccessWidenerApplier {

    private static final Logger log = LoggerFactory.getLogger(AccessWidenerApplier.class);

    private final Set<String> classes = new HashSet<>();
    private final Set<String> unfinalClasses = new HashSet<>();
    private final Map<String, Set<String>> methods = new HashMap<>();
    private final Map<String, Set<String>> unfinalMethods = new HashMap<>();
    private final Map<String, Set<String>> fields = new HashMap<>();
    private final Map<String, Set<String>> unfinalFields = new HashMap<>();

    private AccessWidenerApplier() {
    }

    /**
     * @param awText содержимое .accesswidener
     * @return неймспейс из заголовка ({@code named}/{@code intermediary}) или {@code null}
     */
    public static String namespace(String awText) {
        for (String line : awText.split("\n")) {
            line = line.trim();
            if (line.startsWith("accessWidener")) {
                String[] parts = line.split("\\s+");
                return parts.length >= 3 ? parts[2] : null;
            }
        }
        return null;
    }

    /**
     * Разбирает текст access widener.
     *
     * @param awText содержимое .accesswidener
     * @return подготовленный аппликатор
     */
    public static AccessWidenerApplier parse(String awText) {
        AccessWidenerApplier aw = new AccessWidenerApplier();
        for (String raw : awText.split("\n")) {
            String line = raw.trim();
            int comment = line.indexOf('#');
            if (comment >= 0) {
                line = line.substring(0, comment).trim();
            }
            if (line.isEmpty() || line.startsWith("accessWidener")) {
                continue;
            }
            String[] p = line.split("\\s+");
            int i = 0;
            if (p[i].startsWith("transitive-")) {
                p[i] = p[i].substring("transitive-".length());
            }
            String access = p[i++];
            String kind = p[i++];
            switch (kind) {
                case "class" -> {
                    String cls = p[i];
                    aw.classes.add(cls);
                    if ("extendable".equals(access)) {
                        aw.unfinalClasses.add(cls);
                    }
                }
                case "method" -> {
                    String cls = p[i++];
                    String key = p[i] + p[i + 1];
                    aw.methods.computeIfAbsent(cls, k -> new HashSet<>()).add(key);
                    if ("extendable".equals(access)) {
                        aw.unfinalMethods.computeIfAbsent(cls, k -> new HashSet<>()).add(key);
                    }
                    aw.classes.add(cls); // владелец тоже должен быть доступен
                }
                case "field" -> {
                    String cls = p[i++];
                    String key = p[i] + p[i + 1];
                    aw.fields.computeIfAbsent(cls, k -> new HashSet<>()).add(key);
                    if ("mutable".equals(access)) {
                        aw.unfinalFields.computeIfAbsent(cls, k -> new HashSet<>()).add(key);
                    }
                    aw.classes.add(cls);
                }
                default -> log.debug("AW: неизвестная запись пропущена: {}", line);
            }
        }
        return aw;
    }

    /** @return число целевых классов */
    public int targetCount() {
        return classes.size();
    }

    /**
     * Применяет widener: копирует jar, переписывая флаги доступа целевых
     * классов и их членов.
     *
     * @param inputJar  исходный jar Minecraft
     * @param outputJar результирующий jar
     * @throws IOException при ошибке чтения/записи
     */
    public void apply(Path inputJar, Path outputJar) throws IOException {
        try (JarFile in = new JarFile(inputJar.toFile());
             JarOutputStream out = new JarOutputStream(Files.newOutputStream(outputJar))) {
            Enumeration<JarEntry> entries = in.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.isDirectory()) {
                    continue;
                }
                out.putNextEntry(new JarEntry(entry.getName()));
                try (InputStream is = in.getInputStream(entry)) {
                    if (entry.getName().endsWith(".class")) {
                        out.write(transform(is.readAllBytes()));
                    } else {
                        is.transferTo(out);
                    }
                }
                out.closeEntry();
            }
        }
    }

    private byte[] transform(byte[] classBytes) {
        ClassReader reader = new ClassReader(classBytes);
        ClassWriter writer = new ClassWriter(0);
        reader.accept(new AwVisitor(writer), 0);
        return writer.toByteArray();
    }

    private int widen(int access, boolean removeFinal) {
        int result = (access & ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED)) | Opcodes.ACC_PUBLIC;
        if (removeFinal) {
            result &= ~Opcodes.ACC_FINAL;
        }
        return result;
    }

    private final class AwVisitor extends ClassVisitor {

        private String className;

        AwVisitor(ClassVisitor cv) {
            super(Opcodes.ASM9, cv);
        }

        @Override
        public void visit(int version, int access, String name, String signature,
                          String superName, String[] interfaces) {
            className = name;
            if (classes.contains(name)) {
                access = widen(access, unfinalClasses.contains(name));
            }
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public void visitInnerClass(String name, String outerName, String innerName, int access) {
            if (classes.contains(name)) {
                access = widen(access, unfinalClasses.contains(name));
            }
            super.visitInnerClass(name, outerName, innerName, access);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor,
                                         String signature, String[] exceptions) {
            Set<String> targets = methods.get(className);
            if (targets != null && targets.contains(name + descriptor)) {
                Set<String> unfinal = unfinalMethods.get(className);
                access = widen(access, unfinal != null && unfinal.contains(name + descriptor));
            }
            return super.visitMethod(access, name, descriptor, signature, exceptions);
        }

        @Override
        public FieldVisitor visitField(int access, String name, String descriptor,
                                       String signature, Object value) {
            Set<String> targets = fields.get(className);
            if (targets != null && targets.contains(name + descriptor)) {
                Set<String> unfinal = unfinalFields.get(className);
                access = widen(access, unfinal != null && unfinal.contains(name + descriptor));
            }
            return super.visitField(access, name, descriptor, signature, value);
        }
    }
}
