rootProject.name = "minecraft-jar-migrator"
