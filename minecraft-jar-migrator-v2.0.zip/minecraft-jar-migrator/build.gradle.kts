plugins {
    java
    application
    // Fat-jar, чтобы работал запуск `java -jar migrator.jar`
    id("com.gradleup.shadow") version "9.4.2"
}

group = "com.mcmigrator"
version = "1.0.0"

java {
    // Не требуем отдельный JDK 17: компилируем на любом установленном
    // JDK 17+ с таргетом Java 17 (см. options.release ниже).
}

repositories {
    mavenCentral()
    // tiny-remapper и mapping-io публикуются на Maven FabricMC
    maven("https://maven.fabricmc.net/")
}

dependencies {
    // CLI
    implementation("info.picocli:picocli:4.7.5")
    annotationProcessor("info.picocli:picocli-codegen:4.7.5")

    // Декомпиляция
    implementation("org.vineflower:vineflower:1.10.1")
    // Альтернативные декомпиляторы (прямой API, без рефлексии)
    implementation("org.benf:cfr:0.152")
    implementation("org.bitbucket.mstrobel:procyon-compilertools:0.6.0")

    // Ремаппинг
    implementation("net.fabricmc:tiny-remapper:0.10.3")
    implementation("net.fabricmc:mapping-io:0.6.1")

    // Трансформация AST
    implementation("com.github.javaparser:javaparser-symbol-solver-core:3.25.8")

    // JSON-наборы правил (resources/rules/*.json)
    implementation("com.google.code.gson:gson:2.10.1")

    // Логирование
    implementation("org.slf4j:slf4j-api:2.0.12")
    implementation("ch.qos.logback:logback-classic:1.5.3")

    // GUI: modern Look-and-Feel with light/dark themes
    implementation("com.formdev:flatlaf:3.4")

    // Syntax highlighting editor
    implementation("com.fifesoft:rsyntaxtextarea:3.4.1")

    // Bytecode: Fabric Access Widener to client.jar
    implementation("org.ow2.asm:asm:9.7")

    // Test
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.2")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.test {
    useJUnitPlatform()
}

application {
    mainClass.set("com.mcmigrator.Main")
}

tasks.compileJava {
    options.encoding = "UTF-8"
    options.release.set(17)
    // для picocli-codegen
    options.compilerArgs.add("-Aproject=${project.group}/${project.name}")
}

tasks.shadowJar {
    archiveBaseName.set("migrator")
    archiveClassifier.set("")
    archiveVersion.set("")
    mergeServiceFiles()
    manifest {
        attributes("Main-Class" to "com.mcmigrator.Main")
    }
}

tasks.build {
    dependsOn(tasks.shadowJar)
}
